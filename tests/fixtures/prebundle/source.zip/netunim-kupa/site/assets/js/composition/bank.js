import {createDomainsBankController} from '../domains/bank/controller.js';
import {createKupaBankConnectionOwner,KUPA_BANK_BRIDGE_MINIMUM_VERSION} from '../domains/bank/connection-owner.js';
import {createBankConnectionForms} from '../domains/bank/connection-forms.js';
import {createKupaBankArchiveReadout} from '../domains/bank/archive-readout.js';
import {createBankArchiveReconciliation} from '../shared/bank-archive-reconciliation.js';
import {createFinanceLeaseOwner} from '../shared/finance-lease-owner.js';
import {bankArchiveTargets} from '../domains/bank/archive-model.js';
import {createKupaBankSnapshotCommands} from '../domains/bank/snapshot-commands.js';
import {createKupaBankRefresh} from '../domains/bank/refresh.js';
import {createKupaBankSnapshotPolicy} from '../domains/bank/snapshot-policy.js';
import {BANK_READOUT_WARNING} from '../domains/bank/snapshot-commands.js';
import {normalizeBankFeed} from '../domains/bank/feed.js';
import {bankRecurringDebitHistoryData} from '../shared/bank-recurring-debits.js';
import {bankAutoRefreshDue} from '../shared/finance-refresh-policy.js';
import {wholeMoney} from '../core/money.js';
import {createManualBankSnapshot} from '../domains/bank/manual-snapshot.js';
import {createBankLocalSnapshot} from '../domains/bank/local-snapshot.js';
import {uid} from '../core/values.js';
import {todayISO} from '../core/dates.js';
import {createDomainsBankView} from '../domains/bank/view.js';
import {createFinanceBrowserEffects} from '../shared/finance-browser-effects.js';
import {createBankActions} from '../ui/action-packs/bank.js';
import {createLazyDeferredSearchUpdater} from '../shared/search-scheduler.js';

function requireMethods(name, port, methods) {
  for (const method of methods) {
    if (typeof port?.[method] !== 'function') throw new TypeError(`kupa_bank_${name}_${method}_required`);
  }
}

// Owns Bank orchestration/presentation and resource lifetimes. The shared
// Finance Bridge and cloud adapters are supplied by Finance composition.
export function createKupaBankCapability({
  model, session, checks, cloud, persistence, bridge, authority, readout, revisions, platform={},
}) {
  if (!model || !session) throw new TypeError('kupa_bank_context_required');
  requireMethods('checks', checks, ['hasLocalWork', 'sync', 'save']);
  requireMethods('persistence', persistence, ['save', 'recover']);
  requireMethods('scope', authority?.scope, ['capture', 'captureRead']);
  if (typeof authority?.automaticAccess !== 'function') throw new TypeError('kupa_bank_automatic_access_required');
  requireMethods('readout', readout, ['balance', 'forecast', 'observedCheckSequence']);
  requireMethods('revisions', revisions, ['touchData', 'touchDisplay']);
  requireMethods('cloud', cloud, ['refreshFinance', 'claimLease', 'releaseLease',
    'saveSnapshot', 'syncTransactions', 'readTransactions', 'readTransactionSnapshot',
    'acknowledgeMissing', 'syncImages', 'downloadImage']);
  const effects = platform.effects ?? createFinanceBrowserEffects();
  requireMethods('effects', effects, ['saveJson', 'dispose']);
  let disposed = false, binding = null;
  const pending = new Set();
  function ready() {
    if (disposed) throw new Error('kupa_bank_disposed');
    if (!binding) throw new Error('kupa_bank_ui_not_bound');
    return binding;
  }
  const notify = (...args) => { if (!disposed) return ready().toast(...args); };
  const render = (...args) => { if (!disposed) return ready().render(...args); };
  function capture(method) {
    const guard = authority.scope[method]();
    return () => {
      if (disposed) throw Object.assign(new Error('kupa_bank_disposed'), {code:'FINANCE_OPERATION_SCOPE_CHANGED'});
      guard();
    };
  }
  const scope = {capture:() => capture('capture'), captureRead:() => capture('captureRead')};
  const archive = createKupaBankArchiveReadout({
    authority:scope,
    sources:{targets:() => bankArchiveTargets(model.state.bank || {})},
    reads:{
      transactions:(...args) => cloud.readTransactions(...args),
      snapshot:(...args) => cloud.readTransactionSnapshot(...args),
    },
    access:{cloud:() => session.connectionMode === 'supabase'},
    publication:() => { revisions.touchDisplay(); render(); },
    report:(role,error) => console.error(`bank display archive ${role}`,error),
  });
  const localSnapshot = createBankLocalSnapshot({
    model, saveState:(...args) => persistence.save(...args),
    recoverLocalState:(...args) => persistence.recover(...args), render,
  });
  const snapshots = createKupaBankSnapshotCommands({
    authority:scope,
    bank:{
      mode:() => session.connectionMode,
      manualCandidate:(numeric,options) => {
        const observedSeq = readout.observedCheckSequence();
        return createManualBankSnapshot(model.state.bank,numeric,observedSeq,options,{
          now:() => new Date().toISOString(), today:todayISO, createToken:() => uid('BANK'),
        });
      },
    },
    checks:{hasLocalWork:(...args) => checks.hasLocalWork(...args),saveCloud:(...args) => checks.save(...args),syncCloud:(...args) => checks.sync(...args)},
    local:localSnapshot,
    cloud:{publish:(...args) => cloud.saveSnapshot(...args),refresh:(...args) => cloud.refreshFinance(...args)},
    publication:{archive:archive.commands.publish,data:(...args) => { revisions.touchData(...args); }},
  });
  const syncLeases = createFinanceLeaseOwner({
    leases:{claim:(...args) => cloud.claimLease(...args),release:(...args) => cloud.releaseLease(...args)},
    authority:authority.scope,timers:platform.timers??globalThis,
  });
  const archiveReconciliation = createBankArchiveReconciliation({
    transactions:{reconcile:(...args) => cloud.syncTransactions(...args)},
    images:{sync:(...args) => cloud.syncImages(...args)},
    archive:{read:archive.queries.readSnapshot},authority:scope,
  });
  const connections = createKupaBankConnectionOwner({
    pairing:{read:() => bridge.getBridgeToken(),write:value => bridge.setBridgeToken(value)},
    transport:{readStatus:() => bridge.status(),configure:input => bridge.configureCredentials(input),selectAccount:input => bridge.selectAccount(input),deleteCredentials:() => bridge.deleteCredentials(),readDiagnostics:() => bridge.bankDiagnostics()},
    presentation:{toast:notify,changed:() => { if (!disposed && binding) binding.view.updateBridgePanel(); }},
    effects:{saveJson:(...args) => { ready(); return effects.saveJson(...args); }},
    clock:{now:() => Date.now()},protocol:{minimumBridgeVersion:KUPA_BANK_BRIDGE_MINIMUM_VERSION,statusCacheMs:15000},
  });
  let controller;
  const bankRefresh=createKupaBankRefresh({
    authority:scope,
    cloud:{mode:()=>session.connectionMode,refresh:(...args)=>cloud.refreshFinance(...args),currentState:()=>model.state,
      lastSyncAt:state=>controller.refreshReadout.lastSyncAt(state),checksHaveLocalWork:(...args)=>checks.hasLocalWork(...args)},
    device:{capture:connections.queries.capture,readStatus:connections.queries.readStatus,supported:connections.queries.supported,fetchBalance:options=>bridge.fetchBalance(options)},
    leases:{...syncLeases,createToken:()=>uid('FINLEASE'),reportFailure:error=>console.error('bank sync lease release',error)},
    publication:{prepare:snapshots.commands.prepare,reconcile:archiveReconciliation.commands.sync,
      publishCloud:snapshots.commands.publishCloud,publishLocal:snapshots.commands.publishLocal,readoutWarning:BANK_READOUT_WARNING},
    policy:createKupaBankSnapshotPolicy({
      feeds:{normalize:normalizeBankFeed,recurringHistory:bankRecurringDebitHistoryData,roundMoney:wholeMoney},
      source:{readBank:()=>model.state.bank&&typeof model.state.bank==='object'?model.state.bank:{},observedSequence:()=>readout.observedCheckSequence()},
      identity:{now:()=>new Date().toISOString(),today:todayISO,createToken:()=>uid('BANK')},
    }),
    automation:{due:bankAutoRefreshDue,markAttempt:()=>bridge.markAutoAttempt()},
  });
  controller = createDomainsBankController({
    model, session, bridge, operationScope:scope, archive, snapshots, connections,bankRefresh,
    timers:platform.timers ?? globalThis, autoScope:() => disposed ? null : authority.automaticAccess(),
    toast:notify, render,
    acknowledgeBankTransactionMissing:(...args) => cloud.acknowledgeMissing(...args),
  });
  function enter(method, ...args) {
    if (disposed) return Promise.resolve(false);
    ready();
    return controller[method](...args);
  }
  function viewCall(method, ...args) {
    if (disposed) return false;
    const result = ready().view[method](...args);
    if (result?.then) {
      const tracked = Promise.resolve(result);
      pending.add(tracked);
      tracked.then(() => pending.delete(tracked), () => pending.delete(tracked));
    }
    return result;
  }
  const commands = Object.fromEntries([
    'refreshBankBalance', 'retryLocalBankSnapshot', 'saveBankBridgeToken', 'configureBankBridge',
    'selectBankBridgeAccount', 'deleteBankBridgeCredentials', 'exportBankChequeDiagnostics', 'acknowledgeMissingBankTransaction',
  ].map(method => [method, (...args) => enter(method, ...args)]));
  commands.setBankAutoRefresh = enabled => { if (disposed) return false; ready(); return controller.setBankAutoRefresh(enabled); };
  const presentation = Object.fromEntries([
    'renderBank', 'openCashflowBreakdown', 'openBankChequeImage', 'setBankAccountView', 'setBankDataView',
    'setBankSearch', 'setBankDateMode', 'setBankDateBoundary', 'toggleBankSyncOptions',
  ].map(method => [method, (...args) => viewCall(method, ...args)]));
  const queries = {
    snapshot:() => { ready(); return controller.bankBridgeUiState(); },
    localSnapshot:() => { ready(); return controller.bankLocalSnapshotState(); },
    ensureDisplayArchive:(...args) => enter('ensureBankDisplayArchive', ...args),
    refreshStatus:(...args) => enter('refreshBankBridgeStatus', ...args),
  };

  function bindUi({ui, modal, date, toast, render:renderView, runFinance, importConnections}) {
    if (disposed) throw new Error('kupa_bank_disposed');
    if (binding) throw new Error('kupa_bank_ui_already_bound');
    requireMethods('modal', modal, ['modal', 'closeModal']);
    requireMethods('date', date, ['dateEditorMarkup']);
    if (!ui || [toast, renderView, runFinance].some(method => typeof method !== 'function')) {
      throw new TypeError('kupa_bank_ui_commands_required');
    }
    requireMethods('import_commands',importConnections?.commands,['importConnections']);
    requireMethods('import_runtime',importConnections?.runtime,['isPending','drain','dispose']);
    const forms = createBankConnectionForms({commands,readPairing:connections.queries.snapshot,isActive:() => !disposed});
    const view = createDomainsBankView({
      bindConnectionForms:forms.bind,
      model, ui, runFinance, isActive:() => !disposed,
      modal:(...args) => { if (!disposed) return modal.modal(...args); }, closeModal:(...args) => { if (!disposed) return modal.closeModal(...args); },
      bankHomeBalance:(...args) => readout.balance('home', ...args),
      bankNextCycleCommitments:(...args) => readout.forecast('business', ...args),
      bankHomeNextCycleCommitments:(...args) => readout.forecast('home', ...args),
      bankBridgeUiState:queries.snapshot, refreshBankBridgeStatus:queries.refreshStatus,
      ensureBankDisplayArchive:queries.ensureDisplayArchive,
      downloadBankChequeImage:(date, key) => cloud.downloadImage(date, key, {assertCurrent:scope.captureRead()}),
      dateEditorMarkup:date.dateEditorMarkup,
    });
    const search = createLazyDeferredSearchUpdater(value => { if (!disposed) ui.bankSearchValue = value; }, presentation.setBankSearch);
    const actions = createBankActions({bankCommands:commands, bankPresentation:presentation, connectionForms:forms, importFinanceConnections:importConnections.commands.importConnections, ui, toast:notify, search});
    binding = {view, forms, importConnections, toast, render:renderView, search, actions:Object.fromEntries(Object.entries(actions).map(([name, handler]) =>
      [name, (...args) => disposed ? false : handler(...args)]))};
  }
  const runtime = {
    isActive:() => !disposed,
    start() { if (disposed) return false; ready(); return controller.startAutoSync(); },
    stop:controller.stopAutoSync,
    wake() { if (disposed) return false; ready(); return controller.maybeAutoRefreshBankBalance(); },
    isPending:() => controller.runtime.isPending() || archiveReconciliation.runtime.isPending() || connections.runtime.isPending() || !!binding?.importConnections.runtime.isPending() || pending.size > 0,
    async drain() { do { await Promise.all([controller.runtime.drain(),archiveReconciliation.runtime.drain(),connections.runtime.drain(),archive.runtime.drain(),binding?.importConnections.runtime.drain(),Promise.allSettled([...pending])]); } while(runtime.isPending()); },
    dispose() {
      if (disposed) return false;
      disposed = true;
      archiveReconciliation.runtime.dispose();
      binding?.importConnections.runtime.dispose();
      controller.runtime.dispose();
      connections.runtime.dispose();
      archive.runtime.dispose();
      binding?.search.cancel();
      binding?.view.runtime.dispose();
      binding?.forms.runtime.dispose();
      effects.dispose();
      return true;
    },
  };
  return {bindUi, commands, queries, presentation, runtime,
    assertReady:() => { ready(); return true; }, actionPack:() => ({name:'bank', actions:ready().actions})};
}
