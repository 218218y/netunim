import {evidenceDate} from '../../shared/observation-time.js';
import {withFinanceDerivations} from '../../shared/finance-derivations.js';
import {updateCashflowExplorer,cashflowExplorerMarkup,cashflowBreachMarkup} from '../../shared/cashflow-breakdown.js';
import {kupaAccountCashflowData,kupaBankCreditSettlementIdentitiesData} from '../../shared/kupa-cashflow.js';
import {esc} from '../../core/values.js';
import {money, moneyWithCents} from '../../core/money.js';
import {readBankMoney} from '../../shared/bank-money-value.js';
import {dateFmt} from '../../core/dates.js';
import {syncEventCurrent} from '../../shared/sync-status.js';
import {dateInRange,searchMatch} from '../../core/search.js';
import {localSearchMarkup} from '../../ui-primitives/local-search.js';
import {bankTransactionIdentity} from './feed.js';
import {bankSmartHistoryRows} from '../../shared/bank-transaction-order.js';
import {bankChequeImageDownloadName,bankChequeImageWithinRetention,retainBankChequeImagePreviewUrl} from '../../shared/bank-cheque-images.js';
import {bankLocalSnapshotNotice} from './local-snapshot-view.js';

export function createDomainsBankView({bindConnectionForms,isActive=()=>true,runFinance=withFinanceDerivations, modal,closeModal,model,ui,bankHomeBalance,bankNextCycleCommitments,bankHomeNextCycleCommitments,bankBridgeUiState,refreshBankBridgeStatus,ensureBankDisplayArchive=async()=>false,downloadBankChequeImage=async()=>null,dateEditorMarkup}){
let releasePreview=null;
function accountLabel(branch,account){return branch&&account?`סניף ${branch} · חשבון ${account}`:account?`חשבון ${account}`:''}
function bridgeStatusText(s){
  if(s.busy&&!s.resultReady)return s.message||'מתבצע עדכון מול Bank Bridge…';
  if(!s.tokenConfigured)return 'החיבור המקומי עדיין לא הותאם למחשב זה.';
  if(s.upgradeRequired)return s.message||'נדרש לשדרג את Bank Bridge במחשב זה.';
  if(s.available===false)return s.availabilityError||'Bank Bridge המקומי אינו זמין.';
  if(s.available===true&&s.configured){
    const business=accountLabel(s.businessBranchNumber||s.branchNumber,s.businessAccountNumber||s.accountNumber),home=accountLabel(s.homeBranchNumber,s.homeAccountNumber);
    return `Bank Bridge מחובר${business?` · עסקי: ${business}`:''}${home?` · ביתי: ${home}`:' · חשבון ביתי טרם הוגדר'}`;
  }
  if(s.available===true)return 'Bank Bridge פעיל, אך עדיין לא נשמרו בו פרטי בנק הפועלים.';
  return s.message||'בודק את החיבור המקומי…';
}

function syncTimeLabel(value){
  if(!value)return 'טרם בוצע עדכון מוצלח מהבנק';
  const d=new Date(value);if(!Number.isFinite(d.getTime()))return 'זמן עדכון לא זמין';
  return `${d.toLocaleDateString('he-IL')} · ${d.toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'})}`;
}

function bankDateLabel(value){
  if(!value)return '—';
  const d=new Date(value);if(!Number.isFinite(d.getTime()))return '—';
  const weekday=['א׳','ב׳','ג׳','ד׳','ה׳','ו׳','ש׳'][d.getDay()]||'';
  const dd=String(d.getDate()).padStart(2,'0'),mm=String(d.getMonth()+1).padStart(2,'0'),yy=String(d.getFullYear()).slice(-2);
  return `${weekday} ${dd}/${mm}/${yy}`;
}

function bankRowMatchesSearch(row,query){return searchMatch(query,[row?.date,row?.processedDate,bankDateLabel(row?.date||row?.processedDate),row?.description,row?.memo,row?.amount,row?.balanceAfter,row?.bankReference,row?.status,row?.presenceState,row?.missingSince,row?.lastSeenAt,JSON.stringify(row?.checkDetails||{}),JSON.stringify(row?.creditSettlementDetails||{})],[row?.date,row?.processedDate])}
function bankMissingActive(row){return row?.presenceState==='missing'&&!row?.missingAcknowledgedAt}
function bankDataMode(){return ui.bankDataView==='direct'?'direct':'history'}
function bankSmartRows(rows,directRows=[]){return bankSmartHistoryRows(rows,{directTransactions:directRows,isMissingActive:bankMissingActive})}
function bankPresenceTime(value){if(!value)return '—';const d=new Date(value);return Number.isFinite(d.getTime())?`${d.toLocaleDateString('he-IL')} · ${d.toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'})}`:'—'}
function bankDataViewToggleMarkup(){const mode=bankDataMode(),direct=mode==='direct',current=direct?'עדכני מהבנק':'היסטוריה חכמה',next=direct?'history':'direct',nextLabel=direct?'היסטוריה חכמה':'עדכני מהבנק',shortLabel=direct?'מהבנק':'חכם',icon=direct?'↻':'✦';return `<button type="button" class="bank-data-view-toggle ${direct?'direct':'history'}" data-action="set-bank-data-view" data-click-arg0="${next}" aria-label="תצוגה נוכחית: ${current}. לחץ למעבר אל ${nextLabel}" title="${current} · לחץ למעבר אל ${nextLabel}"><span class="bank-data-view-toggle-icon" aria-hidden="true">${icon}</span><span>${shortLabel}</span><span class="bank-data-view-toggle-swap" aria-hidden="true">⇄</span></button>`}
function bankDirectSnapshotNote(snapshot){if(!snapshot)return `<div class="bank-direct-snapshot-note empty-state"><b>עדיין אין צילום תנועות מלא ומאומת מהבנק.</b><span>צילום ישיר יישמר רק לאחר קריאת תנועות מלאה ללא אזהרה; קריאה חלקית לעולם לא תחליף אותו.</span></div>`;return `<div class="bank-direct-snapshot-note"><span><b>נתוני הבנק הישירים האחרונים</b> · ${esc(bankPresenceTime(snapshot.snapshotAt))}</span><small>כיסוי ${esc(snapshot.coverageFrom)} עד ${esc(snapshot.coverageTo)} · ${esc(snapshot.transactionCount)} תנועות. סנכרון חלקי אינו מחליף צילום זה.</small></div>`}
function bankMissingSummary(rows) { const active = (Array.isArray(rows) ? rows : []).filter(bankMissingActive), cheques = active.filter(row => row.cheque); if (!active.length)
    return ''; return `<div class="bank-missing-summary"><span class="bank-missing-summary-icon" aria-hidden="true">!</span><div><b>${esc(active.length)} תנועות אינן מופיעות בסריקת הבנק המלאה האחרונה${cheques.length ? ` · מתוכן ${esc(cheques.length)} הפקדות צ׳קים` : ''}</b><small>הן הועלו לראש הרשימה. כל עוד לא אושרו הן נשארות לבדיקה גם אחרי סנכרונים נוספים; סימון „נבדק” מסתיר אותן מההיסטוריה החכמה אך משאיר תיעוד בארכיון.</small></div></div>`; }
function bankMissingDetailMarkup(row){if(!bankMissingActive(row))return '';const title=row.cheque?'הפקדת צ׳ק לא מופיעה בסריקת הבנק האחרונה':'התנועה לא מופיעה בסריקת הבנק האחרונה';return `<div class="bank-missing-detail"><div><b>${esc(title)}</b><small>נראתה לאחרונה: ${esc(bankPresenceTime(row.lastSeenAt))} · חסרה מאז: ${esc(bankPresenceTime(row.missingSince))}</small></div>${row.archiveId?`<button type="button" class="btn bank-missing-ack" data-action="ack-bank-missing" data-click-arg0="${esc(row.archiveId)}">נבדק — הסר התראה</button>`:''}</div>`}
function bankDateFilterActive(){return ui.bankDateMode==='range'}
function bankRowMatchesDateRange(row){return !bankDateFilterActive()||dateInRange(row?.date||row?.processedDate,ui.bankDateFrom||'',ui.bankDateTo||'')}
function dateInput(value,key){return dateEditorMarkup('',value,{data:{[key]:''},compact:true})}
function bankDateFilterMarkup(){const range=bankDateFilterActive(),label=range?'טווח תאריכים':'כל התנועות';return `<details class="bank-date-filter" data-dismiss-on-outside><summary class="bank-date-filter-trigger" aria-label="סינון תנועות הבנק לפי תאריך"><span>${label}</span><span class="bank-date-filter-chevron" aria-hidden="true">⌄</span></summary><div class="bank-date-menu" data-menu-panel><button type="button" class="bank-date-menu-all ${range?'':'active'}" data-action="bank-date-mode" data-click-arg0="all"><span>כל התנועות</span>${range?'':'<b aria-hidden="true">✓</b>'}</button><div class="bank-date-range-card ${range?'active':''}"><div class="bank-date-range-title"><span>טווח תאריכים</span>${range?'<b aria-hidden="true">✓</b>':''}</div><div class="bank-date-range-fields" data-menu-keep-open><div class="bank-date-range-field"><span>מ־</span>${dateInput(ui.bankDateFrom||'','bank-date-from')}</div><div class="bank-date-range-field"><span>עד</span>${dateInput(ui.bankDateTo||'','bank-date-to')}</div></div><button type="button" class="btn primary bank-date-apply" data-action="bank-date-apply">החל</button></div></div></details>`}

function currentBankError(s){if(s?.localSnapshot&&s.localSnapshot.phase!=='saving')return s.localSnapshot.message;return s?.lastError&&syncEventCurrent(s.lastErrorAt,s.sharedLastSyncAt)?s.lastError:''}
function currentBankWarning(s){return !s?.localSnapshot&&s?.lastWarning&&syncEventCurrent(s.lastScrapeAt,s.sharedLastSyncAt)?s.lastWarning:''}
function bankSyncHeadlineState(s){
  const lastSync=s?.sharedLastSyncAt,lastFailure=s?.lastErrorAt,error=currentBankError(s),warning=currentBankWarning(s);
  if(s?.localSnapshot)return {tone:s.localSnapshot.phase==='saving'?'busy':'error',icon:'!',title:s.localSnapshot.phase==='saving'?'ממתין לשמירה':'לא אושר',meta:'צילום זמני'};
  if(s?.busy&&!s?.resultReady)return {tone:'busy',icon:'↻',title:'מסנכרן',meta:'כעת'};
  if(s?.upgradeRequired)return {tone:'error',icon:'!',title:'נדרש עדכון',meta:`Bridge v${String(s.bridgeVersion||'?')}`};
  if(error)return {tone:'error',icon:'!',title:'נכשל',meta:lastFailure?syncTimeLabel(lastFailure):'זמן הכשל לא זמין'};
  if(warning&&lastSync)return {tone:'warn',icon:'!',title:'הושלם חלקית',meta:syncTimeLabel(lastSync)};
  if(lastSync)return {tone:'ok',icon:'✓',title:'הצליח',meta:syncTimeLabel(lastSync)};
  if(!s?.tokenConfigured)return {tone:'idle',icon:'•',title:'טרם הוגדר',meta:'לחץ להגדרה'};
  if(s?.available===false)return {tone:'error',icon:'!',title:'לא זמין',meta:s?.availabilityErrorAt?syncTimeLabel(s.availabilityErrorAt):'Bridge מקומי'};
  return {tone:'idle',icon:'•',title:'טרם סונכרן',meta:s?.configured?'מוכן לרענון':'נדרשת הגדרה'};
}

function bankSyncHeadlineMarkup(s){
  const state=bankSyncHeadlineState(s);
  return `<span class="bank-sync-state-icon" aria-hidden="true">${esc(state.icon)}</span><span class="bank-sync-state-copy"><b>${esc(state.title)}</b><small>${esc(state.meta)}</small></span>`;
}

function errorStageLabel(stage){
  return ({browser:'פתיחת דפדפן',login:'התחברות',session:'הכנת שירותי הבנק',account:'בחירת חשבון',data:'קריאת נתוני החשבון',balance:'קריאת יתרה',transactions:'קריאת תנועות'}[stage]||'');
}

function bankAccountChoicesMarkup(accounts,role=''){
  const rows=Array.isArray(accounts)?accounts:[],targetRole=role==='home'?'home':'business';
  if(!rows.length)return '';
  const roleLabel=targetRole==='home'?'הביתי':'העסקי';
  return `<div class="bank-account-choices"><div class="bank-account-choices-title"><b>החשבונות הפעילים שהבנק החזיר</b><small>בחר את החשבון ${roleLabel}. הבחירה נשמרת רק ב-Bridge המקומי.</small></div><div class="bank-account-choice-list">${rows.map(row=>{
    const branch=String(row?.branchNumber||''),account=String(row?.accountNumber||''),bank=String(row?.bankNumber||'12');
    if(!branch||!account)return '';
    return `<button type="button" class="bank-account-choice" data-action="select-bank-bridge-account" data-click-arg0="${esc(targetRole)}" data-click-arg1="${esc(branch)}" data-click-arg2="${esc(account)}"><span>סניף <b>${esc(branch)}</b></span><span>חשבון <b>${esc(account)}</b></span><small>מזהה API: ${esc(bank)}-${esc(branch)}-${esc(account)}</small></button>`;
  }).join('')}</div></div>`;
}

function bankBridgeDiagnosticsMarkup(s){
  const stage=errorStageLabel(s?.lastErrorStage),role=s?.accountSelectionRole==='home'?'הביתי':s?.accountSelectionRole==='business'?'העסקי':'',currentError=currentBankError(s),currentWarning=currentBankWarning(s);
  const error=currentError?`<div class="bank-sync-detail error"><b>העדכון האחרון נכשל${stage?` בשלב: ${esc(stage)}`:''}${role?` · החשבון ${role}`:''}</b><span>${esc(currentError)}</span>${s.lastErrorCode||s.lastErrorHttpStatus?`<small>${s.lastErrorCode?`קוד: ${esc(s.lastErrorCode)}`:''}${s.lastErrorCode&&s.lastErrorHttpStatus?' · ':''}${s.lastErrorHttpStatus?`HTTP מהבנק: ${esc(s.lastErrorHttpStatus)}`:''}</small>`:''}${s.availableAccounts?.length?'<small>פתח את הגדרות החיבור למטה כדי לבחור את החשבון המדויק.</small>':''}</div>`:'';
  const availability=s?.availabilityError?`<div class="bank-sync-detail warn"><b>Bank Bridge המקומי אינו זמין כרגע</b><span>${esc(s.availabilityError)}</span><small>זו בדיקת זמינות במחשב הזה; היא אינה מבטלת סינכרון חדש יותר שכבר נשמר בענן.</small></div>`:'';
  const homePartial=currentWarning&&s?.accountSelectionRole==='home'&&s?.lastWarningCode;
  const warning=currentWarning?homePartial?`<div class="bank-sync-detail warn"><b>החשבון העסקי נשמר; החשבון הביתי לא עודכן${s.lastWarningStage?` בשלב: ${esc(errorStageLabel(s.lastWarningStage))}`:''}</b><span>${esc(currentWarning)}</span><small>קוד: ${esc(s.lastWarningCode)}${s.lastWarningHttpStatus?` · HTTP מהבנק: ${esc(s.lastWarningHttpStatus)}`:''}</small>${s.availableAccounts?.length?'<small>בחר למטה את החשבון הביתי המדויק מתוך החשבונות הפעילים שהבנק החזיר.</small>':''}</div>`:`<div class="bank-sync-detail warn"><b>היתרות נשמרו, אך קיימת אזהרה לגבי התנועות</b><span>${esc(currentWarning)}</span></div>`:'';
  return error+availability+warning;
}


function bankChequeImageButtons(row, item) { if (!bankChequeImageWithinRetention(row?.date || row?.processedDate))
    return item.hasDocumentReference ? 'קיים בבנק' : '—'; const buttons = []; if (item.imageFrontKey)
    buttons.push(`<button type="button" class="btn bank-cheque-image-btn" data-action="view-bank-cheque-image" data-click-arg0="${esc(row?.date || row?.processedDate || '')}" data-click-arg1="${esc(item.imageFrontKey)}" data-click-arg2="חזית">חזית</button>`); if (item.imageBackKey)
    buttons.push(`<button type="button" class="btn bank-cheque-image-btn" data-action="view-bank-cheque-image" data-click-arg0="${esc(row?.date || row?.processedDate || '')}" data-click-arg1="${esc(item.imageBackKey)}" data-click-arg2="גב">גב</button>`); return buttons.length ? `<span class="bank-cheque-image-actions">${buttons.join('')}</span>` : item.hasDocumentReference ? 'קיים בבנק' : '—'; }
async function openBankChequeImage(eventDate,imageKey,label='תמונת שיק'){
  if(!isActive())return false;
  const blob=await downloadBankChequeImage(eventDate,imageKey);
  if(!isActive())return false;
  if(!blob)throw new Error('תמונת השיק אינה זמינה בענן (ייתכן שהיא מחוץ לחלון השמירה או שהאחסון טרם הוכן).');
  releasePreview?.();releasePreview=null;
  const url=URL.createObjectURL(blob),filename=bankChequeImageDownloadName(eventDate,label,blob.type);
  try{
    modal(`שיק · ${label}`,`<div class="bank-cheque-image-preview"><img src="${esc(url)}" alt="${esc(label)}"></div>`,'הורד תמונה',()=>{
      if(!isActive())return;
      const link=document.createElement('a');link.href=url;link.download=filename;link.click();
    });
    const img=document.querySelector('.bank-cheque-image-preview img'),backdrop=document.getElementById('modalBackdrop');
    releasePreview=retainBankChequeImagePreviewUrl(url,{image:img,backdrop});
  }catch(error){URL.revokeObjectURL(url);throw error}
  return true;
}

function bankCreditSettlementDetailsMarkup(row,identity={}){
  const details=row?.creditSettlementDetails&&typeof row.creditSettlementDetails==='object'?row.creditSettlementDetails:null;if(!details)return '';
  const facts=[],cards=identity.last4s||[];
  if(details.providerLabel)facts.push(`<span><b>חברת אשראי:</b> ${esc(details.providerLabel)}</span>`);
  if(cards.length)facts.push(`<span><b>${cards.length===1?'כרטיס':'כרטיסים'}:</b> ${cards.map(value=>`•••• ${esc(value)}`).join(', ')}</span>`);
  if(cards.length&&identity.source&&identity.source!=='bank_detail_explicit'){
    const bankDerived=['bank_permission_suffix_validated','bank_identifier_suffix_validated','legacy_bank_reference_validated'].includes(identity.source);
    facts.push(`<span><b>זיהוי כרטיס:</b> ${bankDerived?'4 הספרות האחרונות זוהו מנתוני הבנק ואומתו מול הכרטיס המסונכרן':'אומת מול מחזור החיוב המסונכרן מחברת האשראי'}</span>`);
  }
  if(details.permissionReference)facts.push(`<span><b>מזהה הרשאת חיוב בבנק:</b> ${esc(details.permissionReference)}</span>`);
  if(details.issuerReference)facts.push(`<span><b>אסמכתת חיוב בבנק:</b> ${esc(details.issuerReference)}</span>`);
  if(!facts.length&&!details.warning)return '';
  return `<div class="bank-credit-settlement-info bank-cheque-info">${facts.length?`<div class="bank-cheque-facts">${facts.join('')}</div>`:''}${details.warning?`<div class="bank-feed-warning">${esc(details.warning)}</div>`:''}</div>`;
}

function bankChequeDetailsMarkup(row){
  const details=row?.checkDetails&&typeof row.checkDetails==='object'?row.checkDetails:null;if(!details)return '';
  const kind=['deposit','returned','returned_credit'].includes(details.kind)?details.kind:(row?.cheque?'deposit':'');if(!kind)return '';
  const items=(Array.isArray(details.checkItems)?details.checkItems:[]).filter(item=>item&&Number(item.amount)>0&&(item.checkNumber||(item.bankNumber&&item.branchNumber&&item.accountNumber)));
  const numbers=[...new Set((Array.isArray(details.checkNumbers)?details.checkNumbers:[]).filter(x=>x&&x!=='0'))];
  const count=Number(details.checkCount),facts=[];
  if(kind==='deposit'){
    if(items.length>1)facts.push(`<span><b>שיקים בהפקדה:</b> ${esc(items.length)}</span>`);
    else if(Number.isFinite(count)&&count>1)facts.push(`<span><b>שיקים בהפקדה:</b> ${esc(Math.trunc(count))}</span>`);
  }
  const rowNumbers=new Set(items.map(item=>String(item.checkNumber||'').trim()).filter(Boolean)),unassignedNumbers=numbers.filter(number=>!rowNumbers.has(String(number)));
  if(!items.length&&numbers.length)facts.push(`<span><b>${numbers.length===1?'מספר שיק':'מספרי שיקים'}:</b> ${numbers.map(x=>esc(x)).join(', ')}</span>`);
  else if(unassignedNumbers.length)facts.push(`<span><b>מספרי שיקים שלא שויכו לשורה:</b> ${unassignedNumbers.map(x=>esc(x)).join(', ')}</span>`);
  if(row.bankReference&&row.bankReference!=='0')facts.push(`<span><b>${kind==='deposit'?'אסמכתת הפקדה':'אסמכתא'}:</b> ${esc(row.bankReference)}</span>`);
  const table=items.length?`<div class="bank-cheque-items-wrap"><table class="bank-cheque-items"><thead><tr><th>בנק</th><th>סניף</th><th>חשבון</th><th>מס׳ שיק</th><th>סכום</th><th>מסמך</th></tr></thead><tbody>${items.map(item=>`<tr><td>${esc(item.bankNumber||'—')}</td><td>${esc(item.branchNumber||'—')}</td><td>${esc(item.accountNumber||'—')}</td><td class="bank-cheque-number">${esc(item.checkNumber||'—')}</td><td class="bank-cheque-amount">${moneyWithCents(Number(item.amount))}</td><td>${bankChequeImageButtons(row,item)}</td></tr>`).join('')}</tbody></table></div>`:'';
  const documentNote=!items.length&&details.hasDocumentReference?'<div class="bank-cheque-document-note">הבנק מציין שקיים מסמך/צילום עבור השיק, אך כתובת המסמך אינה נשמרת בקופה.</div>':'';
  const warning=details.warning?`<div class="bank-cheque-detail-warning">${esc(details.warning)}</div>`:'';
  if(!facts.length&&!table&&!documentNote&&!warning)return '';
  return `<div class="bank-cheque-info" data-cheque-kind="${esc(kind)}">${facts.length?`<div class="bank-cheque-facts">${facts.join('')}</div>`:''}${table}${documentNote}${warning}</div>`;
}

function bankTransactionsTableMarkup(feed,role){
  const mode=bankDataMode(),directSnapshot=feed?.directSnapshot||null,historyRows=bankSmartRows(feed?.transactions||[],directSnapshot?.transactions||[]),allRows=mode==='direct'?(directSnapshot?.transactions||[]):historyRows,periodRows=allRows.filter(bankRowMatchesDateRange),query=ui.bankSearchValue||'',rows=query.trim()?periodRows.filter(row=>bankRowMatchesSearch(row,query)):periodRows,balance=readBankMoney(feed?.balance);
  const scoped=bankDateFilterActive()||query.trim(),countLabel=scoped?`${rows.length} מתוך ${allRows.length} תנועות`:`${rows.length} תנועות`;
  const available=readBankMoney(feed?.availableBalance),limit=readBankMoney(feed?.creditLimit),difference=Number.isFinite(balance)&&Number.isFinite(available)?available-balance:null;
  const roleName=role==='home'?'ביתי':'עסקי',cashflow=kupaAccountCashflowData(model.state,roleName),facts=[];
  if(Number.isFinite(balance))facts.push(`<span class="bank-primary-balance"><span>יתרה ${roleName}</span><b>${moneyWithCents(balance)}</b></span>`);
  if(Number.isFinite(available))facts.push(`<span class="bank-available-balance"><span>למשיכה</span><b>${moneyWithCents(available)}</b>${Number.isFinite(difference)?`<span class="bank-balance-delta" title="הפרש בין היתרה ליתרה הזמינה למשיכה">(${moneyWithCents(difference)})</span>`:''}</span>`);
  if(Number.isFinite(limit)&&limit>0)facts.push(`<span class="bank-credit-limit-balance"><span>מסגרת</span><b>${moneyWithCents(limit)}</b></span>`);
  if(cashflow.projected!==null)facts.push(`<button type="button" data-action="cashflow-breakdown" data-click-arg0="${role}" aria-haspopup="dialog" class="bank-cashflow-metric bank-cashflow-projected ${cashflow.breach.breachDate?'bank-cashflow-alert':''} ${cashflow.forecastIncomplete?'bank-cashflow-incomplete':''}"><span>עו״ש תזרימי (${esc(dateFmt(cashflow.targetDate))})${cashflow.forecastIncomplete?' · חלקי':''}</span><b>${moneyWithCents(cashflow.projected)}</b></button>`);
  const balanceFacts=facts.length?`<div class="bank-compact-balance">${facts.map((fact,index)=>`${index?'<span class="bank-balance-separator" aria-hidden="true"></span>':''}${fact}`).join('')}</div>`:'';
  const accountTitle=feed?.accountNumber?`חשבון ${roleName} ${esc(feed.accountNumber)}`:`חשבון ${roleName}`;
  const caption=`<div class="bank-transactions-caption"><div class="bank-caption-account"><b>${accountTitle}</b><small>${countLabel}</small>${bankDateFilterMarkup()}${bankDataViewToggleMarkup()}</div><div class="bank-caption-controls">${balanceFacts}</div></div>${cashflow.breach.breachDate?`<div class="bank-cashflow-warning-row">${cashflowBreachMarkup(cashflow)}</div>`:''}`;
  const context=mode==='direct'?bankDirectSnapshotNote(directSnapshot):bankMissingSummary(historyRows);
  if(!feed)return `${caption}${context}<div class="empty bank-feed-empty">${role==='home'?'החשבון הביתי עדיין לא סונכרן. הגדר אותו בחיבור לבנק ולחץ „רענן”.':'לא בוצע עדיין סנכרון בנק שמכיל תנועות.'}</div>`;
  if(mode==='direct'&&!directSnapshot)return `${caption}${context}`;
  if(!rows.length){const empty=periodRows.length&&query.trim()?'אין תנועות המתאימות לחיפוש בתקופה שנבחרה.':allRows.length&&bankDateFilterActive()?'אין תנועות בטווח התאריכים שנבחר.':'לא התקבלו תנועות בנק להצגה.';return `${caption}${context}<div class="empty bank-feed-empty">${empty}${feed.transactionWarning?`<div class="bank-feed-warning">${esc(feed.transactionWarning)}</div>`:''}</div>`}
  const creditIdentities=kupaBankCreditSettlementIdentitiesData(model.state,rows,role==='home'?'ביתי':'עסקי');
  const searchSource=mode==='direct'?(directSnapshot?.transactions||[]):(feed.transactions||[]);
  const searchIndexes=new Map(searchSource.map((row,index)=>[row,index]));
  const body=rows.map((row,index)=>{
    const searchId=bankTransactionIdentity(row,role,searchIndexes.get(row)??index);
    const amount=readBankMoney(row.amount),balanceAfter=readBankMoney(row.balanceAfter),when=row.date||row.processedDate,valueDate=row.processedDate&&row.processedDate!==row.date?bankDateLabel(row.processedDate):'',activeMissing=mode==='history'&&bankMissingActive(row);
    return `<tr class="${row.status==='pending'?'pending ':''}${activeMissing?'bank-transaction-missing active':''}" data-bank-search-id="${esc(searchId)}"><td class="bank-transaction-date"><b>${esc(bankDateLabel(when))}</b>${valueDate?`<small>ערך ${esc(valueDate)}</small>`:''}</td><td class="bank-transaction-description"><div><b>${esc(row.description||'תנועת בנק')}</b>${row.status==='pending'?'<span class="bank-transaction-pending">ממתינה</span>':''}${activeMissing?'<span class="bank-transaction-missing-badge">דורש בדיקה</span>':''}</div>${row.memo?`<small>${esc(row.memo)}</small>`:''}${activeMissing?bankMissingDetailMarkup(row):''}${bankCreditSettlementDetailsMarkup(row,creditIdentities.get(row))}${bankChequeDetailsMarkup(row)}</td>${amount===null?'<td colspan="2" class="bank-transaction-money unknown">סכום לא ידוע</td>':`<td class="bank-transaction-money debit">${amount<0?money(Math.abs(amount)):''}</td><td class="bank-transaction-money credit">${amount>=0?money(amount):''}</td>`}<td class="bank-transaction-money balance-after">${balanceAfter===null?'—':money(balanceAfter)}</td></tr>`;
  }).join('');
  return `${caption}${context}<div class="bank-transactions-table-wrap"><table class="bank-transactions-table"><thead><tr><th>תאריך</th><th>פעולה</th><th>חובה</th><th>זכות</th><th>יתרה לאחר תנועה</th></tr></thead><tbody>${body}</tbody></table></div>${feed.transactionWarning?`<div class="bank-feed-warning">${esc(feed.transactionWarning)}</div>`:''}`;
}

function bankAccountTabsMarkup(){
  const active=ui.bankAccountView==='home'?'home':'business';
  return `<span class="bank-account-tabs bank-sync-account-tabs" role="tablist" aria-label="בחירת חשבון לתצוגה"><button type="button" role="tab" aria-selected="${active==='business'}" class="bank-account-tab ${active==='business'?'active':''}" data-action="set-bank-account-view" data-click-arg0="business">חשבון עסקי</button><button type="button" role="tab" aria-selected="${active==='home'}" class="bank-account-tab ${active==='home'?'active':''}" data-action="set-bank-account-view" data-click-arg0="home">חשבון ביתי</button></span>`;
}

function bankHeaderCashflowMarkup(){
  const role=ui.bankAccountView==='home'?'home':'business',roleName=role==='home'?'ביתי':'עסקי',cashflow=kupaAccountCashflowData(model.state,roleName),amount=moneyWithCents(cashflow.expectedChange);
  return `<button id="bankHeaderCashflow" type="button" class="bank-header-cashflow bank-cashflow-metric ${cashflow.expectedChange>0?'positive':cashflow.expectedChange<0?'negative':''} ${cashflow.forecastIncomplete?'bank-cashflow-incomplete':''}" data-action="cashflow-breakdown" data-click-arg0="${role}" aria-haspopup="dialog" title="פתח פירוט של כל הסכומים והמועדים המרכיבים את השינוי הצפוי"><span>שינוי צפוי</span><b>${amount}</b></button>`;
}

function syncBankHeaderCashflow(){const current=document.getElementById('bankHeaderCashflow');if(current)current.outerHTML=bankHeaderCashflowMarkup()}

function bankTransactionsMarkup(s=bankBridgeUiState()){
  const active=ui.bankAccountView==='home'?'home':'business',feed=active==='home'?s.homeFeed:s.feed;
  return bankTransactionsTableMarkup(feed,active);
}

function syncBankAccountTabs(){
  const active=ui.bankAccountView==='home'?'home':'business';
  document.querySelectorAll('[data-action="set-bank-account-view"]').forEach(button=>{
    const selected=button.dataset.clickArg0===active;
    button.classList.toggle('active',selected);button.setAttribute('aria-selected',String(selected));
  });
}

function setBankAccountView(role){
  ui.bankAccountView=role==='home'?'home':'business';syncBankAccountTabs();syncBankHeaderCashflow();
  const region=document.querySelector('.bank-transactions-region');if(region)region.innerHTML=bankTransactionsMarkup();
}
function setBankDataView(value){ui.bankDataView=value==='direct'?'direct':'history';rerenderBankTransactions()}
function rerenderBankTransactions(){const region=document.querySelector('.bank-transactions-region');if(region)region.innerHTML=bankTransactionsMarkup()}
function setBankSearch(value){ui.bankSearchValue=String(value||'');rerenderBankTransactions()}
function setBankDateMode(value, from = ui.bankDateFrom || '', to = ui.bankDateTo || '') { if (value !== 'range') {
    ui.bankDateMode = 'all';
    ui.bankDateFrom = '';
    ui.bankDateTo = '';
    return rerenderBankTransactions();
} const valid = x => evidenceDate(x) ? x : '', nextFrom = valid(from), nextTo = valid(to); if (!nextFrom && !nextTo) {
    ui.bankDateMode = 'all';
    ui.bankDateFrom = '';
    ui.bankDateTo = '';
    return rerenderBankTransactions();
} ui.bankDateMode = 'range'; if (nextFrom && nextTo && nextFrom > nextTo) {
    ui.bankDateFrom = nextTo;
    ui.bankDateTo = nextFrom;
}
else {
    ui.bankDateFrom = nextFrom;
    ui.bankDateTo = nextTo;
} rerenderBankTransactions(); }
function setBankDateBoundary(side,value){const key=side==='to'?'bankDateTo':'bankDateFrom',other=side==='to'?'bankDateFrom':'bankDateTo',next=evidenceDate(value)?value:'';ui.bankDateMode='range';ui[key]=next;if(next&&ui[other]){if(side==='from'&&next>ui[other])ui.bankDateTo=next;if(side==='to'&&next<ui[other])ui.bankDateFrom=next}rerenderBankTransactions()}
function toggleBankSyncOptions(){ui.bankSyncOpen=!ui.bankSyncOpen;const panel=document.getElementById('bankSyncPanel'),button=document.getElementById('bankSyncHeadline');if(panel)panel.hidden=!ui.bankSyncOpen;if(button){button.classList.toggle('open',ui.bankSyncOpen);button.setAttribute('aria-expanded',String(ui.bankSyncOpen))}}

function updateBridgePanel(){
  if(!isActive())return;
  const s=bankBridgeUiState(),headline=document.getElementById('bankSyncHeadline'),status=document.getElementById('bankBridgeStatus');
  if(headline){const state=bankSyncHeadlineState(s);headline.innerHTML=`${bankSyncHeadlineMarkup(s)}<span class="bank-sync-chevron" aria-hidden="true">⌄</span>`;headline.className=`bank-sync-toggle ${state.tone} ${ui.bankSyncOpen?'open':''}`;headline.setAttribute('aria-expanded',String(ui.bankSyncOpen))}
  if(status){status.textContent=bridgeStatusText(s);status.className=`bank-sync-status ${s.available===false||currentBankError(s)?'error':s.configured?'ok':''}`}
  const diagnostics=document.getElementById('bankBridgeDiagnostics');if(diagnostics)diagnostics.innerHTML=bankBridgeDiagnosticsMarkup(s);
  const choices=document.getElementById('bankBridgeAccountChoices');if(choices)choices.innerHTML=bankAccountChoicesMarkup(s.availableAccounts,s.accountSelectionRole);
  for(const [id,value] of [['bankBusinessBranchNumberInput',s.businessBranchNumber||s.branchNumber],['bankBusinessAccountNumberInput',s.businessAccountNumber||s.accountNumber],['bankHomeBranchNumberInput',s.homeBranchNumber],['bankHomeAccountNumberInput',s.homeAccountNumber]]){const input=document.getElementById(id);if(input&&document.activeElement!==input&&!input.value)input.value=value||''}
  const refresh=document.querySelector('[data-action="refresh-bank-from-hapoalim"]');if(refresh)refresh.disabled=!!s.busy||!!s.localSnapshot||!s.tokenConfigured||!!s.upgradeRequired;
  const auth=document.querySelector('[data-action="open-bank-auth"]');if(auth)auth.disabled=!!s.busy||!!s.localSnapshot||!s.tokenConfigured||!!s.upgradeRequired;
  const exportDiagnostics=document.querySelector('[data-action="export-bank-cheque-diagnostics"]');if(exportDiagnostics)exportDiagnostics.disabled=!!s.busy||!s.tokenConfigured||!!s.upgradeRequired;
  const remove=document.querySelector('[data-action="delete-bank-bridge-credentials"]');if(remove)remove.disabled=!!s.busy||!s.configured;
  const save=document.querySelector('[data-action="configure-bank-bridge"]');if(save)save.disabled=!!s.busy;
  const pair=document.querySelector('[data-action="save-bank-bridge-token"]');if(pair)pair.disabled=!!s.busy;
  syncBankAccountTabs();
  const region=document.querySelector('.bank-transactions-region');if(region)region.innerHTML=bankTransactionsMarkup(s);
}

function openCashflowBreakdown(role,targetDate='',input=null){const account=role==='home'?'ביתי':'עסקי';if(input)return updateCashflowExplorer(input,date=>kupaAccountCashflowData(model.state,account,undefined,{targetDate:date}));modal(`פירוט שינוי צפוי · ${account}`,cashflowExplorerMarkup(kupaAccountCashflowData(model.state,account,undefined,{targetDate}),'cashflow-breakdown',role,dateEditorMarkup),'סגור',()=>closeModal(true))}

function renderBank(...args){if(!isActive())return false;return runFinance(()=>isActive()?renderBankContent(...args):false)}
function renderBankContent(){
  const cycle=bankNextCycleCommitments(),homeCycle=bankHomeNextCycleCommitments(),homeBank=bankHomeBalance();
  const bridgeUi=bankBridgeUiState(),staleTotal=cycle.elapsedCredit+cycle.elapsedExpenses,homeStaleTotal=homeCycle.elapsedCredit+homeCycle.elapsedExpenses;
  document.getElementById('content').innerHTML=`
  ${bankLocalSnapshotNotice(bridgeUi.localSnapshot,{retry:true})}
  <section class="section bank-sync-section">
    <div class="bank-command-row">
      <div class="bank-view-tools">${bankAccountTabsMarkup()}${localSearchMarkup({value:ui.bankSearchValue||'',placeholder:'חיפוש תנועות…',label:'חיפוש בתנועות הבנק המוצגות',inputAction:'bank-search',className:'bank-search-field'})}${bankHeaderCashflowMarkup()}</div>
      <div class="bank-sync-quick-actions"><button id="bankSyncHeadline" type="button" class="bank-sync-toggle ${bankSyncHeadlineState(bridgeUi).tone} ${ui.bankSyncOpen?'open':''}" data-action="toggle-bank-sync-options" aria-expanded="${ui.bankSyncOpen===true}" aria-controls="bankSyncPanel">${bankSyncHeadlineMarkup(bridgeUi)}<span class="bank-sync-chevron" aria-hidden="true">⌄</span></button><button type="button" class="btn primary bank-sync-refresh" data-action="refresh-bank-from-hapoalim" ${bridgeUi.busy||bridgeUi.localSnapshot||!bridgeUi.tokenConfigured||bridgeUi.upgradeRequired?'disabled':''}>${bridgeUi.busy?(bridgeUi.resultReady?'מסיים…':'מעדכן…'):'רענן'}</button></div>
    </div>
    <div id="bankSyncPanel" class="bank-sync-settings-body" ${ui.bankSyncOpen?'':'hidden'}>
      <div class="bank-sync-settings-top"><div><b>אפשרויות סינכרון</b><small>פתח אימות רק כשהבנק דורש הזדהות מחדש; פירוט מלא של כשל מופיע כאן.</small></div><div class="bank-sync-panel-actions"><button type="button" class="btn" data-action="import-finance-connections" ${bridgeUi.busy||!bridgeUi.tokenConfigured||bridgeUi.upgradeRequired?'disabled':''}>ייבוא בנק + אשראי</button><button type="button" class="btn" data-action="export-bank-cheque-diagnostics" ${bridgeUi.busy||!bridgeUi.tokenConfigured||bridgeUi.upgradeRequired?'disabled':''}>ייצוא אבחון בנק (JSON)</button><button type="button" class="btn" data-action="open-bank-auth" ${bridgeUi.busy||!bridgeUi.tokenConfigured||bridgeUi.upgradeRequired?'disabled':''}>פתח אימות בבנק</button></div></div>
      <div id="bankBridgeDiagnostics">${bankBridgeDiagnosticsMarkup(bridgeUi)}</div>
      <div id="bankBridgeStatus" class="bank-sync-status ${bridgeUi.available===false||bridgeUi.lastError?'error':bridgeUi.configured?'ok':''}">${esc(bridgeStatusText(bridgeUi))}</div>
      <div id="bankBridgeAccountChoices">${bankAccountChoicesMarkup(bridgeUi.availableAccounts,bridgeUi.accountSelectionRole)}</div>
      <div class="bank-connection-forms">
        <form id="bankBridgePairForm" class="bank-sync-form bank-sync-pair-form" autocomplete="off">
          <div class="bank-sync-form-title">חיבור הדפדפן ל-Bridge במחשב הזה</div>
          <label><span>מפתח Bank Bridge</span><input id="bankBridgeTokenInput" name="bankBridgeToken" type="password" autocomplete="off" placeholder="הדבק את המפתח שהעתיקה ההתקנה"></label>
          <button type="button" class="btn" data-action="save-bank-bridge-token" ${bridgeUi.busy?'disabled':''}>שמור מפתח למחשב זה</button>
          <small>${bridgeUi.tokenConfigured?'מפתח מקומי כבר שמור בדפדפן הזה. אפשר להחליף אותו בהדבקת מפתח חדש.':'יש לבצע פעם אחת בכל מחשב/דפדפן.'}</small>
        </form>
        <form id="bankBridgeCredentialsForm" class="bank-sync-form bank-sync-credentials-form" autocomplete="off">
          <div class="bank-sync-form-title">פרטי בנק הפועלים — התחברות אחת, שני חשבונות</div>
          <div class="bank-sync-login-grid"><label><span>קוד משתמש</span><input id="bankUserCodeInput" name="username" type="text" autocomplete="username" spellcheck="false" placeholder="קוד המשתמש לבנק"></label><label><span>סיסמה</span><input id="bankPasswordInput" name="current-password" type="password" autocomplete="current-password" placeholder="הסיסמה נשלחת רק ל-Bridge המקומי"></label></div>
          <div class="bank-account-config-grid">
            <fieldset class="bank-account-config business"><legend>חשבון עסקי — מקור הקופה</legend><label><span>סניף עסקי</span><input id="bankBusinessBranchNumberInput" name="businessBranchNumber" type="text" inputmode="numeric" autocomplete="off" placeholder="לדוגמה 123" value="${esc(bridgeUi.businessBranchNumber||bridgeUi.branchNumber||'')}"></label><label><span>מספר חשבון עסקי</span><input id="bankBusinessAccountNumberInput" name="businessAccountNumber" type="text" inputmode="numeric" autocomplete="off" placeholder="לדוגמה 456789" value="${esc(bridgeUi.businessAccountNumber||bridgeUi.accountNumber||'')}"></label><small>רק יתרת החשבון הזה מעדכנת את צילום העו״ש ואת חישובי הקופה.</small></fieldset>
            <fieldset class="bank-account-config home"><legend>חשבון ביתי — חישובי בית</legend><label><span>סניף ביתי</span><input id="bankHomeBranchNumberInput" name="homeBranchNumber" type="text" inputmode="numeric" autocomplete="off" placeholder="אותו סניף או סניף אחר" value="${esc(bridgeUi.homeBranchNumber||'')}"></label><label><span>מספר חשבון ביתי</span><input id="bankHomeAccountNumberInput" name="homeAccountNumber" type="text" inputmode="numeric" autocomplete="off" placeholder="מספר החשבון הביתי" value="${esc(bridgeUi.homeAccountNumber||'')}"></label><small>היתרה משתתפת בחישובי הבית בלבד; היא לעולם אינה נכנסת לחישובים העסקיים.</small></fieldset>
          </div>
          <div class="bank-sync-form-actions"><button type="button" class="btn" data-action="configure-bank-bridge" ${bridgeUi.busy?'disabled':''}>שמור פרטי הפועלים ושני החשבונות</button><button type="button" class="btn danger-soft" data-action="delete-bank-bridge-credentials" ${bridgeUi.busy||!bridgeUi.configured?'disabled':''}>מחק פרטי התחברות</button></div>
          <small>ה-Bridge משתמש במזהה מלא בנק 12 + סניף + מספר חשבון לכל אחד מהחשבונות. ברענון אחד הוא נכנס פעם אחת לבנק, מאמת ששני החשבונות קיימים, ורק אז קורא את שניהם.</small>
        </form>
      </div>
      <div class="bank-sync-actions"><label class="bank-auto-toggle"><input type="checkbox" data-change="set-bank-auto-refresh" ${bridgeUi.autoEnabled?'checked':''}> <span>עדכון אוטומטי של שני החשבונות פעם ב־4 שעות</span></label></div>
      <div class="soft-note">„רענן” מעדכן את העסקי והביתי באותו סשן בנק. אם החשבון הביתי לא הוגדר, מתעדכן רק העסקי. „פתח אימות בבנק” נדרש רק כשהפועלים מבקש הזדהות מחדש. „ייצוא אבחון בנק” מוריד מהמחשב קובץ JSON מסודר מהסנכרון האחרון: כל סוגי התנועות שנקלטו, השדות הגולמיים שהבנק החזיר, השורה המנורמלת שנכנסת למערכת, סיכום סוגי הפעילות ופירוט שיקים כשקיים. סיסמאות, cookies, tokens, נתוני session, HTML ותוכן בינארי מושחרים; קישורי מסמכי שיק נשמרים רק כמסלול מסונן לצורכי אבחון, והקובץ אינו עולה לענן. הקובץ עדיין עשוי להכיל נתונים פיננסיים ולכן יש לשתף אותו רק במכוון. פרטי ההתחברות נשמרים מוצפנים ורק במחשב המקומי; נתוני החשבונות נשמרים במאגר סינכרון פיננסי נפרד, ותנועות הבנק מתמזגות לארכיון ייעודי שאינו נכלל בגיבויי הקופה.</div>
    </div>
    <div class="bank-transactions-region">${bankTransactionsMarkup(bridgeUi)}</div>
  </section>
  ${staleTotal>0?`<div class="notice warn" style="margin-bottom:16px"><b>צילום העו״ש העסקי ישן ביחס להיום.</b> לצורך חישוב נכון נגרעו גם חיובים עסקיים שכבר עברו מאז הצילום בסך ${money(staleTotal)}. מומלץ לרענן את היתרה מהבנק.</div>`:''}
  ${homeStaleTotal>0&&homeBank!==null?`<div class="notice warn" style="margin-bottom:16px"><b>צילום העו״ש הביתי ישן ביחס להיום.</b> לצורך חישוב נכון נגרעו גם חיובים ביתיים שכבר עברו מאז הצילום בסך ${money(homeStaleTotal)}. מומלץ לרענן את היתרה מהבנק.</div>`:''}
`;
  updateBridgePanel();
  bindConnectionForms();
  refreshBankBridgeStatus({force:false}).then(updateBridgePanel).catch(()=>updateBridgePanel());
  ensureBankDisplayArchive().catch(error=>console.error('bank display archive',error));
}

return {runtime:{dispose(){releasePreview?.();releasePreview=null}},updateBridgePanel,renderBank,openCashflowBreakdown,openBankChequeImage,setBankAccountView,setBankDataView,setBankSearch,setBankDateMode,setBankDateBoundary,toggleBankSyncOptions};
}
