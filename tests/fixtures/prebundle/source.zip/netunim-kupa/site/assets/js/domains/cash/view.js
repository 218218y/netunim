import {esc} from '../../core/values.js';
import {money,moneyWithCents} from '../../core/money.js';
import {dateFmt} from '../../core/dates.js';
import {searchMatch} from '../../core/search.js';
import {localSearchMarkup} from '../../ui-primitives/local-search.js';
import {ledgerTypeLabel} from './model.js';

// Dependencies are supplied by the composition root; this module has no startup side effects.
export function createDomainsCashView({model, ui, cashBalance, rightsBalance, kpi, syncBulkUi, bulkControls, bulkHeader, bulkCell, dateEditorMarkup}){
function visibleLedgerRows(rows){const q=String(ui.cashSearchValue||'').trim();if(!q)return rows;return rows.filter(r=>searchMatch(q,[r.type,r.description,r.note,r.amount],[r.date]))}
function ledgerTable({collection,title,rows,openAction,editAction}){
  const formatAmount=collection==='rights'?moneyWithCents:money;
  const empty=String(ui.cashSearchValue||'').trim()?'אין תנועות המתאימות לחיפוש.':'אין עדיין תנועות בתצוגה הזאת.';
  return `<section class="section cash-ledger-section"><div class="section-head"><div><h3>${esc(title)}</h3><small class="local-search-count">${esc(rows.length)} תנועות</small></div><div class="bulk-actions">${bulkControls(collection)}<button class="btn primary" data-action="${esc(openAction)}">+ תנועה חדשה</button></div></div><div class="table-scroll"><table class="mobile-card-table cash-table"><thead><tr>${bulkHeader(collection)}<th class="cash-col-date">תאריך</th><th class="cash-col-type">סוג</th><th class="cash-col-description">תיאור</th><th class="cash-col-amount">סכום</th><th class="cash-col-note">הערה</th><th class="cash-col-actions"></th></tr></thead><tbody>${rows.length?rows.map(r=>`<tr data-bulk-collection="${esc(collection)}" data-bulk-id="${esc(r.id)}" class="${esc(ui.bulkSelected.has(r.id)?'bulk-selected-row':'')}">${bulkCell(collection,r.id)}<td class="cash-col-date" data-label="תאריך">${dateFmt(r.date)}</td><td class="cash-col-type" data-label="סוג">${esc(ledgerTypeLabel(collection,r.type))}</td><td class="cash-col-description" data-label="תיאור"><b>${esc(r.description)}</b></td><td class="cash-col-amount amount cash-amount ${esc(r.amount<0?'negative':'positive')}" data-label="סכום">${formatAmount(r.amount)}</td><td class="cash-col-note muted" data-label="הערה">${esc(r.note)||'—'}</td><td class="cash-col-actions" data-label="פעולות"><button class="iconbtn" data-action="${esc(editAction)}" data-click-arg0="${esc(r.id)}">עריכה</button></td></tr>`).join(''):`<tr><td colspan="${ui.bulkCollection===collection?7:6}"><div class="empty compact">${empty}</div></td></tr>`}</tbody></table></div></section>`
}
function cashLedgersMarkup(){
  const cashRows=visibleLedgerRows([...model.state.cash].sort((a,b)=>(b.date||'').localeCompare(a.date||'')));
  const rightsRows=visibleLedgerRows([...(model.state.rights||[])].sort((a,b)=>(b.date||'').localeCompare(a.date||'')));
  const rightsKpi=`<div class="rights-kpi-wrap">${kpi('יתרת מעשר',rightsBalance(),'#eef1f8','#7f86a6','מחושב מכל תנועות המעשר',moneyWithCents)}<div class="rights-calculated-date"><span>חושב לאחרונה בתאריך</span>${dateEditorMarkup('',model.state.rightsLastCalculatedDate||'',{label:'תאריך חישוב אחרון של יתרת המעשר',change:'set-rights-last-calculated-date',compact:true})}</div></div>`;
  return `<div class="cash-ledgers"><div class="cash-ledger-column cash-ledger-cash">${kpi('יתרת מזומן',cashBalance(),'#e8f4f2','#147d73','מחושב מכל תנועות המזומן')}${ledgerTable({collection:'cash',title:'תנועות מזומן',rows:cashRows,openAction:'open-cash-modal',editAction:'open-cash-modal-2'})}</div><div class="cash-ledger-column cash-ledger-rights">${rightsKpi}${ledgerTable({collection:'rights',title:'תנועות מעשר',rows:rightsRows,openAction:'open-right-modal',editAction:'open-right-modal-2'})}</div></div>`;
}
function syncCashBulk(){syncBulkUi('cash');syncBulkUi('rights')}
function setCashSearch(value){ui.cashSearchValue=String(value||'');const region=document.getElementById('cashLedgersRegion');if(region){region.innerHTML=cashLedgersMarkup();syncCashBulk()}}
function renderCash(){
  document.getElementById('content').innerHTML=`<div class="view-search-row cash-view-search">${localSearchMarkup({value:ui.cashSearchValue||'',placeholder:'חיפוש בתנועות מזומן ומעשר…',label:'חיפוש בתנועות מזומן ומעשר',inputAction:'cash-search',className:'wide'})}</div><div id="cashLedgersRegion">${cashLedgersMarkup()}</div>`;
  syncCashBulk()
}

return { renderCash, setCashSearch, visibleLedgerRows };
}
