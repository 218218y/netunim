import {checkFutureTotalData,checkMonthSummaryMarkup} from '../../shared/check-summary.js';
import {esc} from '../../core/values.js';
import {checkUrgency, checkBelongsToAccountData, checkIsClosedStatus} from './model.js';
import {daysFromToday, monthKey, monthLabel, dateFmt, todayISO} from '../../core/dates.js';
import {moneyWithCents as money} from '../../core/money.js';
import {searchMatch} from '../../core/search.js';
import {localSearchMarkup} from '../../ui-primitives/local-search.js';

import {checkBankReviewMarkup,checkBankStatusMarkup,checkBankActivityMarkup,checkMorningSourceMarkup} from '../../shared/check-bank-review.js';

// Dependencies are supplied by the composition root; this module has no startup side effects.
export function createDomainsChecksView({getBankImageContext=()=>({}), ui, model, syncBulkUi, bulkControls, bulkHeader, bulkCell, futureCheckMonths}){
function badgeStatus(s){const cls=s==='בקופה'?'blue':s==='הופקד - במעקב'?'orange':s==='נפרע'?'green':s==='חזר'?'red':'';return `<span class="badge ${esc(cls)}">${esc(s)}</span>`}

function dueBadge(c){const u=checkUrgency(c);if(u==='overdue')return '<span class="badge red">עבר מועד</span>';if(u==='week')return '<span class="badge orange">השבוע</span>';if(u==='month')return '<span class="badge yellow">עד 30 יום</span>';return ''}

function checkFocusMatch(x){
  if(ui.checkFocus==='due7'){const d=daysFromToday(x.dueDate);return x.status==='בקופה'&&d>=0&&d<=7}
  if(ui.checkFocus==='overdue')return x.status==='בקופה'&&daysFromToday(x.dueDate)<0;
  return true;
}

function clearCheckFocus(){ui.checkFocus='all';renderChecks()}

function checkAccountFilterMatch(check){return ui.checkAccount==='all'||checkBelongsToAccountData(check,ui.checkAccount)}

function visibleChecks(){let rows=model.state.checks.filter(checkAccountFilterMatch);if(ui.checkTab==='open')rows=rows.filter(x=>!checkIsClosedStatus(x.status));if(ui.checkTab==='deposited')rows=rows.filter(x=>x.status==='הופקד - במעקב');if(ui.checkTab==='closed')rows=rows.filter(x=>['נפרע','חזר','בוטל'].includes(x.status));rows=rows.filter(checkFocusMatch);if(ui.checkYear!=='all')rows=rows.filter(x=>x.dueDate?.startsWith(ui.checkYear+'-'));const q=ui.checkSearchValue.trim();if(q)rows=rows.filter(x=>searchMatch(q,[x.name,x.checkNumber,x.note,x.status,x.account,x.amount,x.dueDate,x.depositDate,x.clearedDate,x.createdAt],[x.dueDate,x.depositDate,x.clearedDate,x.createdAt]));return rows.sort((a,b)=>(a.dueDate||'').localeCompare(b.dueDate||''))}

function visibleChecksTotal(rows=visibleChecks()){return ui.checkTab==='open'?checkFutureTotalData(rows):rows.reduce((sum,row)=>sum+(Number(row.amount)||0),0)}
function checkTotalLabel(){return ui.checkTab==='open'?'סה״כ צ׳קים עתידיים':ui.checkTab==='deposited'?'סה״כ צ׳קים שהופקדו':'סה״כ צ׳קים שנסגרו'}

function renderChecks(){const bankAccountFilter=ui.checkAccount==='all'?null:ui.checkAccount,years=[...new Set(model.state.checks.filter(checkAccountFilterMatch).map(x=>x.dueDate?.slice(0,4)).filter(Boolean))].sort();if(ui.checkYear!=='all'&&!years.includes(ui.checkYear))ui.checkYear='all';const rows=visibleChecks();const groups={};rows.forEach(r=>(groups[monthKey(r.dueDate)]??=[]).push(r));
document.getElementById('content').innerHTML=`<div class="checks-page-compact"><div class="toolbar checks-toolbar"><div class="segmented"><button class="${esc(ui.checkTab==='open'?'active':'')}" data-action="check-tab">הכל</button><button class="${esc(ui.checkTab==='deposited'?'active':'')}" data-action="check-tab-2">הופקדו</button><button class="${esc(ui.checkTab==='closed'?'active':'')}" data-action="check-tab-3">נסגרו</button></div><select data-change="check-year"><option value="all">כל השנים</option>${years.map(y=>`<option ${ui.checkYear===y?'selected':''}>${esc(y)}</option>`).join('')}</select>${localSearchMarkup({value:ui.checkSearchValue,placeholder:'חיפוש שם, מספר צ׳ק, סכום או הערה…',label:'חיפוש בצ׳קים המוצגים',inputAction:'render-checks-search',className:'checks-search-field'})}<span class="checks-grand-total" id="checksGrandTotal">${checkTotalLabel()} <b>${money(visibleChecksTotal(rows))}</b></span><div class="check-account-toggle" role="group" aria-label="סיווג צ׳קים"><button class="${esc(ui.checkAccount==='all'?'active':'')}" data-action="check-account" data-click-arg0="all">הכל</button><button class="${esc(ui.checkAccount==='עסקי'?'active':'')}" data-action="check-account" data-click-arg0="עסקי">עסקי</button><button class="${esc(ui.checkAccount==='ביתי'?'active':'')}" data-action="check-account" data-click-arg0="ביתי">ביתי</button></div>${ui.checkFocus==='due7'?`<span class="stat-pill">סינון: פירעון ב־7 ימים <button class="iconbtn" data-action="clear-check-focus" title="הסר סינון">×</button></span>`:''}${ui.checkFocus==='overdue'?`<span class="stat-pill">סינון: עבר מועד <button class="iconbtn" data-action="clear-check-focus" title="הסר סינון">×</button></span>`:''}<span class="toolbar-spacer"></span>${bulkControls('checks')}${ui.bulkCollection==='checks'?'<button type="button" class="btn" data-action="review-check-bank" data-click-arg2="remove-selected">הסר הודעות שטופלו לצ׳קים שנבחרו</button>':''}<button class="btn primary" data-action="open-check-modal">+ צק חדש</button></div>${checkBankReviewMarkup(model.state.checks,bankAccountFilter)}${checkBankActivityMarkup(model.state.checks,bankAccountFilter,ui.checkBankHistoryPage,getBankImageContext())}${checkForecastMarkup()}<div id="checkGroups">${renderCheckGroups(groups)}</div></div>`;syncBulkUi('checks')}

function checkForecastMarkup(){
  const months=futureCheckMonths({fromMonth:monthKey(todayISO()),year:ui.checkYear,account:ui.checkAccount});
  const max=Math.max(1,...months.map(x=>Math.abs(x.total))),split=Math.ceil(months.length/2),columns=[months.slice(0,split),months.slice(split)],body=months.length?`<div class="section-body"><div class="checks-forecast-columns">${columns.filter(column=>column.length).map(column=>`<div class="bar-list">${column.map(x=>checkForecastBarRow(x,max)).join('')}</div>`).join('')}</div></div>`:`<div class="section-body"><div class="empty compact">אין צ׳קים עתידיים בקופה בטווח שנבחר.</div></div>`;
  return `<section class="section checks-forecast forecast-disclosure-section"><div class="forecast-disclosure-head"><button type="button" class="forecast-disclosure-toggle ${ui.checksForecastOpen?'open':''}" data-action="toggle-checks-forecast" aria-expanded="${ui.checksForecastOpen===true}" aria-controls="checksForecastBody"><span>תצוגת צ׳קים לפי חודש</span><span class="forecast-disclosure-chevron" aria-hidden="true">⌄</span></button></div><div id="checksForecastBody" class="forecast-disclosure-body" ${ui.checksForecastOpen?'':'hidden'}>${body}</div></section>`;
}

function checkForecastBarRow(month,max){const width=month.total===0?0:Math.max(2,Math.abs(month.total)/max*100);return `<div class="bar-row"><b>${esc(monthLabel(month.key))}</b><div class="bar"><i style="--bar:#76929a;width:${esc(width)}%"></i></div><div class="num">${money(month.total)}</div></div>`}

function renderChecksSearch(v){ui.checkSearchValue=v;const rows=visibleChecks(),g={};rows.forEach(r=>(g[monthKey(r.dueDate)]??=[]).push(r));document.getElementById('checkGroups').innerHTML=renderCheckGroups(g);const total=document.getElementById('checksGrandTotal');if(total)total.innerHTML=`${checkTotalLabel()} <b>${money(visibleChecksTotal(rows))}</b>`;syncBulkUi('checks')}

function renderCheckGroups(groups){const keys=Object.keys(groups).sort();if(!keys.length)return '<section class="section"><div class="empty">אין צקים בתצוגה הזאת.</div></section>';return keys.map(k=>{const arr=groups[k];return `<div class="month-group"><div class="month-title"><b>${monthLabel(k)}</b><span class="month-check-total">${checkMonthSummaryMarkup(arr,money)}</span></div><div class="table-scroll"><table class="mobile-card-table checks-table"><thead><tr>${bulkHeader('checks')}<th>שם</th><th>סכום</th><th>פירעון</th><th>סטטוס</th><th>התראה</th><th>מס׳ צק</th><th>הערה</th><th></th></tr></thead><tbody>${arr.map(checkRow).join('')}</tbody></table></div></div>`}).join('')}

function checkRow(c){return `<tr data-bulk-collection="checks" data-bulk-id="${esc(c.id)}" class="${esc(ui.bulkSelected.has(c.id)?'bulk-selected-row':'')}">${bulkCell('checks',c.id)}<td data-label="שם"><b>${esc(c.name)}</b>${checkMorningSourceMarkup(c)}</td>
<td data-label="סכום" class="amount">${money(c.amount)}</td><td data-label="פירעון">${dateFmt(c.dueDate)}</td><td data-label="סטטוס">${badgeStatus(c.status)}${checkBankStatusMarkup(c)}</td><td data-label="התראה">${dueBadge(c)}</td><td data-label="מספר צק">${esc(c.checkNumber)||'—'}</td><td data-label="הערה" class="muted">${esc(c.note)||'—'}</td><td data-label="פעולות"><div class="row-actions">${c.status==='בקופה'?`<button class="iconbtn" data-action="mark-deposited" data-click-arg0="${esc(c.id)}">הופקד</button>`:''}${c.status==='הופקד - במעקב'?`<button class="iconbtn" data-action="mark-cleared" data-click-arg0="${esc(c.id)}">נפרע</button>`:''}<button class="iconbtn" data-action="open-check-modal-2" data-click-arg0="${esc(c.id)}">עריכה</button></div></td></tr>`}

return { badgeStatus, dueBadge, checkFocusMatch, clearCheckFocus, checkAccountFilterMatch, visibleChecks, visibleChecksTotal, renderChecks, renderChecksSearch, renderCheckGroups, checkRow, checkForecastMarkup };
}
