import {startupMark} from './shared/startup-timing.js';
import {createKupaTaxCalculator} from './composition/tax-calculator.js';
import {createTaxCalculatorActions} from './ui/action-packs/tax-calculator.js';
import {createKupaDashboardCapability} from './composition/dashboard.js';
import {createKupaBankQueries} from './composition/bank-queries.js';
import {readCloudWriteScope} from './shared/cloud-write-scope.js';
import {createKupaConnectivityRuntime} from './connectivity.js';
import {createStorageStartupRecovery} from './shared/storage-startup-recovery.js';
import {createRuntimeResources} from './shared/runtime-resources.js';
import {createKupaCloudStartup} from './startup/cloud-hydration.js';
import {createKupaLocalServices} from './startup/local-services.js';
import {createKupaConnectionStartup} from './startup/connection.js';
import {createKupaStorageV2Coordinator} from './composition/storage-v2.js';
import {installLocalSiteResetPeerListener} from './shared/local-site-reset.js';
import {assertKupaEntityInvariants} from './state/validation.js';
import {KUPA_FINANCE_DOMAINS} from './state/revisions.js';
import {createFinanceDerivationStore} from './shared/finance-derivations.js';
import {createUiConnection} from './ui/connection.js';
import {createStateNormalization} from './composition/state-normalization.js';
import {createUiStatus} from './ui/status.js';
import {createStorageIndexedDb} from './storage/indexed-db.js';
import {createStorageBrowser} from './storage/browser.js';
import {createStorageTabLock} from './storage/tab-lock.js';
import {createSyncRecovery} from './sync/recovery.js';
import {createStorageFiles} from './storage/files.js';
import {createStorageBackup} from './storage/backup.js';
import {createStoragePersistence} from './storage/persistence.js';
import {createUiFolders} from './ui/folders.js';
import {createCloudAuth} from './cloud/auth.js';
import {createCloudTransport} from './cloud/transport.js';
import {createSyncMerge} from './sync/merge.js';
import {createSyncDocument} from './composition/main-sync.js';
import {composeCloudUi} from './composition/cloud.js';
import {createUiDateEditor} from './ui/date-editor.js';
import {createKupaChecksRuntime} from './composition/checks.js';
import {createKupaCashRuntime} from './composition/cash.js';
import {createKupaCreditRuntime} from './composition/credit.js';
import {createKupaExpensesRuntime} from './composition/expenses.js';
import {createUiNavigation} from './ui/navigation.js';
import {createUiSidebar} from './ui/sidebar.js';
import {createUiGlobalSearch} from './ui/global-search.js';
import {createUiBulk} from './ui/bulk.js';
import {createKupaNotesRuntime} from './composition/notes.js';
import {createDomainsBankAlerts} from './domains/bank/alerts.js';
import {composeDocumentSearch} from './shared/document-search-composition.js';
import {composeKupaFinance} from './composition/finance.js';
import {createUiSettings} from './ui/settings.js';
import {createUiModal} from './ui/modal.js';
import {inactiveCreditExpired} from './domains/credit/model.js';
import {createDomainsRecordsCommands} from './domains/records/commands.js';
import {createUiBackup} from './ui/backup.js';
import {createLifecycle} from './lifecycle.js';
import {bindActionEvents,bindBackdropDismissal,bindDismissibleDetails,bindNumberInputWheelGuard} from './shared/events.js';
import {checkBankReviewItems,checkBankReviewMarkup} from './shared/check-bank-review.js';
import {composeActionRegistry} from './shared/action-registry.js';
import {createShellActions,createSettingsActions,createBackupActions,createCloudActions} from './ui/actions.js';
import {createContexts} from './state/contexts.js';
import {createKupaDomainRevisions,kupaPageRevision} from './state/revisions.js';
import {createRestoreGroupStore} from './shared/restore-groups.js';
import {RESTORE_GROUP_NAMESPACES} from './shared/restore-group-keys.js';













startupMark('composition-start');
const {model, session, ui, files, tab, checksSession}=createContexts();
installLocalSiteResetPeerListener();
// Event handlers are installed before the async owner/protocol preflight finishes.
session.storageProtocolBlocked=true;
const storageRecovery=createStorageStartupRecovery();
const domainRevisions=createKupaDomainRevisions(session);
const financeDerivations=createFinanceDerivationStore({revision:()=>domainRevisions.stamp(KUPA_FINANCE_DOMAINS)});

const storageV2Coordinator=createKupaStorageV2Coordinator({tab,session});
const {owner:storageOwner,preparing:storagePreparationActive}=storageV2Coordinator;

function captureLocalSourceScope(){
  const accepted=storageOwner.captureCommitAuthority(),account=cloudAuth.getAccountScope(),generation=session.localGeneration;
  return ()=>{
    const current=cloudAuth.getAccountScope();
    if(!accepted()||storagePreparationActive()||current.epoch!==account.epoch||current.owner!==account.owner||session.localGeneration!==generation)
      throw new Error('storage_source_scope_changed');
  };
}

const uiConnection=createUiConnection({
  session,
  tab,
  setCloudHeaderStatus:(...args)=>uiStatus.setCloudHeaderStatus(...args),
  storeSupaSession:(...args)=>cloudAuth.storeSupaSession(...args),
  openSupabaseLoginModal:(...args)=>uiCloud.openSupabaseLoginModal(...args),
  openCloudUsingSavedSession:(...args)=>uiCloud.openCloudUsingSavedSession(...args),
  supaProjectRef:(...args)=>uiStatus.supaProjectRef(...args),
  supaConfigured:(...args)=>cloudAuth.supaConfigured(...args),
  getRememberedHandle:(...args)=>storageIndexedDb.getRememberedHandle(...args),
  connectDirectory:(...args)=>uiFolders.connectDirectory(...args),
  captureSourceScope:captureLocalSourceScope,
});

const stateNormalization=createStateNormalization({
  externalWorkbooks:true,
  model,
});

const uiStatus=createUiStatus({
  storageRecovery,
  session,
  checksSession,
  tab,
});

const storageIndexedDb=createStorageIndexedDb({

});
const notes=createKupaNotesRuntime({model,ui,session,tab,ownership:{
  current:()=>storageOwner.current(),
  writable:()=>storageOwner.writable&&!storagePreparationActive()&&!session.storageProtocolBlocked,
}});
const captureLegacyWorkbook=(...args)=>notes.captureLegacyWorkbook(...args);

const mainStorageV2=storageV2Coordinator.createRuntime({validate:state=>assertKupaEntityInvariants(state,{includeChecks:Object.hasOwn(state||{},'checks'),required:true}),prepareCheckpoint:state=>stateNormalization.prepareKupaStorageState(state),prepareOperation:operation=>stateNormalization.prepareKupaStorageOperation(operation)});
const storageBrowser=createStorageBrowser({
  storageV2:mainStorageV2,
  model,
  session,
  files,
  normalizeState:(...args)=>stateNormalization.normalizeState(...args),
  prepareKupaCloudState:(...args)=>stateNormalization.prepareKupaCloudState(...args),
});
const storageV2Cloud=storageV2Coordinator.createCloudPorts(storageBrowser);

const restoreGroupStore=createRestoreGroupStore({
  localKey:RESTORE_GROUP_NAMESPACES.kupa,
  put:(key,value)=>storageIndexedDb.idbPut('sync',key,value),
  get:key=>storageIndexedDb.idbGet('sync',key),
  remove:key=>storageIndexedDb.idbDelete('sync',key),
});

const checks=createKupaChecksRuntime({model,ui,checksSession,sharedChecksHasLocalWork:()=>sharedChecksV2.hasLocalWork});

const sharedChecksV2Composition=storageV2Coordinator.createSharedComposition({
  model,checksSession,domainRevisions,main:mainStorageV2,stateNormalization,mergeSharedChecks:checks.mergeSharedChecks,getCloudTransport:()=>cloudTransport,
});
const sharedChecksV2=sharedChecksV2Composition.runtime;
const recoverSharedChecksV2Primary=()=>storageV2Coordinator.recoverShared();
const verifyStorageV2AccountMarker=sharedChecksV2Composition.verifyAccountMarker;

const storageTabLock=createStorageTabLock({
  tab,
  showSecondaryTabGuard:(...args)=>uiConnection.showSecondaryTabGuard(...args),
});

const syncRecovery=createSyncRecovery({
  captureLegacyWorkbook,
  hideConnectScreen:(...args)=>uiStatus.hideConnectScreen(...args),
  model,
  session,
  prepareKupaCloudState:(...args)=>stateNormalization.prepareKupaCloudState(...args),
  normalizeState:(...args)=>stateNormalization.normalizeState(...args),
  setSaveStatus:(...args)=>uiStatus.setSaveStatus(...args),
  setConnectedStatus:(...args)=>uiStatus.setConnectedStatus(...args),
  setCloudHeaderStatus:(...args)=>uiStatus.setCloudHeaderStatus(...args),
  ...storageV2Cloud,
  loadBrowserState:(...args)=>storageBrowser.loadBrowserState(...args),
  loadBrowserStateReadOnly:(...args)=>storageBrowser.loadBrowserStateReadOnly(...args),
  startCloudPolling:(...args)=>syncDocument.startCloudPolling(...args),
  render:(...args)=>uiNavigation.render(...args),
  domainRevisions,
});

const storageFiles=createStorageFiles({

});

const storageBackup=createStorageBackup({
  files,
  model,
  session,
  normalizeState:(...args)=>stateNormalization.normalizeState(...args),
  writeJsonHandle:(...args)=>storageFiles.writeJsonHandle(...args),
  readJsonHandle:(...args)=>storageFiles.readJsonHandle(...args),
  platform:{reportBackupError:message=>uiStatus.toast(message)},
});

const storagePersistence=createStoragePersistence({
  model,session,tab,
  journal:{
    sharedChecksV2,storageV2Boundary:sharedChecksV2Composition.boundary,
    storageV2Primary:()=>mainStorageV2.primaryReady,
    recoverStorageV2State:()=>mainStorageV2.recoverForOwner({intent:'load-account'}),
    storageV2DurabilityAtRisk:()=>mainStorageV2.durabilityAtRisk,
    mutationScope:()=>JSON.stringify([mainStorageV2.cloudScope?.owner,mainStorageV2.cloudScope?.epoch,cloudAuth.getAccountScope()]),
    confirmVisibleState:()=>storageV2Coordinator.confirmVisibleState(),
    storageV2CommitPromise:()=>storageV2Cloud.storageV2CommitPromise(),
    refreshStorageV2CloudState:()=>storageV2Cloud.refreshStorageV2CloudState(),
    persistImmediateBrowserSnapshot:(...args)=>storageBrowser.persistImmediateBrowserSnapshot(...args),
  },
  projection:{
    domainRevisions,creditNormalizationMayDelete:inactiveCreditExpired,
    stateFromPayload:(...args)=>stateNormalization.stateFromPayload(...args),
    prepareKupaCloudState:(...args)=>stateNormalization.prepareKupaCloudState(...args),
    normalizeState:(...args)=>stateNormalization.normalizeState(...args),
  },
  file:{
    files,checksSession,captureLegacyWorkbook,
    readJsonHandle:(...args)=>storageFiles.readJsonHandle(...args),
    writeJsonHandleVerified:(...args)=>storageFiles.writeJsonHandleVerified(...args),
    listBackups:(...args)=>storageBackup.listBackups(...args),
    backupSnapshotToComputer:(...args)=>storageBackup.backupSnapshotToComputer(...args),
  },
  cloud:{persistSupabaseState:(...args)=>syncDocument.persistSupabaseState(...args)},
  view:{
    setCloudHeaderStatus:(...args)=>uiStatus.setCloudHeaderStatus(...args),
    reportError:(...args)=>uiStatus.reportError(...args),
    setSaveStatus:(...args)=>uiStatus.setSaveStatus(...args),
    setConnectedStatus:(...args)=>uiStatus.setConnectedStatus(...args),
    showSecondaryTabGuard:(...args)=>uiConnection.showSecondaryTabGuard(...args),
    toast:(...args)=>uiStatus.toast(...args),
    isOnline:()=>navigator.onLine!==false,
  },
});

checks.bindPersistence({
  loadSession:(...args)=>cloudAuth.loadSupaSession(...args),
  checksStatus:{
    save:(text,mode)=>uiStatus.setSaveStatus(text,mode,'shared-checks'),
    cloud:(mode,text)=>uiStatus.setCloudHeaderStatus(mode,text,'shared-checks'),
  },
  sharedChecksV2,session,files,tab,domainRevisions,
  showSecondaryTabGuard:(...args)=>uiConnection.showSecondaryTabGuard(...args),
  setSaveStatus:(...args)=>uiStatus.setSaveStatus(...args),
  normalizeState:(...args)=>stateNormalization.normalizeState(...args),
  backupSnapshotToComputer:(...args)=>storageBackup.backupSnapshotToComputer(...args),
});

let resumeSourcePolling=false;
const uiFolders=createUiFolders({
  files,
  session,
  tab,
  ui,
  rememberHandle:(...args)=>storageIndexedDb.rememberHandle(...args),
  rememberBackupHandle:(...args)=>storageIndexedDb.rememberBackupHandle(...args),
  showSecondaryTabGuard:(...args)=>uiConnection.showSecondaryTabGuard(...args),
  permissionFor:(...args)=>storageFiles.permissionFor(...args),
  prepareDirectory:(...args)=>storageBackup.prepareDirectory(...args),
  loadState:(...args)=>storagePersistence.loadState(...args),
  render:(...args)=>uiNavigation.render(...args),
  listBackups:(...args)=>storageBackup.listBackups(...args),
  backupSnapshotToComputer:(...args)=>storageBackup.backupSnapshotToComputer(...args),
  toast:(...args)=>uiStatus.toast(...args),
  renderTaxCalculator:()=>taxCalculator.render(),
  renderSettings:(...args)=>uiSettings.renderSettings(...args),
  getRememberedHandle:(...args)=>storageIndexedDb.getRememberedHandle(...args),
  getRememberedBackupHandle:(...args)=>storageIndexedDb.getRememberedBackupHandle(...args),
  showFirstRun:(...args)=>uiConnection.showFirstRun(...args),
  showRememberedFolderPrompt:(...args)=>uiConnection.showRememberedFolderPrompt(...args),
  captureSourceScope:captureLocalSourceScope,
  drainSources:async()=>{
    resumeSourcePolling=!!session.cloudPollingEnabled;
    await syncDocument.quiesceForStorageCutover();
    await storagePersistence.runtime.drain();
    await checks.runtime.drain();
    storageBackup.runtime.cancelPending();
    await storageBackup.runtime.drain();
  },
  resumeSources:()=>{
    const resume=resumeSourcePolling;resumeSourcePolling=false;
    if(resume&&tab.primaryTab&&!storagePreparationActive()&&session.connectionMode==='supabase'&&session.backendReady)syncDocument.startCloudPolling();
  },
});

const cloudAuth=createCloudAuth({
  session,
  idbGet:(...args)=>storageIndexedDb.idbGet(...args),
  idbPut:(...args)=>storageIndexedDb.idbPut(...args),
  idbDelete:(...args)=>storageIndexedDb.idbDelete(...args),
  supaProjectRef:(...args)=>uiStatus.supaProjectRef(...args),
  setCloudHeaderStatus:(...args)=>uiStatus.setCloudHeaderStatus(...args),
  assertSessionOwner:(...args)=>storageOwner.assertSessionOwner(...args),
});

const domainsDocumentBridge=composeDocumentSearch({supaFetch:(...args)=>cloudAuth.supaRest(...args),accountScope:()=>cloudAuth.getAccountScope(),subscribeAccountScope:cloudAuth.subscribeAccountScope});

const cloudTransport=createCloudTransport({
  session,
  supaRest:(...args)=>cloudAuth.supaRest(...args),
  localResetReadOnlyFetch:(...args)=>cloudAuth.localResetReadOnlyFetch(...args),
});

const dashboard=createKupaDashboardCapability({
  model,ui,runFinance:financeDerivations.run,
  access:{
    current:()=>({account:cloudAuth.getAccountScope(),readable:session.connectionMode==='supabase'&&session.backendReady}),
    subscribe:cloudAuth.subscribeAccountScope,
  },
  remote:{readMeta:(...args)=>cloudTransport.readOrdersReadOnlyMeta(...args),readDocument:(...args)=>cloudTransport.readOrdersReadOnlyCloud(...args)},
  touchRevision:()=>domainRevisions.touch('ordersFinance'),
});

checks.bindSync({
  sharedChecksV2,
  session,
  files,
  tab,
  loadSession:(...args)=>cloudAuth.loadSupaSession(...args),
  toast:(...args)=>uiStatus.toast(...args),
  render:(...args)=>uiNavigation.checksChanged(...args),
  setSaveStatus:(text,mode)=>uiStatus.setSaveStatus(text,mode,'shared-checks'),
  setCloudHeaderStatus:(mode,text)=>uiStatus.setCloudHeaderStatus(mode,text,'shared-checks'),
  backupSnapshotToComputer:(...args)=>storageBackup.backupSnapshotToComputer(...args),
  refreshCloudHeaderTimestamp:(...args)=>uiStatus.refreshCloudHeaderTimestamp(...args),
});

const syncMerge=createSyncMerge({
  normalizeState:(...args)=>stateNormalization.normalizeState(...args),
  prepareKupaCloudState:(...args)=>stateNormalization.prepareKupaCloudState(...args),
});

const syncDocument=createSyncDocument({
  model,session,tab,
  ownership:{
    getScope:()=>readCloudWriteScope(mainStorageV2.cloudScope,cloudAuth.getAccountScope()),
    preparing:storagePreparationActive,
    assertAccountOwner:()=>storageV2Coordinator.accountContextPort().assertAccountOwner(),
    cancelRecovery:()=>uiCloud.recoveryRuntime.cancel(),
  },
  storage:storageV2Cloud,
  state:{normalization:stateNormalization,merge:syncMerge,domainRevisions},
  transport:cloudTransport,
  view:{status:uiStatus,render:()=>uiNavigation.render(),showSecondaryTabGuard:()=>uiConnection.showSecondaryTabGuard()},
  mirror:storageBackup,
  secondary:{checks,dashboard:dashboard.commands},
});


storageV2Coordinator.configure({
  storageBrowser,syncDocument,saveRuntime:storagePersistence.runtime,checksRuntime:checks.runtime,notesRuntime:notes.runtime,backupRuntime:{cancelPending(){uiBackup.runtime.cancelPending();storageBackup.runtime.cancelPending()},async drain(){await uiBackup.runtime.drain();await storageBackup.runtime.drain()}},model,session,checksSession,files,
  captureLegacyWorkbook,
  stateNormalization,domainRevisions,sharedChecksV2Composition,sharedChecksV2,
  cloudTransport,cloudAuth,mainStorageV2,verifyStorageV2AccountMarker:()=>verifyStorageV2AccountMarker(),
});

const uiDateEditor=createUiDateEditor({
  markCheckSeriesManual:(...args)=>checks.markCheckSeriesManual(...args),
  syncCheckSeriesFromFirst:(...args)=>checks.syncCheckSeriesFromFirst(...args),
  toast:(...args)=>uiStatus.toast(...args),
});

const cash=createKupaCashRuntime({model,ui});
const credit=createKupaCreditRuntime({model,ui});

const bankQueries=createKupaBankQueries({model,checksSession});

const uiNavigation=createUiNavigation({
  runFinance:financeDerivations.run,
  refreshCheckBankIndicator:()=>{const b=document.getElementById('checkBankAlerts');if(b){const count=checkBankReviewItems(model.state.checks).length;b.hidden=!count;b.textContent=`⚠ צ׳קים (${count})`}},
  ui,
  renderDashboard:(...args)=>dashboard.presentation.renderDashboard(...args),
  renderChecks:(...args)=>checks.renderChecks(...args),
  renderCredit:(...args)=>credit.renderCredit(...args),
  renderCash:(...args)=>cash.renderCash(...args),
  renderBank:(...args)=>bank.presentation.renderBank(...args),
  renderNotes:(...args)=>notes.renderNotes(...args),
  renderSettings:(...args)=>uiSettings.renderSettings(...args),
  maybeAutoRefreshBankBalance:(...args)=>bank.runtime.wake(...args),
  maybeAutoRefreshCreditSync:(...args)=>credit.runtime.wake(...args),
  maybeShowCashflowStartupAlert:(...args)=>domainsBankAlerts.maybeShowStartupCashflowAlert(...args),
  onPageActivated:page=>{void notes.activateSheetIfVisible(page)},
  dataRevision:page=>kupaPageRevision(domainRevisions,page)+':'+new Date().toLocaleDateString('en-CA')+notes.revisionSuffix(page),
});

const uiGlobalSearch=createUiGlobalSearch({
  documentBridge:domainsDocumentBridge,
  searchRevision:domains=>domainRevisions.stamp(domains)+':'+new Date().toLocaleDateString('en-CA'),
  runFinance:financeDerivations.run,
  model,
  ui,
  setPage:(...args)=>uiNavigation.setPage(...args),
  confirmDialog:(...args)=>uiModal.confirmDialog(...args),
});

const uiSidebar=createUiSidebar({setPage:(...args)=>uiNavigation.setPage(...args)});

const uiBulk=createUiBulk({
  ui,
  model,
  render:(...args)=>uiNavigation.render(...args),
  saveState:(...args)=>storagePersistence.saveState(...args),
  saveChecksState:(...args)=>checks.commands.saveLocal(...args),
  toast:(...args)=>uiStatus.toast(...args),
  confirmDialog:(...args)=>uiModal.confirmDialog(...args),
});

const expenses=createKupaExpensesRuntime({
  model,ui,
  bankForecast:{
    business:(...args)=>bankQueries.forecast('business',...args),
    home:(...args)=>bankQueries.forecast('home',...args),
  },
});

const {
  bank,bindBankUi,automation:financeAutomation,
}=composeKupaFinance({
  model,session,ui,cloudAuth,cloudTransport,syncDocument,
  checks,credit,storagePersistence,uiStatus,uiNavigation,
  uiDateEditor,financeDerivations,bankQueries,domainRevisions,
  getUiModal:()=>uiModal,
  operationAccess:()=>({
    account:cloudAuth.getAccountScope(),connectionMode:session.connectionMode,storageOwner:storageOwner.current(),
    readable:storageOwner.ready&&!storagePreparationActive()&&!session.storageProtocolBlocked&&storageRecovery.isReady()&&!session.startupCloudHydrating,
    writable:tab.primaryTab&&storageOwner.writable&&!storagePreparationActive()&&!session.storageProtocolBlocked&&storageRecovery.isReady()&&!session.startupCloudHydrating,
  }),
  automaticAccess:()=>{
    if(!tab.primaryTab||!session.backendReady||navigator.onLine===false||session.storageProtocolBlocked||!storageRecovery.isReady()||session.startupCloudHydrating||session.syncCapabilitiesChecking||session.syncCapabilitiesError)return null;
    if(session.connectionMode!=='supabase')return 'local:'+session.connectionMode;
    const owner=cloudAuth.loadSupaSession()?.user?.id;return owner?'supabase:'+owner:null;
  },
});

dashboard.bindView({
  bank:bankQueries,
  checks:{active:(...args)=>checks.activeChecks(...args),deposited:(...args)=>checks.depositedChecks(...args)},
  localBankSnapshot:(...args)=>bank.queries.localSnapshot(...args),
});
dashboard.assertReady();

const uiCloud=composeCloudUi({
  session,tab,checksSession,model,storageV2Cloud,storageV2Coordinator,syncDocument,uiStatus,cloudAuth,
  getUiModal:()=>uiModal,uiConnection,stateNormalization,syncRecovery,cloudTransport,checks,getUiNavigation:()=>uiNavigation,financeAutomation,
});

credit.bindView({
  uiBulk,uiDateEditor,financeDerivations,domainRevisions,
  expensesMarkup:(...args)=>expenses.expensesMarkup(...args),
});

checks.bindView({
  uiBulk,
  getBankImageContext:()=>({bank:bank.queries.snapshot(),imageAction:'view-bank-cheque-image'}),
});

const uiSettings=createUiSettings({
  mountSyncIncidents:container=>void syncIncidentsReady.then(feature=>{if(container.isConnected)feature?.mountSettings(container)}),
  model,
  session,
  ui,
  checksSession,
  files,
  supaProjectRef:(...args)=>uiStatus.supaProjectRef(...args),
  supaConfigured:(...args)=>cloudAuth.supaConfigured(...args),
  bankCurrentBalance:(...args)=>bankQueries.balance('business',...args),
  saveState:(...args)=>storagePersistence.saveState(...args),
});

const uiModal=createUiModal({
  ui,
});

notes.bind({cloudAuth,uiModal,storagePersistence});
notes.assertReady();
bindBankUi();bank.assertReady();

const domainsBankAlerts=createDomainsBankAlerts({
  model,
  bankProjectedThisMonth:(...args)=>bankQueries.projectedBalance('business',...args),
  bankHomeProjectedThisMonth:(...args)=>bankQueries.projectedBalance('home',...args),
  modal:(...args)=>uiModal.modal(...args),
  closeModal:(...args)=>uiModal.closeModal(...args),
});

const domainsRecordsCommands=createDomainsRecordsCommands({
  model,
  saveState:(...args)=>storagePersistence.saveState(...args),
  saveChecksState:(...args)=>checks.commands.saveLocal(...args),
  closeModal:(...args)=>uiModal.closeModal(...args),
  confirmDialog:(...args)=>uiModal.confirmDialog(...args),
  renderCollection:collection=>{
    if(collection==='checks')uiNavigation.checksChanged();
    if(collection==='cash'||collection==='rights')cash.renderCash();
    else if(collection==='expenses'||collection==='credits')credit.renderCredit();
  },
});

cash.bindUi({uiBulk,uiDateEditor,domainsDashboardView:dashboard.presentation,uiModal,uiStatus,storagePersistence,domainsRecordsCommands});
cash.assertReady();

checks.bindEditor({uiDateEditor,uiModal,uiStatus,domainsRecordsCommands,uiNavigation,uiBulk});
checks.assertReady();

credit.bindEditor({uiModal,uiDateEditor,uiStatus,storagePersistence,domainsRecordsCommands});
credit.assertReady();

expenses.bindEditor({
  uiModal,uiDateEditor,uiStatus,storagePersistence,domainsRecordsCommands,
  renderCredit:(...args)=>credit.renderCredit(...args),
});
expenses.assertReady();

const uiBackup=createUiBackup({
  model,
  session,
  ui,
  files,
  checksSession,
  projection:{
    stateFromPayload:(...args)=>stateNormalization.stateFromPayload(...args),
  },
  view:{
    toast:(...args)=>uiStatus.toast(...args),
    renderSettings:(...args)=>uiSettings.renderSettings(...args),
    render:(...args)=>uiNavigation.render(...args),
    modal:(...args)=>uiModal.modal(...args),
    closeModal:(...args)=>uiModal.closeModal(...args),
    confirmDialog:(...args)=>uiModal.confirmDialog(...args),
    invalidateAllViewDomains:()=>domainRevisions.touchAll(),
  },
  local:{
    readJsonHandle:(...args)=>storageFiles.readJsonHandle(...args),
    listBackups:(...args)=>storageBackup.listBackups(...args),
    createManualBackup:(...args)=>storageBackup.createManualBackup(...args),
    chooseFolder:(...args)=>uiFolders.chooseFolder(...args),
  },
  cloud:{
    accountScope:()=>cloudAuth.getAccountScope(),
    subscribeAccountScope:listener=>cloudAuth.subscribeAccountScope(listener),
    persistSupabaseState:(...args)=>syncDocument.persistSupabaseState(...args),
    readRestoreHeads:async(options)=>{
      const [main,shared]=await Promise.all([cloudTransport.readSupabaseDocument({...options,includeFinance:false}),cloudTransport.readSharedChecksDocument()]);
      return {main,shared};
    },
    restoreGroupStore,
    stageRestoreGroup:(...args)=>cloudTransport.stageRestoreGroup(...args),
    applyRestoreGroup:(...args)=>cloudTransport.applyRestoreGroup(...args),
    listIncompleteRestoreGroups:(...args)=>cloudTransport.listIncompleteRestoreGroups(...args),
    listKupaCloudBackups:(...args)=>cloudTransport.listKupaCloudBackups(...args),
    readKupaCloudBackupPoint:(...args)=>cloudTransport.readKupaCloudBackupPoint(...args),
    loadSupaSession:(...args)=>cloudAuth.loadSupaSession(...args),
  },
  storage:{
    ...storageV2Cloud,
    storageV2Boundary:sharedChecksV2Composition.boundary,
    sharedChecksV2,
    storageV2LocalPrimary:()=>mainStorageV2.primaryReady,
    recoverStorageV2State:()=>mainStorageV2.recoverForOwner({intent:'load-account'}),
    storageOwnerCurrent:()=>storageOwner.current(),
  },
});

storageRecovery.bind({
  main:{primary:({localEngineActive})=>localEngineActive?storageV2Coordinator.recoverLocalV2State():syncRecovery.recoverBrowserV2State({startup:true,deferRender:true}),
    readOnly:()=>storageV2Coordinator.recoverReadOnlyV2State()},
  shared:{primary:recoverSharedChecksV2Primary,readOnly:()=>sharedChecksV2.recoverReadOnly()},
});

const startupAccess=()=>tab.primaryTab&&!session.storageProtocolBlocked&&storageRecovery.isReady();
const connectionResources=createRuntimeResources();
const connectionStartup=createKupaConnectionStartup({
  events:{listen:(id,handler)=>connectionResources.listen(document.getElementById(id),'click',handler),dispose:()=>connectionResources.dispose()},
  actions:{chooseFolder:uiFolders.chooseFolder,chooseDataFile:uiFolders.chooseDataFile,openLastFolder:uiFolders.openLastFolder,openCloud:uiConnection.handleCloudConnectButton},
  presentation:{tryAutoOpenRemembered:uiConnection.tryAutoOpenRemembered,showFirstRun:uiConnection.showFirstRun},access:{allowed:startupAccess},
});
const localServices=createKupaLocalServices({storage:{requestPersistentBrowserStorage:storageBrowser.requestPersistentBrowserStorage},backup:{restoreTarget:uiFolders.restoreRememberedBackupTarget}});
const cloudStartup=createKupaCloudStartup({
  session,access:{allowed:startupAccess,online:()=>navigator.onLine!==false,authenticated:()=>!!cloudAuth.loadSupaSession()},
  capabilities:{ensure:cloudAuth.ensureSyncCapabilities},restore:{resume:uiBackup.resumeIncompleteRestore},
  cloud:{configured:cloudAuth.supaConfigured,openAutomatic:uiCloud.tryAutoOpenSupabase,noDocument:()=>session.cloudAuthNoDocument,
    showNoDocument:uiCloud.showCloudNoDocument,startPolling:syncDocument.startCloudPolling},
  status:{setCloudHeaderStatus:uiStatus.setCloudHeaderStatus,setConnectUI:uiConnection.setConnectUI},
});

const lifecycle=createLifecycle({
  online:()=>globalThis.navigator?.onLine!==false,
  storageProtocol:storageV2Coordinator.startupProtocol,
  storageAdmission:storageV2Coordinator.startupAdmission,
  storageRecovery,
  cloudStartup,localServices,connectionStartup,
  hydrateStorageOwner:()=>storageOwner.hydrate({initialOwner:async()=> (await cloudAuth.restoreSupaSession())?.user?.id}),
  hideConnectScreen:()=>uiStatus.hideConnectScreen(),
  ...storageV2Coordinator.lifecyclePorts(),
  render:(...args)=>uiNavigation.render(...args),
  session,
  tab,
  setCloudHeaderStatus:(...args)=>uiStatus.setCloudHeaderStatus(...args),
  setSaveStatus:(...args)=>uiStatus.setSaveStatus(...args),
  setConnectedStatus:(...args)=>uiStatus.setConnectedStatus(...args),
  showSecondaryTabGuard:(...args)=>uiConnection.showSecondaryTabGuard(...args),
  acquirePrimaryTabLock:(...args)=>storageTabLock.acquirePrimaryTabLock(...args),
  restoreSupaSession:(...args)=>cloudAuth.restoreSupaSession(...args),
  setConnectUI:(...args)=>uiConnection.setConnectUI(...args),
});

const uiEvents={bindActionEvents:(root,actions)=>bindActionEvents(root,actions,{
  canRun:(...args)=>uiStatus.canRunInteractiveAction(...args),
  onError:(error,context)=>{
    console.error('UI action failed',context,error);
    uiStatus.toast('לא ניתן להשלים את הפעולה. אפשר לנסות שוב ולבדוק את מצב החיבור.');
  },
})};

document.getElementById('checkBankAlerts').addEventListener('click',()=>{if(uiStatus.canRunInteractiveAction('view-check-bank-alerts'))uiModal.modal('התאמות צ׳קים בבנק',checkBankReviewMarkup(model.state.checks),'סגור',()=>uiModal.closeModal(true))});

const taxCalculator=createKupaTaxCalculator({cloudAuth,tab,ui,navigation:uiNavigation,modal:uiModal});

const uiActions=composeActionRegistry([
  {name:'tax-calculator',actions:createTaxCalculatorActions({tax:taxCalculator})},
  {name:'checks',actions:checks.actions},
  bank.actionPack(),
  {name:'shell',actions:createShellActions({uiModal,uiNavigation})},
  {name:'credit',actions:credit.actions},
  {name:'cash',actions:cash.actions},
  {name:'notes',actions:notes.actions},
  {name:'notes-sheet',actions:notes.sheetActions},
  {name:'spreadsheet-workspace',actions:notes.workspaceActions},
  {name:'expenses',actions:expenses.actions},
  {name:'settings',actions:createSettingsActions({uiSettings})},
  {name:'backup',actions:createBackupActions({uiBackup,uiFolders})},
  {name:'cloud',actions:createCloudActions({syncDocument,uiCloud})},
]);


const connectivity=createKupaConnectivityRuntime({
  access:{primary:()=>tab.primaryTab,blocked:()=>session.storageProtocolBlocked||!storageRecovery.isReady()||session.startupCloudHydrating||session.syncCapabilitiesChecking||!!session.syncCapabilitiesError},
  cloud:{connected:()=>session.connectionMode==='supabase',resumeAfterReconnect:()=>syncDocument.resumeAfterReconnect(),cloudPoll:()=>syncDocument.cloudPoll()},
  bank:{startAutoSync:(...args)=>bank.runtime.start(...args),stopAutoSync:()=>bank.runtime.stop()},credit:{startAutoSync:credit.runtime.start,stopAutoSync:credit.runtime.stop},status:uiStatus,
});
connectivity.start();
uiSidebar.bind();
document.getElementById('backupTop').addEventListener('click',()=>{if(uiStatus.canRunInteractiveAction('manual-backup'))uiBackup.manualBackup()});
bindBackdropDismissal(document.getElementById('modalBackdrop'),()=>uiModal.closeModal());
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(uiSidebar.isOpen())uiSidebar.close({restoreFocus:true});else uiModal.closeModal()}});
window.addEventListener('beforeunload',e=>{
  if(!tab.primaryTab||session.storageProtocolBlocked)return;
  if(mainStorageV2.durabilityAtRisk||sharedChecksV2.durabilityAtRisk||session.localUndurableGenerations?.size){e.preventDefault();e.returnValue=''}
});

uiEvents.bindActionEvents(document.getElementById('content'),uiActions);
bindDismissibleDetails(document);
bindNumberInputWheelGuard(document);
uiEvents.bindActionEvents(document.getElementById('modal'),uiActions);
uiGlobalSearch.bind();
dashboard.runtime.start();
startupMark('composition-end');
const syncIncidentsReady=import('./shared/sync-incident-feature.js').then(({createSyncIncidentFeature})=>createSyncIncidentFeature({site:'kupa',accountScope:cloudAuth.getAccountScope,subscribeAccountScope:cloudAuth.subscribeAccountScope,
  confirmReview:message=>uiModal.confirmDialog('טיפול ידני בהתראת סנכרון',message,{confirmText:'סימון כטופל ללא אימות',tone:'danger'}),
  primary:()=>tab.primaryTab,request:cloudAuth.supaRest,
  domains:[
    {domain:'kupa_main',read:()=>storageOwner.current()===cloudAuth.getAccountScope().owner?mainStorageV2.incidentSample():{known:false}},
    {domain:'shared_checks',read:()=>storageOwner.current()===cloudAuth.getAccountScope().owner?sharedChecksV2.incidentSample():{known:false}},
    {domain:'kupa_sheet',read:()=>notes.workbook.sync.incidentSample()},
  ],
})).catch(()=>{const warning=document.createElement('section');warning.className='sync-incidents';warning.dataset.warning='true';warning.textContent='לא ניתן לטעון התראות סנכרון. יש לרענן את האתר.';warning.setAttribute('role','status');document.body.append(warning)});
export const appReady=lifecycle.boot();
void appReady.then(()=>{startupMark('boot-complete');if(tab.primaryTab&&!session.storageProtocolBlocked&&storageRecovery.isReady()&&!session.syncCapabilitiesError&&session.backendReady&&!session.startupCloudHydrating){startupMark('command-ready');connectivity.resumeStartup()}},()=>{});
export async function sharedChecksStorageV2Diagnostics(){await sharedChecksV2.flush();return {...sharedChecksV2.diagnostics}}
