import {createOperationId} from './storage-operation.js';
export {createOperationId};
export {equalSyncJson} from './sync-json.js';
export {documentWriteAckRevision} from './document-write-ack.js';

export const OUTBOX_SCHEMA_VERSION=4;
export const CLOUD_WRITE_POLICY=Object.freeze({busyAttempts:3,conflictAttempts:3});

/** @typedef {import('./cloud-policy.js').CloudPolicy} Policy */
/** @typedef {import('./cloud-policy.js').OutboxRecord} OutboxRecord */
/** @typedef {import('./cloud-policy.js').CloudErrorKind} CloudErrorKind */
/** @template Result @typedef {import('./cloud-policy.js').QueueItem<Result>} QueueItem */
/** @type {Policy['object']} */
function object(value){return value!==null&&typeof value==='object'}
/** @type {Policy['record']} */
function record(value){return object(value)?value:{}}

/** @template Value @param {Value} value @returns {Value} */
function copy(value){return value==null?value:structuredClone(value)}
/** @type {Policy['finiteRevision']} */
function finiteRevision(value){const n=Number(value);return Number.isSafeInteger(n)&&n>=0?n:0}
/** @type {Policy['finiteGeneration']} */
function finiteGeneration(value){const n=Number(value);return Number.isSafeInteger(n)&&n>=0?n:0}
/** @type {Policy['iso']} */
function iso(value,now){const parsed=Date.parse(String(value||''));return Number.isFinite(parsed)?new Date(parsed).toISOString():new Date(now()).toISOString()}
/** @type {Policy['nowMilliseconds']} */
function nowMilliseconds(now=Date.now){const value=Number(typeof now==='function'?now():now);return Number.isFinite(value)?value:Date.now()}
/** @type {Policy['futureIso']} */
function futureIso(value,now=Date.now){const parsed=Date.parse(String(value||'')),current=nowMilliseconds(now);return Number.isFinite(parsed)&&parsed>current?new Date(parsed).toISOString():null}


/** @type {Policy['createOutboxRecord']} */
export function createOutboxRecord({domain,documentName,operationId,generation,mutationSeq,baseRevision,baseState,snapshot,createdAt,updatedAt,conflict=null,retry=null,mutationType='autosave',surface='unknown',restoreGroupId=null},options={}){
  const now=options.now||Date.now,created=iso(createdAt,now),updated=iso(updatedAt||created,now);
  const normalizedGeneration=finiteGeneration(generation),normalizedMutationSeq=Math.max(normalizedGeneration,finiteGeneration(mutationSeq));
  return {
    schemaVersion:OUTBOX_SCHEMA_VERSION,
    domain:String(domain||'unknown'),
    documentName:String(documentName||'main'),
    operationId:String(operationId||createOperationId(String(domain||'sync'),{now,random:options.random||Math.random,...(Object.hasOwn(options,'randomUUID')?{randomUUID:options.randomUUID??null}:{})})),
    generation:normalizedGeneration,
    mutationSeq:normalizedMutationSeq,
    baseRevision:finiteRevision(baseRevision),
    baseState:copy(baseState??{}),
    snapshot:copy(snapshot??{}),
    createdAt:created,
    updatedAt:updated,
    conflict:conflict?copy(conflict):null,
    mutationType:String(mutationType||'autosave').slice(0,80),
    surface:String(surface||'unknown').slice(0,120),
    restoreGroupId:restoreGroupId==null?null:String(restoreGroupId),
    retry:{
      attempts:finiteGeneration(record(retry).attempts),
      lastErrorCode:record(retry).lastErrorCode==null?null:String(record(retry).lastErrorCode),
      lastAttemptAt:record(retry).lastAttemptAt?iso(record(retry).lastAttemptAt,now):null,
      nextAttemptAt:record(retry).nextAttemptAt?iso(record(retry).nextAttemptAt,now):null,
    },
  };
}

/** @type {Policy['getOutboxRetryDelay']} */
export function getOutboxRetryDelay(record,now=Date.now){
  const nextAttempt=Date.parse(String(record?.retry?.nextAttemptAt||''));
  if(!Number.isFinite(nextAttempt))return 0;
  return Math.max(0,nextAttempt-nowMilliseconds(now));
}

/** @type {Policy['outboxRetryForGeneration']} */
export function outboxRetryForGeneration(existing,{sameGeneration=false,retry=undefined,now=Date.now}={}){
  const selected=retry===undefined?(sameGeneration?existing?.retry:null):retry,current=nowMilliseconds(now);
  const previousNotBefore=futureIso(record(existing?.retry).nextAttemptAt,current),selectedNotBefore=futureIso(record(selected).nextAttemptAt,current);
  const nextAttemptAt=!previousNotBefore?selectedNotBefore:!selectedNotBefore?previousNotBefore:(Date.parse(previousNotBefore)>=Date.parse(selectedNotBefore)?previousNotBefore:selectedNotBefore);
  return {
    attempts:finiteGeneration(record(selected).attempts),
    lastErrorCode:record(selected).lastErrorCode==null?null:String(record(selected).lastErrorCode),
    lastAttemptAt:record(selected).lastAttemptAt?iso(record(selected).lastAttemptAt,()=>current):null,
    nextAttemptAt,
  };
}

/** @param {import('./cloud-policy.js').RetrySchedulerOptions} [options] */
export function createOutboxRetryScheduler({now=Date.now,setTimer=(callback,delay)=>setTimeout(callback,delay),clearTimer=timer=>clearTimeout(timer),onError=error=>console.error('outbox retry callback',error)}={}){
  const MAX_TIMER_DELAY=2_147_483_647;
  /** @type {number|null} */ let timer=null;let key='',dueAt=0;
  function cancel(){if(timer!==null)clearTimer(timer);timer=null;key='';dueAt=0}
  /** @param {import('./cloud-policy.js').RetryScheduleRecord} record @param {import('./cloud-policy.js').RetryResume} resume */
  function schedule(record,resume){
    const delay=getOutboxRetryDelay(record,now);if(delay<=0){if(timer!==null&&dueAt<=nowMilliseconds(now))cancel();return 0}
    const nextKey=[record?.domain,record?.documentName,finiteGeneration(record?.generation),record?.operationId,record?.retry?.nextAttemptAt].map(value=>String(value??'')).join('|');
    if(timer!==null&&key===nextKey)return delay;
    cancel();key=nextKey;dueAt=nowMilliseconds(now)+delay;
    const arm=()=>{const remaining=getOutboxRetryDelay(record,now);if(remaining>0){timer=setTimer(arm,Math.min(remaining,MAX_TIMER_DELAY));return}timer=null;key='';dueAt=0;try{const result=resume();if(result&&typeof result==='object'&&typeof result.catch==='function')result.catch(onError)}catch(error){onError(error)}};
    timer=setTimer(arm,Math.min(delay,MAX_TIMER_DELAY));return delay;
  }
  function stats(){return {scheduled:timer!==null,key,dueAt}}
  return {schedule,cancel,stats};
}

/** @type {Policy['migrateOutboxRecord']} */
export function migrateOutboxRecord(value,{domain,documentName,baseRevision=0,baseState={},snapshot={},generation=1,now=Date.now}={}){
  if(!value||typeof value!=='object')return null;
  const data=record(value);
  const marker=data.pending===true&&!data.snapshot;
  const sourceSnapshot=marker?snapshot:(data.snapshot??snapshot);
  const sourceBase=data.baseState??baseState;
  const sourceConflict=data.conflict===true?{kind:'unresolved'}:data.conflict;
  return createOutboxRecord({
    domain:data.domain||domain,
    documentName:data.documentName||documentName,
    operationId:data.operationId||data.id,
    generation:Math.max(finiteGeneration(data.generation),finiteGeneration(generation)),
    mutationSeq:Math.max(finiteGeneration(data.mutationSeq),finiteGeneration(data.commitSeq),finiteGeneration(data.generation),finiteGeneration(generation)),
    baseRevision:data.baseRevision??baseRevision,
    baseState:sourceBase,
    snapshot:sourceSnapshot,
    createdAt:data.createdAt||data.savedAt||data.updatedAt,
    updatedAt:data.updatedAt||data.savedAt,
    conflict:sourceConflict,
    retry:data.retry,
    mutationType:data.mutationType,
    surface:data.surface,
    restoreGroupId:data.restoreGroupId,
  },{now});
}

/** @type {Policy['updateOutboxSnapshot']} */
export function updateOutboxSnapshot(existing,{snapshot,generation,mutationSeq,updatedAt,conflict,retry}={}){
  if(!existing)throw new Error('outbox_record_required');
  return createOutboxRecord({...existing,
    snapshot:snapshot??existing.snapshot,
    generation:Math.max(finiteGeneration(existing.generation),finiteGeneration(generation)),
    mutationSeq:Math.max(finiteGeneration(existing.mutationSeq),finiteGeneration(mutationSeq),finiteGeneration(generation)),
    updatedAt:updatedAt||new Date().toISOString(),
    conflict:conflict===undefined?existing.conflict:conflict,
    retry:retry||existing.retry,
  });
}

/** @type {Policy['acknowledgedGenerationMatches']} */
export function acknowledgedGenerationMatches(record,acknowledgedGeneration){
  const acknowledged=Number(acknowledgedGeneration);
  return !!record&&Number.isSafeInteger(acknowledged)&&acknowledged>=0&&finiteGeneration(record.generation)===acknowledged;
}

/** @type {Policy['compareOutboxFreshness']} */
export function compareOutboxFreshness(a,b){
  const generationDelta=finiteGeneration(a?.generation)-finiteGeneration(b?.generation);
  if(generationDelta)return generationDelta;
  const sequenceDelta=finiteGeneration(a?.mutationSeq??a?.commitSeq)-finiteGeneration(b?.mutationSeq??b?.commitSeq);
  if(sequenceDelta)return sequenceDelta;
  const operationDelta=String(a?.operationId||a?.id||'').localeCompare(String(b?.operationId||b?.id||''));
  if(operationDelta)return operationDelta;
  return JSON.stringify(a??null).localeCompare(JSON.stringify(b??null));
}

const CLIENT_INSTANCE_KEY='netunim.sync.client-instance.v1';
let ephemeralClientInstanceId='';
export function clientInstanceId(){
  if(ephemeralClientInstanceId)return ephemeralClientInstanceId;
  try{const existing=localStorage.getItem(CLIENT_INSTANCE_KEY);if(existing)return ephemeralClientInstanceId=existing;const id=globalThis.crypto?.randomUUID?.()||createOperationId('client');localStorage.setItem(CLIENT_INSTANCE_KEY,id);return ephemeralClientInstanceId=id}catch{return ephemeralClientInstanceId=globalThis.crypto?.randomUUID?.()||createOperationId('client-ephemeral')}
}

/** @type {Policy['operationAuditMetadata']} */
export function operationAuditMetadata({site,build='sync-v5',mutationType='autosave',surface='unknown',baseRevision=0,beforeState={},afterState={},collections=[],deleteCount=0,restoreGroupId=null}={}){
  /** @param {unknown} source */
  const counts=source=>Object.fromEntries(collections.map(path=>{const value=String(path).split('.').reduce((x,key)=>record(x)[key],source);return [path,Array.isArray(value)?value.length:0]}));
  return {clientInstanceId:clientInstanceId(),app:String(site||'unknown'),build:String(build),mutationType:String(mutationType),surface:String(surface),baseRevision:finiteRevision(baseRevision),beforeCount:counts(beforeState),afterCount:counts(afterState),deleteCount:finiteGeneration(deleteCount),restoreGroupId:restoreGroupId==null?null:String(restoreGroupId),timestamp:new Date().toISOString()};
}

/** @type {Policy['errorMessage']} */
function errorMessage(input){const data=record(input);return String(record(data.j).message||data.message||data.body||data.txt||record(data.original).message||'')}

/** @type {Policy['retryAfterMilliseconds']} */
function retryAfterMilliseconds(response,input){
  const explicit=Number(record(input).retryAfterMs);
  if(Number.isFinite(explicit)&&explicit>0)return explicit;
  const headers=record(record(response).headers);
  /** @type {unknown} */ const retryAfter=typeof headers.get==='function'?headers.get('retry-after'):null;
  const raw=String(retryAfter||'').trim();
  if(!raw)return null;
  const seconds=Number(raw);
  if(Number.isFinite(seconds)&&seconds>=0)return Math.round(seconds*1000);
  const at=Date.parse(raw);
  return Number.isFinite(at)?Math.max(0,at-Date.now()):null;
}

/** @type {Policy['normalizeCloudError']} */
export function normalizeCloudError(input){
  const data=record(input),response=record(data.r||data.response||input);
  const status=Number(response.status||data.status||0)||null;
  const code=String(record(data.j).code||data.code||data.errorCode||'');
  const message=errorMessage(input);
  const lower=message.toLowerCase();
  /** @type {CloudErrorKind} */ let kind='fatal';
  if(code==='PT429'||lower.includes('save_busy'))kind='busy';
  else if(code==='PT409'||lower.includes('revision_conflict'))kind='revision_conflict';
  else if(status===429||code==='SUPABASE_DATA_API_RATE_LIMIT')kind='rate_limited';
  else if(status===409)kind='conflict';
  else if(status!==null&&[500,502,503,504].includes(status)||['PGRST002','PGRST003','SUPABASE_DATA_API_BACKOFF'].includes(code))kind='service_unavailable';
  else if(status===401||status===403||code==='42501'||code==='cloud_auth_required')kind='auth';
  else if(code==='SUPABASE_NETWORK_TIMEOUT'||String(data.name||'')==='AbortError'||lower.includes('timeout')||lower.includes('timed out'))kind='timeout';
  else if(code==='SUPABASE_NETWORK_UNAVAILABLE'||String(data.name||'')==='TypeError'||lower.includes('failed to fetch')||lower.includes('networkerror')||lower.includes('load failed'))kind='network';
  const retryAfterMs=retryAfterMilliseconds(response,input);
  return {kind,code:code||null,status,retryAfterMs:retryAfterMs||null,original:input};
}

/** @type {Policy['cloudWriteError']} */
export function cloudWriteError(input,fallbackMessage='cloud_write_failed'){
  const normalized=normalizeCloudError(input),data=record(input);
  return Object.assign(new Error(errorMessage(input)||fallbackMessage),{name:'CloudWriteError',kind:normalized.kind,code:normalized.code,status:normalized.status,retryAfterMs:normalized.retryAfterMs,response:data.r||data.response||null,cause:input});
}

export function contentionDelay(attempt=0,{baseMs=300,maxMs=2400,jitterMs=200,random=Math.random}={}){
  return Math.min(maxMs,baseMs*Math.pow(2,Math.max(0,Number(attempt)||0)))+Math.floor(random()*Math.max(0,jitterMs));
}

// Store a not-before deadline in the existing durable control, so polling,
// new edits and a browser restart all respect the same retry budget.
/** @type {Policy['createCloudRetryControl']} */
export function createCloudRetryControl(error,previous=null,{now=Date.now,random=Math.random}={}){
  const normalized=normalizeCloudError(error),attempts=Math.min(Number.MAX_SAFE_INTEGER,finiteGeneration(previous?.attempts)+1),at=nowMilliseconds(now);
  const transient=['busy','rate_limited','service_unavailable','timeout','network'].includes(normalized.kind);
  const cap=Math.min(60000,2000*2**Math.min(attempts-1,16)),sample=Number(random()),jitter=Number.isFinite(sample)?Math.max(0,Math.min(1,sample)):0.5;
  const delay=transient?(normalized.retryAfterMs||Math.floor(cap*(0.75+jitter*0.25))):0;
  return {attempts,lastErrorCode:normalized.code||normalized.kind,lastAttemptAt:new Date(at).toISOString(),nextAttemptAt:delay?new Date(at+delay).toISOString():null};
}

/** @template Result @param {(attempt:number)=>Promise<Result>} write @param {import('./cloud-policy.js').BusyWriteOptions} [options] @returns {Promise<Result|null>} */
export async function runBusyCloudWriteWithPolicy(write,{attempts=CLOUD_WRITE_POLICY.busyAttempts,delay=contentionDelay,sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms))}={}){
  /** @type {Result|null} */ let result=null;
  for(let attempt=0;attempt<Math.max(1,Number(attempts)||1);attempt++){
    result=await write(attempt);
    if(normalizeCloudError(result).kind!=='busy')return result;
    if(attempt+1<attempts)await sleep(delay(attempt));
  }
  return result;
}

/** @template [Result=unknown] @param {import('./cloud-policy.js').SchedulerOptions} [options] */
export function createDataApiScheduler({maxHighBurst=4,canRun=()=>true}={}){
  /** @type {QueueItem<Result>[]} */ const high=[];
  /** @type {QueueItem<Result>[]} */ const low=[];
  /** @type {Map<string,Promise<Result>>} */ const coalesced=new Map();let running=false,highBurst=0;
  function choose(){if(high.length&&(!low.length||highBurst<maxHighBurst)){highBurst++;return high.shift()}if(low.length){highBurst=0;return low.shift()}if(high.length){highBurst=1;return high.shift()}return null}
  async function drain(){if(running)return;running=true;try{for(;;){const item=choose();if(!item)break;try{if(!canRun(item))throw item.blockedError();item.resolve(await item.task())}catch(error){item.reject(error)}}}finally{running=false;if(high.length||low.length)queueMicrotask(drain)}}
  /** @param {()=>Result|PromiseLike<Result>} task @param {{priority?:'high'|'low',key?:string,blockedError?:()=>unknown}} [options] @returns {Promise<Result>} */
  function schedule(task,{priority='low',key='',blockedError=()=>new Error('scheduler_blocked')}={}){
    const normalizedPriority=priority==='high'?'high':'low',coalesceKey=normalizedPriority==='low'&&key?String(key):'';
    const pending=coalesceKey?coalesced.get(coalesceKey):undefined;
    if(pending)return pending;
    /** @type {Promise<Result>} */ const promise=new Promise((resolve,reject)=>{(normalizedPriority==='high'?high:low).push({task,priority:normalizedPriority,key:coalesceKey,blockedError,resolve,reject});queueMicrotask(drain)});
    if(coalesceKey){coalesced.set(coalesceKey,promise);promise.finally(()=>{if(coalesced.get(coalesceKey)===promise)coalesced.delete(coalesceKey)}).catch(()=>{})}
    return promise;
  }
  function stats(){return {running,highQueued:high.length,lowQueued:low.length,coalesced:coalesced.size}}
  return {schedule,stats};
}

// Capture evidence before rebasing. Missing entities are represented by null, never dropped.
/** @type {Policy['structuredSyncConflict']} */
export function structuredSyncConflict({domain,conflicts,base,local,remote,generation,baseRevision,currentRemoteRevision}){
  /** @type {Record<string,string>} */ const aliases={supplier:'suppliers',transaction:'transactions',transactionOrder:'transactions',customerDebt:'customerDebts',customerOrder:'customerOrders',serviceCall:'serviceCalls',note:'notes',inventoryItem:'inventoryItems',inventoryEvent:'inventoryEvents',warehouseOrder:'warehouseOrders',check:'checks'};
  /** @param {unknown} state @param {string} type @param {string|null} id @returns {unknown} */
  const value=(state,type,id)=>{const path=aliases[type]||type;const data=Array.isArray(state)?state:path.split('.').reduce((v,k)=>record(v)[k],state);return structuredClone((id&&Array.isArray(data)?data.find(row=>String(record(row).id??record(row).name)===id):data)??null)};
  return {kind:'entity-conflict',domain,generation,baseRevision,currentRemoteRevision,items:conflicts.map(key=>{const [entityType='',...parts]=String(key).split(':'),entityId=parts.join(':')||null;return {domain,entityType,entityId,base:value(base,entityType,entityId),local:value(local,entityType,entityId),remote:value(remote,entityType,entityId),generation,baseRevision,currentRemoteRevision}})};
}
