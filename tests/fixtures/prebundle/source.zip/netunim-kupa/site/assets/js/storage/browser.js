import {storageCloudHeadIsCurrent} from '../shared/cloud-write-scope.js';
import {beginMeasure} from '../shared/runtime-performance.js';
import {clone} from '../core/values.js';
import {createOperationId} from '../shared/cloud-sync.js';
import {assertValidCloudState} from '../state/validation.js';

// Dependencies are supplied by the composition root; this module has no startup side effects.
export function createStorageBrowser({storageV2=null,model, session, files, normalizeState, prepareKupaCloudState=state=>state}){
let v2CloudStateCache=null;
function nextSnapshotSequence(){
  return session.localSnapshotSeq=Number(session.localSnapshotSeq||0)+1;
}

function persistImmediateBrowserSnapshot(snapshot=model.state,revision=session.dbRevision,options){const done=beginMeasure('kupa:local-snapshot');try{
  if(session.storageProtocolBlocked)throw new Error('storage_protocol_verification_required');
  nextSnapshotSequence();const appMetadata={snapshotSeq:session.localSnapshotSeq,revision:Number(revision||0)},fast=storageV2?.persist?.(snapshot,options,appMetadata);if(!fast?.handled)throw new Error('storage_v2_write_unavailable');
  files.storageV2CommitPromise=fast.committed;if(fast.seq&&v2CloudStateCache?.base){session.storageV2CloudPending=true;v2CloudStateCache={...v2CloudStateCache,seq:Math.max(Number(v2CloudStateCache.seq||0),Number(fast.seq)),pending:true}}return fast.emergencyDurable
}finally{done()}}

async function loadBrowserState(){
  const recovered=await storageV2?.recover?.(null);
  if(!recovered){if(storageV2?.accountV2Active)throw new Error('storage_v2_main_recovery_required');return null}
  session.localSnapshotSeq=Math.max(Number(session.localSnapshotSeq||0),Number(recovered.appMetadata?.snapshotSeq||0));
  return {schemaVersion:2,v2Authoritative:true,snapshotSeq:session.localSnapshotSeq,state:recovered.state,revision:Number(recovered.appMetadata?.revision||0),savedAt:new Date().toISOString()};
}

async function loadBrowserStateReadOnly(){
  const recovered=await storageV2?.recoverReadOnly?.();
  if(!recovered){if(storageV2?.accountV2Active)throw new Error('storage_v2_main_readonly_recovery_required');return null}
  session.localSnapshotSeq=Math.max(Number(session.localSnapshotSeq||0),Number(recovered.appMetadata?.snapshotSeq||0));
  return {schemaVersion:2,v2Authoritative:true,snapshotSeq:session.localSnapshotSeq,state:recovered.state,revision:Number(recovered.appMetadata?.revision||0),savedAt:new Date().toISOString()};
}

async function requestPersistentBrowserStorage(){try{if(navigator.storage?.persist)await navigator.storage.persist()}catch(e){console.error('persistent storage request',e)}}

function storageV2CloudOutboxActive(){return !!storageV2?.primaryReady&&storageCloudHeadIsCurrent(v2CloudStateCache,storageV2?.cloudScope)}
function cacheStorageV2CloudState(state){if(state?.base&&!storageCloudHeadIsCurrent(state,storageV2?.cloudScope))return state;v2CloudStateCache=state;session.storageV2CloudPending=!!(state?.pending||state?.flight);return state}
function settledStorageV2CloudState(seq,base,control=null){return {seq:Number(seq||0),base:base?clone(base):null,flight:null,control:control?clone(control):null,pending:false,pendingDeleteIntents:{},pendingGeneration:0,pendingMutationType:'autosave',pendingSurface:'unknown',afterFlightPending:false,afterFlightDeleteIntents:{},afterFlightGeneration:0,afterFlightMutationType:'autosave',afterFlightSurface:'unknown'}}
function resetStorageV2CloudState(seq,base){const current=Number(seq||0),ackSeq=Number(base?.ackSeq||0),pending=current>ackSeq;return {seq:current,base:base?clone(base):null,flight:null,control:null,pending,pendingDeleteIntents:{},pendingGeneration:pending?Number(session.localGeneration||0):0,pendingMutationType:'autosave',pendingSurface:pending?'epoch-transition':'unknown',afterFlightPending:false,afterFlightDeleteIntents:{},afterFlightGeneration:0,afterFlightMutationType:'autosave',afterFlightSurface:'unknown'}}
function acknowledgedStorageV2CloudState(prior,operationId,receipt,revision,state,control){const sent=prior?.flight?.operationId===operationId?prior.flight:null,ackSeq=Number(receipt?.ackSeq??sent?.endSeq??prior?.base?.ackSeq??0),seq=Math.max(ackSeq,Number(prior?.seq||0)),pending=seq>ackSeq,pendingDeleteIntents=pending&&sent?clone(prior?.afterFlightDeleteIntents||{}):{},pendingGeneration=pending&&sent?Number(prior?.afterFlightGeneration||0):0,pendingMutationType=pending&&sent?(prior?.afterFlightMutationType||'autosave'):'autosave',pendingSurface=pending&&sent?(prior?.afterFlightSurface||'unknown'):'unknown';return {...(prior||{}),seq,base:{...(prior?.base||{}),version:2,revision:Number(revision),state:clone(state),projection:'cloud',ackSeq},flight:null,control:control?clone(control):null,pending,pendingDeleteIntents,pendingGeneration,pendingMutationType,pendingSurface,afterFlightPending:false,afterFlightDeleteIntents:clone(pendingDeleteIntents),afterFlightGeneration:pendingGeneration,afterFlightMutationType:pendingMutationType,afterFlightSurface:pendingSurface}}
async function refreshStorageV2CloudState(){
  if(!storageV2?.primaryReady){cacheStorageV2CloudState(null);return null}
  const state=await storageV2.cloudState({validateBase:value=>assertValidCloudState(value,'Kupa V2 cloud base')});cacheStorageV2CloudState(state);if(storageCloudHeadIsCurrent(state,storageV2.cloudScope)&&state?.control?.conflict)session.cloudConflictPending=true;return state
}
async function refreshStorageV2CloudStateAfterCommit(label,committedState){
  cacheStorageV2CloudState(committedState);
  try{return await refreshStorageV2CloudState()}catch(error){console.warn(`Storage V2 ${label} committed; cloud cache refresh deferred`,error);return committedState}
}
async function materializeStorageV2CloudFlight({throughSeq,snapshot}={}){
  const state=await refreshStorageV2CloudState();if(!state?.base)return null;if(state.flight)return state.flight;
  const flight=await storageV2.materializeFlight({operationId:createOperationId('kupa-v2'),baseRevision:Number(state.base.revision),throughSeq,snapshot,project:value=>prepareKupaCloudState(value),validateCloud:value=>assertValidCloudState(value,'Kupa V2 flight')});const fallback=flight?{...state,flight:clone(flight),pending:true,afterFlightPending:Number(state.seq||0)>Number(flight.endSeq||0)}:state;await refreshStorageV2CloudStateAfterCommit('flight materialization',fallback);return flight
}
async function acknowledgeStorageV2CloudFlight(operationId,revision,state,{currentState=model.state,expectedSeq,control=null}={}){assertValidCloudState(state,'Kupa V2 ACK base');const prior=v2CloudStateCache,receipt=await storageV2.acknowledgeFlight(operationId,Number(revision),state,{validateBase:value=>assertValidCloudState(value,'Kupa V2 ACK base'),currentState,expectedSeq,control,appMetadata:{snapshotSeq:Number(session.localSnapshotSeq||0),revision:Number(revision||0),storageRole:'primary'}}),fallback=acknowledgedStorageV2CloudState(prior,operationId,receipt,revision,state,control);return refreshStorageV2CloudStateAfterCommit('ACK',fallback)}
async function rejectStorageV2CloudFlight(operationId,revision,state,{currentState,expectedSeq,control=null}={}){assertValidCloudState(state,'Kupa V2 rebase base');const prior=v2CloudStateCache,result=await storageV2.rejectFlight(operationId,Number(revision),state,{validateBase:value=>assertValidCloudState(value,'Kupa V2 rebase base'),currentState,expectedSeq,control,appMetadata:{snapshotSeq:Number(session.localSnapshotSeq||0),revision:Number(revision||0),storageRole:'primary'}}),fallback=result?.cloudState||{...(prior||{}),base:clone(result?.base||{...(prior?.base||{}),revision:Number(revision),state:clone(state)}),flight:null,control:result?.control?clone(result.control):control?clone(control):null,pending:!!prior?.pending,afterFlightPending:false,afterFlightDeleteIntents:clone(prior?.pendingDeleteIntents||{}),afterFlightGeneration:Number(prior?.pendingGeneration||0),afterFlightMutationType:prior?.pendingMutationType||'autosave',afterFlightSurface:prior?.pendingSurface||'unknown'};await refreshStorageV2CloudStateAfterCommit('confirmed flight rejection',fallback);return result}
async function setStorageV2CloudControl(control={},options={}){const prior=v2CloudStateCache,result=await storageV2.setCloudControl(control,options),fallback=prior?{...prior,control:clone(result||control)}:prior;await refreshStorageV2CloudStateAfterCommit('control update',fallback);return result}
async function readStorageV2CloudRecovery(options={}){return storageV2.readCloudRecovery({...options,validateBase:value=>assertValidCloudState(value,'V2 recovery base')})}
async function commitStorageV2CloudRecovery(state,options={}){const head=await storageV2.commitCloudRecovery(state,{...options,validateBase:value=>assertValidCloudState(value,'V2 recovery base')});cacheStorageV2CloudState(head);return head}
async function clearStorageV2CloudControl(options={}){const result=await storageV2.clearCloudControl({...options,project:prepareKupaCloudState,validateBase:value=>assertValidCloudState(value,'Kupa V2 reviewed cloud base')});if(!result)return false;const fallback=v2CloudStateCache?{...v2CloudStateCache,control:null}:v2CloudStateCache,current=await refreshStorageV2CloudStateAfterCommit('control clear',fallback);if(options.onlyIfClean)session.cloudConflictPending=!!current?.control?.conflict;return result}
async function replaceStorageV2AuthoritativeState(state=model.state,revision=session.dbRevision){if(!storageV2?.primaryReady)return false;nextSnapshotSequence();const result=await storageV2.replaceAuthoritativeState(state,{appMetadata:{snapshotSeq:Number(session.localSnapshotSeq||0),revision:Number(revision||0),storageRole:'primary'}});await refreshStorageV2CloudStateAfterCommit('authoritative replacement',settledStorageV2CloudState(Number(result?.seq||0),null));return result}
async function replaceStorageV2CurrentState(state=model.state,{expectedSeq=null}={}){const result=await storageV2.replaceCurrentState(state,{expectedSeq,appMetadata:{snapshotSeq:Number(session.localSnapshotSeq||0),revision:Number(session.dbRevision||0),storageRole:'primary'}});await refreshStorageV2CloudStateAfterCommit('checkpoint replacement',v2CloudStateCache);return result}
async function queueStorageV2CloudNormalization(state=model.state,revision=session.dbRevision){
  const snapshot=clone(state),cloud=await refreshStorageV2CloudState(),expectedRevision=Number(revision);
  if(!cloud?.base||cloud.base.revision!==expectedRevision||cloud.pending||cloud.flight||cloud.control)throw new Error('kupa_v2_normalization_head_changed');
  const result=await storageV2.replaceLocalWithPending(snapshot,{boundaryId:`kupa-cloud-normalization:${expectedRevision}:${cloud.seq}`,expectedSeq:cloud.seq,expectedBaseRevision:expectedRevision,mutationType:'cloud-normalization',surface:'kupa.cloud-normalization',validateBase:value=>assertValidCloudState(value,'Kupa V2 normalization base')});
  await refreshStorageV2CloudStateAfterCommit('cloud normalization',v2CloudStateCache?{...v2CloudStateCache,seq:result.seq,pending:true}:cloud);
  return result;
}
async function adoptStorageV2CloudHead(revision,state=model.state,{cloudState=null,expectedHead=null}={}){const cloud=cloudState?clone(cloudState):prepareKupaCloudState(state);assertValidCloudState(cloud,'Kupa V2 adopted cloud head');const result=await storageV2.adoptCloudHead(Number(revision),cloud,state,{expectedHead,validateBase:value=>assertValidCloudState(value,'Kupa V2 adopted cloud head'),appMetadata:{snapshotSeq:Number(session.localSnapshotSeq||0),revision:Number(revision||0),storageRole:'primary'}}),seq=Number(result?.seq??v2CloudStateCache?.seq??0),base={...(v2CloudStateCache?.base||{}),version:2,revision:Number(revision),state:clone(cloud),projection:'cloud',ackSeq:seq};const current=await refreshStorageV2CloudStateAfterCommit('cloud head adoption',settledStorageV2CloudState(seq,base));return {...result,seq:current?.seq??result.seq,revision:current?.base?.revision??result.revision,pending:!!current?.pending,control:current?.control??null}}
async function resetStorageV2CloudHead(revision,state=model.state){if(!storageV2?.primaryReady)return false;nextSnapshotSequence();const cloud=prepareKupaCloudState(state);assertValidCloudState(cloud,'Kupa V2 reset cloud head');const result=await storageV2.resetCloudHead(Number(revision),cloud,state,{validateBase:value=>assertValidCloudState(value,'Kupa V2 reset cloud head'),appMetadata:{snapshotSeq:Number(session.localSnapshotSeq||0),revision:Number(revision||0),storageRole:'primary'}});session.cloudConflictPending=false;const ackSeq=Number(result?.ackSeq||0),base={version:2,owner:v2CloudStateCache?.base?.owner,epoch:result?.epoch,revision:Number(revision),state:clone(cloud),projection:'cloud',ackSeq};await refreshStorageV2CloudStateAfterCommit('cloud reset',resetStorageV2CloudState(Number(result?.seq||0),base));return result}

return { persistImmediateBrowserSnapshot, loadBrowserState, loadBrowserStateReadOnly, requestPersistentBrowserStorage, storageV2CloudOutboxActive, refreshStorageV2CloudState, materializeStorageV2CloudFlight, acknowledgeStorageV2CloudFlight, rejectStorageV2CloudFlight, setStorageV2CloudControl,readStorageV2CloudRecovery,commitStorageV2CloudRecovery, clearStorageV2CloudControl, replaceStorageV2AuthoritativeState, replaceStorageV2CurrentState, queueStorageV2CloudNormalization, adoptStorageV2CloudHead, resetStorageV2CloudHead, get storageV2CommitPromise(){return storageV2?.commitPromise||files.storageV2CommitPromise||Promise.resolve()} };
}
