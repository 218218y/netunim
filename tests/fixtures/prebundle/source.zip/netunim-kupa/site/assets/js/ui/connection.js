import {esc} from '../core/values.js';

// Dependencies are supplied by the composition root; this module has no startup side effects.
export function createUiConnection({session, tab, setCloudHeaderStatus, storeSupaSession, openSupabaseLoginModal, openCloudUsingSavedSession, supaProjectRef, supaConfigured, getRememberedHandle, connectDirectory, captureSourceScope}){
function configureCloudConnectButton(label='פתח קופה מהענן',action='open'){
  session.cloudConnectAction=action;
  const b=document.getElementById('openCloud');
  if(b)b.textContent=label;
}

async function handleCloudConnectButton(){
  if(session.cloudConnectAction==='reauth'){
    storeSupaSession(null);
    session.cloudAuthNoDocument=false;
    setCloudHeaderStatus('off','ענן: נדרשת התחברות');
    openSupabaseLoginModal('open');
    return;
  }
  await openCloudUsingSavedSession({interactive:true});
}

function showSecondaryTabGuard(){const readOnly=!tab.primaryTab;const banner=document.getElementById('readOnlyTabBanner');if(banner)banner.hidden=!readOnly;document.body.classList.toggle('secondary-readonly',readOnly);if(readOnly){const connect=document.getElementById('connectScreen');if(connect)connect.style.display='none'}}

function setConnectUI({title,text,note,showLast=false,showChoose=false,showFile=false,showCloud=false}){
  document.getElementById('connectScreen').style.display='flex';
  document.getElementById('connectTitle').textContent=title;
  document.getElementById('connectText').innerHTML=text;
  document.getElementById('connectNote').innerHTML=note||'';
  const actions=document.getElementById('connectActions');
  actions.style.display=(showLast||showChoose||showFile||showCloud)?'flex':'none';
  document.getElementById('openLastFolder').style.display=showLast?'inline-block':'none';
  document.getElementById('chooseFolder').style.display=showChoose?'inline-block':'none';
  document.getElementById('chooseDataFile').style.display=showFile?'inline-block':'none';
  document.getElementById('openCloud').style.display=showCloud?'inline-block':'none';
}

function showFirstRun(){
  configureCloudConnectButton('פתח קופה מהענן','open');
  setConnectUI({title:'פתיחת קופת העסק',text:'אפשר לעבוד מתיקייה מקומית ניידת או לפתוח את אותה קופה מהענן Supabase.',note:`לתיקייה מקומית בוחרים פעם אחת את תיקיית <b>ניהול_קופה_ניידת</b>. לענן מתחברים פעם אחת בכל מחשב; לאחר התחברות מוצלחת ה-Session נשמרת ומתרעננת אוטומטית. ${supaConfigured()?`פרויקט: <b>${esc(supaProjectRef())}</b>.`:''}`,showChoose:true,showFile:!window.showDirectoryPicker,showCloud:supaConfigured()});
}

function showRememberedFolderPrompt(note='הדפדפן דורש אישור מחדש לגישה לתיקייה השמורה.'){
  configureCloudConnectButton('פתח קופה מהענן','open');
  setConnectUI({title:'הקופה השמורה מוכנה',text:'התיקייה כבר שמורה. לחץ פעם אחת כדי לאשר את הגישה מחדש — אין צורך לבחור אותה מחדש.',note,showLast:true,showChoose:true,showFile:!window.showDirectoryPicker,showCloud:supaConfigured()});
}

async function tryAutoOpenRemembered(){
  try{
    const assertCurrent=captureSourceScope(),last=await getRememberedHandle();assertCurrent();
    if(!last)return false;
    const permission=await last.queryPermission?.({mode:'readwrite'});
    assertCurrent();
    if(permission==='granted'){
      await connectDirectory(last,{automatic:true,permissionGranted:true});return true;
    }
    showRememberedFolderPrompt();
    return true;
  }catch(e){console.error(e);showRememberedFolderPrompt(e?.message==='storage_v2_local_file_requires_confirmation'?'הקובץ והתמונה השמורה בדפדפן שונים. כדי למנוע החלפה אוטומטית של נתונים, יש לפתוח את התיקייה במפורש לאחר בדיקת הגיבוי.':'נמצאה תיקייה שמורה, אך לא ניתן היה להתחבר אליה אוטומטית. נסה לפתוח אותה מחדש.');return true}
}

return { configureCloudConnectButton, handleCloudConnectButton, showSecondaryTabGuard, setConnectUI, showFirstRun, showRememberedFolderPrompt, tryAutoOpenRemembered };
}
