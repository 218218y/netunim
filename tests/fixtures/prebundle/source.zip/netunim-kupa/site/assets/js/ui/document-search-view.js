import {esc} from '../core/values.js';

export function documentSearchEmptyHtml(label,partial=false){
  const message=partial?'החיפוש לא הושלם; עדיין לא אותרו התאמות בחלק שנבדק.':`לא נמצאו תוצאות ב־${label}.`;
  return `<div class="global-search-source-empty">${esc(message)}</div>`;
}

export function documentSearchPartialHtml(partial){
  return partial?'<div class="document-search-partial" role="status">החיפוש הושלם באופן חלקי. ייתכן שקיימות תוצאות נוספות; אפשר לצמצם לתיקייה או לנסות שוב.</div>':'';
}

export function bytes(value){const size=Number(value);if(!Number.isFinite(size)||size<0)return '';if(size<1024)return `${size} B`;if(size<1024*1024)return `${Math.round(size/1024)} KB`;return `${(size/1024/1024).toFixed(size<10*1024*1024?1:0)} MB`}
export function localDate(value){const time=Date.parse(value||'');if(!Number.isFinite(time))return '';try{return new Intl.DateTimeFormat('he-IL',{dateStyle:'short',timeStyle:'short'}).format(new Date(time))}catch{return ''}}
export function safeCloudViewUrl(value){try{const url=new URL(String(value||''));const host=url.hostname.toLowerCase();return url.protocol==='https:'&&(host==='google.com'||host.endsWith('.google.com'))?url.toString():''}catch{return ''}}
export function fileKindLabel(item){if(item?.isDirectory)return 'תיקייה';const ext=String(item?.extension||'').toUpperCase();return ext||'קובץ'}
export function documentIconKind(item){if(item?.isDirectory)return 'folder';const ext=String(item?.extension||'').toLowerCase();if(ext==='pdf')return 'pdf';if(['doc','docx','docm','dot','dotx','rtf'].includes(ext))return 'word';if(['xls','xlsx','xlsm','xlsb','csv'].includes(ext))return 'excel';if(['ppt','pptx','pptm','pps','ppsx'].includes(ext))return 'powerpoint';if(['txt','md','log','ini','json','xml','html','htm','css','js','mjs','ts','csv'].includes(ext))return 'text';if(['jpg','jpeg','png','gif','bmp','webp','svg','tif','tiff'].includes(ext))return 'image';if(['zip','7z','rar','tar','gz'].includes(ext))return 'archive';return 'file'}

function documentSortHeader(label,field,scope,sort={}){
  const active=sort?.field===field,direction=active&&sort?.direction==='asc'?'asc':'desc',ariaSort=active?(direction==='asc'?'ascending':'descending'):'none',indicator=active?(direction==='asc'?'▲':'▼'):'';
  return `<span role="columnheader" aria-sort="${ariaSort}"><button class="document-results-sort${active?' active':''}" type="button" data-document-sort-field="${esc(field)}" data-document-sort-scope="${esc(scope)}" title="מיין לפי ${esc(label)}" aria-label="מיין לפי ${esc(label)}${active?`, כעת ${direction==='asc'?'בסדר עולה':'בסדר יורד'}`:''}">${esc(label)}<i aria-hidden="true">${indicator}</i></button></span>`;
}

export function documentResultsTableHtml(rows,mode,{label='',hint='',title='',hasMore=false,selectedKey='',sortScope=mode,sort={field:'modified',direction:'desc'},register=()=>{}}={}){
  const header=`<div class="document-results-head" role="row">${documentSortHeader('שם','name',sortScope,sort)}${documentSortHeader('נתיב','path',sortScope,sort)}${documentSortHeader('גודל','size',sortScope,sort)}${documentSortHeader('עודכן','modified',sortScope,sort)}</div>`;
  const body=(Array.isArray(rows)?rows:[]).map(item=>{const icon=documentIconKind(item),key=`${mode}:${item.id}`;register(key,item);const selected=selectedKey===key?' selected':'';return `<button class="global-search-result document-search-row${selected}" type="button" data-document-result-id="${esc(item.id)}" data-document-result-key="${esc(key)}" data-document-search-mode="${esc(mode)}" title="${esc(title)}"><span class="document-result-name"><i class="document-result-icon ${esc(icon)}" aria-hidden="true"></i><span><b>${esc(item.name||(item.isDirectory?'תיקייה':'קובץ'))}</b><small>${esc(fileKindLabel(item))}</small></span></span><span class="document-result-path">${esc(item.relativePath||'')}</span><span class="document-result-size">${item.isDirectory?'—':esc(bytes(item.size)||'—')}</span><span class="document-result-date">${esc(localDate(item.modified)||'—')}</span></button>`}).join('');
  return `<section class="document-results-table"><div class="document-results-summary"><b>${esc(label)}</b><span>${esc(`${(Array.isArray(rows)?rows:[]).length}${hasMore?'+':''}`)}</span><small>${esc(hint)}</small></div>${header}<div class="document-results-body">${body}</div></section>`;
}
export function previewDetailsHtml(data){const rows=[[data.isDirectory?'סוג':'סיומת',data.isDirectory?'תיקייה':(String(data.extension||'').toUpperCase()||'קובץ')],['גודל',data.isDirectory?'—':bytes(data.size)],['עודכן',localDate(data.modified)],['נתיב',data.fullPath]].filter(([,value])=>value);return `<dl class="document-preview-details">${rows.map(([label,value])=>`<div><dt>${esc(label)}</dt><dd>${esc(value)}</dd></div>`).join('')}</dl>`}
export function previewTextLabel(data){return data.source==='office-text-fallback'?'טקסט שחולץ ממסמך Office':data.source==='everything-content'?'טקסט שחולץ על־ידי Everything':data.source==='google-drive-content'?'קובץ טקסט מ-Google Drive':'קובץ טקסט'}
function compactContext(value,{tail=false,limit=42}={}){const clean=String(value||'').replace(/\s+/g,' ').trim();if(clean.length<=limit)return clean;return tail?`…${clean.slice(-limit).replace(/^\S*\s?/,'')||clean.slice(-limit)}`:`${clean.slice(0,limit).replace(/\s?\S*$/,'')||clean.slice(0,limit)}…`}
export function snippetHtml(snippet,fallbackMatch=''){if(!snippet)return '';const before=compactContext(snippet.before,{tail:true,limit:34}),after=compactContext(snippet.after,{limit:42});return `<span class="document-preview-match-before">${snippet.leading&&!before.startsWith('…')?'…':''}${esc(before)}</span><mark class="document-preview-match-term">${esc(snippet.match||fallbackMatch)}</mark><span class="document-preview-match-after">${esc(after)}${snippet.trailing&&!after.endsWith('…')?'…':''}</span>`}

export function previewMatchBarPresentation(info,{viewerState={},index=0,query=''}={}){
  if(!info?.active)return null;
  const state=viewerState||{},externalCurrent=Math.max(0,Number(state.current)||0),externalTotal=Math.max(0,Number(state.total)||0),snippets=Array.isArray(info.snippets)?info.snippets:[];
  const requestedIndex=externalCurrent?externalCurrent-1:Number(index)||0,safeIndex=snippets.length?Math.max(0,Math.min(snippets.length-1,requestedIndex)):0,snippet=state.snippet||snippets[safeIndex]||null;
  const total=externalTotal||Number(info.count)||snippets.length;
  if(!total)return {index:0,total:0,html:'<div class="document-preview-match-loading muted">לא נמצאו התאמות ניתנות להצגה במסמך.</div>'};
  const countLabel=state.capped||info.capped?`${total}+`:String(total),position=`${externalCurrent||safeIndex+1}/${total}`,location=state.location?`<span class="document-preview-match-location">${esc(state.location)}</span>`:'';
  const html=`<div class="document-preview-match-summary"><b>${esc(countLabel)} התאמות</b>${location}${info.truncated?'<span>בתצוגה החלקית</span>':''}</div><div class="document-preview-match-context">${snippet?snippetHtml(snippet,query):'<span class="document-preview-match-empty">הקובץ תאם לחיפוש, אך לא ניתן להפיק קטע הקשר.</span>'}</div>${total>1?`<div class="document-preview-match-nav"><button type="button" data-preview-match-prev aria-label="התאמה קודמת">‹</button><span>${esc(position)}</span><button type="button" data-preview-match-next aria-label="התאמה הבאה">›</button></div>`:''}`;
  return {index:safeIndex,total,html};
}
