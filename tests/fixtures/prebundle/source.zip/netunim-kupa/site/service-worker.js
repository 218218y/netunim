'use strict';
const CACHE_PREFIX='kupa-app-shell-';
const CACHE='kupa-app-shell-esm-c3a94828a6d5';
const SHELL=[
  './',
  './index.html',
  './reset-local.html',
  './assets/app.css',
  './assets/app.js',
  './assets/js/cloud/auth.js',
  './assets/js/cloud/main-document-write.js',
  './assets/js/cloud/session-store.js',
  './assets/js/cloud/transport.js',
  './assets/js/composition/bank-queries.js',
  './assets/js/composition/bank.js',
  './assets/js/composition/cash.js',
  './assets/js/composition/checks.js',
  './assets/js/composition/cloud.js',
  './assets/js/composition/credit.js',
  './assets/js/composition/dashboard.js',
  './assets/js/composition/expenses.js',
  './assets/js/composition/finance-cloud.js',
  './assets/js/composition/finance.js',
  './assets/js/composition/main-sync.js',
  './assets/js/composition/notes.js',
  './assets/js/composition/search.js',
  './assets/js/composition/state-normalization.js',
  './assets/js/composition/storage-v2.js',
  './assets/js/composition/tax-calculator.js',
  './assets/js/connectivity.js',
  './assets/js/core/dates.js',
  './assets/js/core/money.js',
  './assets/js/core/search.js',
  './assets/js/core/values.js',
  './assets/js/domains/bank/alerts.js',
  './assets/js/domains/bank/archive-model.js',
  './assets/js/domains/bank/archive-readout.js',
  './assets/js/domains/bank/connection-forms.js',
  './assets/js/domains/bank/connection-owner.js',
  './assets/js/domains/bank/controller.js',
  './assets/js/domains/bank/feed.js',
  './assets/js/domains/bank/local-snapshot-view.js',
  './assets/js/domains/bank/local-snapshot.js',
  './assets/js/domains/bank/manual-snapshot.js',
  './assets/js/domains/bank/model.js',
  './assets/js/domains/bank/refresh.js',
  './assets/js/domains/bank/selectors.js',
  './assets/js/domains/bank/snapshot-commands.js',
  './assets/js/domains/bank/snapshot-policy.js',
  './assets/js/domains/bank/view.js',
  './assets/js/domains/cash/controller.js',
  './assets/js/domains/cash/editor.js',
  './assets/js/domains/cash/model.js',
  './assets/js/domains/cash/selectors.js',
  './assets/js/domains/cash/view.js',
  './assets/js/domains/checks/editor.js',
  './assets/js/domains/checks/model.js',
  './assets/js/domains/checks/selectors.js',
  './assets/js/domains/checks/view.js',
  './assets/js/domains/credit/connection-owner.js',
  './assets/js/domains/credit/controller.js',
  './assets/js/domains/credit/detail-read-model.js',
  './assets/js/domains/credit/editor.js',
  './assets/js/domains/credit/model.js',
  './assets/js/domains/credit/publication.js',
  './assets/js/domains/credit/refresh.js',
  './assets/js/domains/credit/selectors.js',
  './assets/js/domains/credit/sync-feed.js',
  './assets/js/domains/credit/sync-view.js',
  './assets/js/domains/credit/view.js',
  './assets/js/domains/dashboard/controller.js',
  './assets/js/domains/dashboard/model.js',
  './assets/js/domains/dashboard/view.js',
  './assets/js/domains/documents/document-result-sort.js',
  './assets/js/domains/documents/document-search-navigator.js',
  './assets/js/domains/documents/docx-search-viewer.js',
  './assets/js/domains/documents/pdf-search-viewer.js',
  './assets/js/domains/documents/pdf-text-fragments.js',
  './assets/js/domains/documents/pdfjs-core.js',
  './assets/js/domains/documents/pdfjs-runtime-config.js',
  './assets/js/domains/documents/preview-modules.js',
  './assets/js/domains/documents/search-source.js',
  './assets/js/domains/documents/spreadsheet-preview-worker.js',
  './assets/js/domains/documents/spreadsheet-search-viewer.js',
  './assets/js/domains/documents/text-search-viewer.js',
  './assets/js/domains/expenses/editor.js',
  './assets/js/domains/expenses/model.js',
  './assets/js/domains/expenses/view.js',
  './assets/js/domains/notes/commands.js',
  './assets/js/domains/notes/controller.js',
  './assets/js/domains/records/commands.js',
  './assets/js/domains/search/model.js',
  './assets/js/integrations/bank-bridge.js',
  './assets/js/integrations/document-bridge.js',
  './assets/js/integrations/document-google-drive.js',
  './assets/js/lifecycle.js',
  './assets/js/main.js',
  './assets/js/platform/credit-preferences.js',
  './assets/js/shared/action-registry.js',
  './assets/js/shared/app-release-startup.js',
  './assets/js/shared/authenticated-account-scope.js',
  './assets/js/shared/automatic-backup-runtime.js',
  './assets/js/shared/backup-browser-resources.js',
  './assets/js/shared/backup-file-authority.js',
  './assets/js/shared/bank-archive-policy.js',
  './assets/js/shared/bank-archive-read-batch.js',
  './assets/js/shared/bank-archive-reconciliation.js',
  './assets/js/shared/bank-balance-result.js',
  './assets/js/shared/bank-bridge-client.js',
  './assets/js/shared/bank-business-evidence.js',
  './assets/js/shared/bank-cheque-images.js',
  './assets/js/shared/bank-feed.js',
  './assets/js/shared/bank-money-value.js',
  './assets/js/shared/bank-recurring-debits.js',
  './assets/js/shared/bank-response-records.js',
  './assets/js/shared/bank-snapshot-receipt.js',
  './assets/js/shared/bank-transaction-evidence.js',
  './assets/js/shared/bank-transaction-identity.js',
  './assets/js/shared/bank-transaction-order.js',
  './assets/js/shared/bridge-pairing-scope.js',
  './assets/js/shared/browser-account-observation.js',
  './assets/js/shared/browser-bridge-platform.js',
  './assets/js/shared/browser-google-drive-platform.js',
  './assets/js/shared/browser-tab-lock-platform.js',
  './assets/js/shared/business-field-merge.js',
  './assets/js/shared/calendar.js',
  './assets/js/shared/cashflow-breakdown.js',
  './assets/js/shared/cashflow-notification.js',
  './assets/js/shared/cashflow.js',
  './assets/js/shared/check-bank-refresh.js',
  './assets/js/shared/check-bank-review.js',
  './assets/js/shared/check-forecast.js',
  './assets/js/shared/check-series.js',
  './assets/js/shared/check-summary.js',
  './assets/js/shared/clean-view-cache.js',
  './assets/js/shared/cloud-ack-diagnostic.js',
  './assets/js/shared/cloud-backups.js',
  './assets/js/shared/cloud-checkpoint-publication.js',
  './assets/js/shared/cloud-post-ack-recovery.js',
  './assets/js/shared/cloud-read-records.js',
  './assets/js/shared/cloud-recovery-runtime.js',
  './assets/js/shared/cloud-sync.js',
  './assets/js/shared/cloud-write-authority.js',
  './assets/js/shared/cloud-write-scope.js',
  './assets/js/shared/credit-billing-cycles.js',
  './assets/js/shared/credit-card-account.js',
  './assets/js/shared/credit-card-order-view.js',
  './assets/js/shared/credit-card-order.js',
  './assets/js/shared/credit-cooldown-policy.js',
  './assets/js/shared/credit-detail-controls.js',
  './assets/js/shared/credit-detail-policy.js',
  './assets/js/shared/credit-detail-sections.js',
  './assets/js/shared/credit-history.js',
  './assets/js/shared/credit-refresh-result.js',
  './assets/js/shared/credit-sync-policy.js',
  './assets/js/shared/credit-transaction-evidence.js',
  './assets/js/shared/customer-debt-progress.js',
  './assets/js/shared/data-invariants.js',
  './assets/js/shared/debounced-task.js',
  './assets/js/shared/document-bridge-client.js',
  './assets/js/shared/document-search-composition.js',
  './assets/js/shared/document-text-search-worker.js',
  './assets/js/shared/document-text-search.js',
  './assets/js/shared/document-write-ack.js',
  './assets/js/shared/domain-revisions.js',
  './assets/js/shared/events.js',
  './assets/js/shared/finance-browser-effects.js',
  './assets/js/shared/finance-connection-file-selection.js',
  './assets/js/shared/finance-connection-import-capability.js',
  './assets/js/shared/finance-connection-import-runtime.js',
  './assets/js/shared/finance-connection-import.js',
  './assets/js/shared/finance-derivations.js',
  './assets/js/shared/finance-fence.js',
  './assets/js/shared/finance-lease-heartbeat.js',
  './assets/js/shared/finance-lease-owner.js',
  './assets/js/shared/finance-lease-receipt.js',
  './assets/js/shared/finance-lease-transport.js',
  './assets/js/shared/finance-refresh-policy.js',
  './assets/js/shared/finance-write-receipt.js',
  './assets/js/shared/global-document-search.css',
  './assets/js/shared/global-document-search.js',
  './assets/js/shared/google-drive-client.js',
  './assets/js/shared/google-drive-document-policy.js',
  './assets/js/shared/html.js',
  './assets/js/shared/indexed-db-connection.js',
  './assets/js/shared/kupa-cashflow.js',
  './assets/js/shared/lazy-global-document-search.js',
  './assets/js/shared/local-mutation-admission.js',
  './assets/js/shared/local-site-reset-page.js',
  './assets/js/shared/local-site-reset.js',
  './assets/js/shared/main-sync-browser.js',
  './assets/js/shared/notes-sheet-model.js',
  './assets/js/shared/notes-workbook-merge.js',
  './assets/js/shared/notes-workbook.css',
  './assets/js/shared/notes-workbook.js',
  './assets/js/shared/observation-time.js',
  './assets/js/shared/orders-finance.js',
  './assets/js/shared/response-evidence.js',
  './assets/js/shared/restore-group-keys.js',
  './assets/js/shared/restore-groups.js',
  './assets/js/shared/restore-response-records.js',
  './assets/js/shared/restore-review-scope.js',
  './assets/js/shared/restore-server-recovery.js',
  './assets/js/shared/result-pages.js',
  './assets/js/shared/revision-selector.js',
  './assets/js/shared/runtime-performance.js',
  './assets/js/shared/runtime-polling.js',
  './assets/js/shared/runtime-resources.js',
  './assets/js/shared/runtime-task-owner.js',
  './assets/js/shared/search-fragments.js',
  './assets/js/shared/search-scheduler.js',
  './assets/js/shared/search.js',
  './assets/js/shared/shared-checks-contract.js',
  './assets/js/shared/shared-checks-flight.js',
  './assets/js/shared/shared-checks-status.js',
  './assets/js/shared/shared-checks-storage-v2.js',
  './assets/js/shared/shared-checks-v2-composition.js',
  './assets/js/shared/shared-checks-v2-runtime.js',
  './assets/js/shared/spreadsheet-model.js',
  './assets/js/shared/spreadsheet-remote.js',
  './assets/js/shared/spreadsheet-store.js',
  './assets/js/shared/spreadsheet-sync.js',
  './assets/js/shared/spreadsheet-workspace.js',
  './assets/js/shared/startup-task.js',
  './assets/js/shared/startup-timing.js',
  './assets/js/shared/storage-checkpoint.js',
  './assets/js/shared/storage-cloud-ack.js',
  './assets/js/shared/storage-cloud-records.js',
  './assets/js/shared/storage-cloud-recovery.js',
  './assets/js/shared/storage-cloud-status.js',
  './assets/js/shared/storage-journal-authority.js',
  './assets/js/shared/storage-journal-idb.js',
  './assets/js/shared/storage-journal-model.js',
  './assets/js/shared/storage-journal.js',
  './assets/js/shared/storage-json-codec.js',
  './assets/js/shared/storage-metrics.js',
  './assets/js/shared/storage-operation.js',
  './assets/js/shared/storage-owner-binding.js',
  './assets/js/shared/storage-owner-idb.js',
  './assets/js/shared/storage-owner.js',
  './assets/js/shared/storage-records.js',
  './assets/js/shared/storage-startup-protocol.js',
  './assets/js/shared/storage-startup-recovery.js',
  './assets/js/shared/storage-v2-account-marker.js',
  './assets/js/shared/storage-v2-activation-cache.js',
  './assets/js/shared/storage-v2-bootstrap.js',
  './assets/js/shared/storage-v2-boundary.js',
  './assets/js/shared/storage-v2-detached-target.js',
  './assets/js/shared/storage-v2-fenced-recovery.js',
  './assets/js/shared/storage-v2-local-birth.js',
  './assets/js/shared/storage-v2-local-import.js',
  './assets/js/shared/storage-v2-owner-transfer.js',
  './assets/js/shared/storage-v2-persisted-compat.js',
  './assets/js/shared/storage-v2-restore.js',
  './assets/js/shared/storage-v2-runtime.js',
  './assets/js/shared/storage-v2-schema.js',
  './assets/js/shared/storage-v2-server-protocol.js',
  './assets/js/shared/sync-capabilities.js',
  './assets/js/shared/sync-incident-adapters.js',
  './assets/js/shared/sync-incident-feature.js',
  './assets/js/shared/sync-incident-model.js',
  './assets/js/shared/sync-incident-monitor.js',
  './assets/js/shared/sync-incident-registry.js',
  './assets/js/shared/sync-incident-store.js',
  './assets/js/shared/sync-incident-ui.js',
  './assets/js/shared/sync-incidents.css',
  './assets/js/shared/sync-journal-incident.js',
  './assets/js/shared/sync-json.js',
  './assets/js/shared/sync-status.js',
  './assets/js/shared/tab-lock.js',
  './assets/js/shared/tax-calculator/arnona.js',
  './assets/js/shared/tax-calculator/compute.js',
  './assets/js/shared/tax-calculator/contracts.js',
  './assets/js/shared/tax-calculator/entry.js',
  './assets/js/shared/tax-calculator/remote.js',
  './assets/js/shared/tax-calculator/rules.js',
  './assets/js/shared/tax-calculator/store.js',
  './assets/js/shared/tax-calculator/style.css',
  './assets/js/shared/tax-calculator/sync.js',
  './assets/js/shared/tax-calculator/view.js',
  './assets/js/shared/tax-calculator/workspace.js',
  './assets/js/startup/cloud-hydration.js',
  './assets/js/startup/connection.js',
  './assets/js/startup/local-services.js',
  './assets/js/state/constants.js',
  './assets/js/state/contexts.js',
  './assets/js/state/normalization.js',
  './assets/js/state/revisions.js',
  './assets/js/state/serialization.js',
  './assets/js/state/validation.js',
  './assets/js/storage/backup.js',
  './assets/js/storage/browser.js',
  './assets/js/storage/files.js',
  './assets/js/storage/indexed-db.js',
  './assets/js/storage/local-commit.js',
  './assets/js/storage/local-file-adoption.js',
  './assets/js/storage/local-file-mirror.js',
  './assets/js/storage/local-source-transition.js',
  './assets/js/storage/main-state.js',
  './assets/js/storage/persistence.js',
  './assets/js/storage/save-publication.js',
  './assets/js/storage/tab-lock.js',
  './assets/js/storage/v2-cloud-ports.js',
  './assets/js/sync/ack-publication.js',
  './assets/js/sync/checks-merge.js',
  './assets/js/sync/checks-persistence.js',
  './assets/js/sync/checks-state.js',
  './assets/js/sync/checks.js',
  './assets/js/sync/confirmation.js',
  './assets/js/sync/document.js',
  './assets/js/sync/legacy-card-migration.js',
  './assets/js/sync/merge-records.js',
  './assets/js/sync/merge.js',
  './assets/js/sync/polling.js',
  './assets/js/sync/recovery.js',
  './assets/js/sync/remote-adoption.js',
  './assets/js/sync/save-operation.js',
  './assets/js/sync/state-projection.js',
  './assets/js/sync/write-flight.js',
  './assets/js/ui-primitives/local-search.js',
  './assets/js/ui/action-packs/backup.js',
  './assets/js/ui/action-packs/bank.js',
  './assets/js/ui/action-packs/cash.js',
  './assets/js/ui/action-packs/checks.js',
  './assets/js/ui/action-packs/cloud.js',
  './assets/js/ui/action-packs/credit.js',
  './assets/js/ui/action-packs/expenses.js',
  './assets/js/ui/action-packs/notes.js',
  './assets/js/ui/action-packs/settings.js',
  './assets/js/ui/action-packs/shell.js',
  './assets/js/ui/action-packs/tax-calculator.js',
  './assets/js/ui/actions.js',
  './assets/js/ui/backup-catalog.js',
  './assets/js/ui/backup-local.js',
  './assets/js/ui/backup-presentation.js',
  './assets/js/ui/backup-restore.js',
  './assets/js/ui/backup.js',
  './assets/js/ui/bulk.js',
  './assets/js/ui/cloud-authentication.js',
  './assets/js/ui/cloud-opening.js',
  './assets/js/ui/cloud-reset.js',
  './assets/js/ui/cloud-review.js',
  './assets/js/ui/cloud-session.js',
  './assets/js/ui/cloud-transfer.js',
  './assets/js/ui/cloud.js',
  './assets/js/ui/connection.js',
  './assets/js/ui/credit-connection-dialog.js',
  './assets/js/ui/credit-connection-input.js',
  './assets/js/ui/date-editor.js',
  './assets/js/ui/document-index-refresh.js',
  './assets/js/ui/document-result-menu.js',
  './assets/js/ui/document-search-connection-view.js',
  './assets/js/ui/document-search-content-options.js',
  './assets/js/ui/document-search-error-view.js',
  './assets/js/ui/document-search-file-type.js',
  './assets/js/ui/document-search-folder-scope.js',
  './assets/js/ui/document-search-pipeline.js',
  './assets/js/ui/document-search-view.js',
  './assets/js/ui/folders.js',
  './assets/js/ui/global-search-refs.js',
  './assets/js/ui/global-search.js',
  './assets/js/ui/modal.js',
  './assets/js/ui/navigation.js',
  './assets/js/ui/secondary-read-only-actions.js',
  './assets/js/ui/settings.js',
  './assets/js/ui/sidebar.js',
  './assets/js/ui/status.js',
  './manifest.webmanifest',
  './supabase/config.js',
  './favicon.ico',
  './favicon-16x16.png',
  './favicon-32x32.png',
  './apple-touch-icon.png',
  './android-chrome-192x192.png',
  './android-chrome-512x512.png'
];

const SHELL_PATHS=new Set(SHELL.map(item=>new URL(item,self.location.href||self.location.origin+'/').pathname));
const LAZY_RUNTIME_PREFIXES=['./assets/vendor/'].map(item=>new URL(item,self.location.href||self.location.origin+'/').pathname);
const isLazyRuntimePath=pathname=>LAZY_RUNTIME_PREFIXES.some(prefix=>pathname.startsWith(prefix));
const sameRelease=response=>response?.headers.get('X-Netunim-Release')===CACHE;

async function fetchRelease(request){
  const url=new URL(typeof request==='string'?request:request.url,self.location.href||self.location.origin+'/');
  // CDN revalidation can retain an old release header for unchanged bytes. Bind
  // transport URLs to this release; canonical cache keys remain unchanged.
  url.searchParams.set('__netunim_release',CACHE);
  const response=await fetch(url.href,{cache:'reload',...(typeof request==='string'?{}:{headers:request.headers,credentials:request.credentials})});
  if(!response.ok||!sameRelease(response))throw new Error('shell_release_mismatch');
  return response;
}

self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    await Promise.all(SHELL.map(async path=>{await cache.put(path,await fetchRelease(path));}));
    // Existing tabs finish with their controlling release. The new worker waits
    // until those tabs close; it never swaps a running page's module graph.
    if(!self.registration?.active)await self.skipWaiting();
  })());
});

self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith(CACHE_PREFIX)&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));
});

// A waiting release can take over only when its requesting bootstrap is the
// sole scoped window. All other tabs keep their original controller and cache.
self.addEventListener('message',event=>{
  if(event.data?.type!=='netunim-activate-single-client')return;
  event.waitUntil((async()=>{
    const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});
    const allowed=windows.length===1&&windows[0].id===event.source?.id;
    event.ports?.[0]?.postMessage({allowed});
    if(allowed)await self.skipWaiting();
  })());
});

self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin)return;
  const lazyRuntime=isLazyRuntimePath(url.pathname);
  if(event.request.mode!=='navigate'&&!SHELL_PATHS.has(url.pathname)&&!lazyRuntime)return;

  // Third-party document runtimes are immutable, version-pinned assets intentionally kept
  // out of the install shell. On first request, persist the clone before
  // resolving the response promise. This makes the lazy cache deterministic:
  // callers that have received the module can rely on it already being cached.
  if(lazyRuntime){
    const lazyResponse=(async()=>{
      try{
        const response=await fetchRelease(event.request);
        if(response.ok){
          const cache=await caches.open(CACHE);
          await cache.put(event.request,response.clone());
        }
        return response;
      }catch(error){
        const cache=await caches.open(CACHE);
        const cached=await cache.match(event.request);
        if(sameRelease(cached))return cached;
        throw error;
      }
    })();
    event.waitUntil(lazyResponse.then(()=>undefined,()=>undefined));
    event.respondWith(lazyResponse);
    return;
  }

  // Network-first prevents a previously installed PWA from keeping stale HTML,
  // config or icons after a deployment. Offline remains fully supported by the
  // verified app-shell cache and navigation fallback.
  const network=fetchRelease(event.request);
  const cacheWrite=network.then(response=>{
    if(!response.ok||!SHELL_PATHS.has(url.pathname))return;
    return caches.open(CACHE).then(cache=>cache.put(event.request,response.clone()));
  }).catch(()=>{});
  event.waitUntil(cacheWrite);
  event.respondWith(
    network.catch(async()=>{
      const cache=await caches.open(CACHE);
      const cached=await cache.match(event.request);
      if(sameRelease(cached))return cached;
      if(event.request.mode==='navigate'){
        const index=await cache.match('./index.html');
        if(sameRelease(index))return index;
      }
      throw new Error('offline_and_not_cached');
    })
  );
});
