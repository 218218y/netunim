import {createAuthenticatedAccountScope} from '../shared/authenticated-account-scope.js';
import {createBrowserAccountObservation} from '../shared/browser-account-observation.js';
import {createSyncCapabilityGate,syncRequestNeedsCapabilities,isSyncIncidentRpc} from '../shared/sync-capabilities.js';
import {supabaseConfig as SUPA_CONFIG} from '../../../supabase/config.js';
import {CLOUD_SESSION_KEY, CLOUD_EMAIL_KEY, CLOUD_AUTO_KEY} from '../state/constants.js';
import {createDataApiScheduler} from '../shared/cloud-sync.js';

const SUPA_NETWORK_ATTEMPTS=3;
// Background read timeouts do not imply write failure.
const SUPA_BACKGROUND_FAILURES_TO_TRIP=2;
const SUPA_NETWORK_TIMEOUT_MS=20*1000;
const SUPA_BACKGROUND_TIMEOUT_MS=8*1000;
const SUPA_NETWORK_BACKOFF_MS=[500,1500];
const SUPA_DATA_API_BACKOFF_MS=[15_000,30_000,60_000,120_000];
const SUPA_DATA_API_RETRY_STATUSES=new Set([502,503,504]);
let supaDataApiFailureCount=0;
let supaDataApiBackgroundFailures=0;
let supaDataApiBlockedUntil=0;
let supaDataApiBlockCode='';
let supaIncidentBlockedUntil=0,supaIncidentFailures=0;
let refreshPromise=null;
let cloudAuthInstanceSequence=0;

function isSupaDataApiPath(path){return /^\/rest\/v1(?:\/|\?|$)/.test(String(path||''))}
function responseRetryAfterMs(response){const raw=String(response?.headers?.get?.('retry-after')||'').trim();if(!raw)return 0;const seconds=Number(raw);if(Number.isFinite(seconds)&&seconds>=0)return Math.round(seconds*1000);const at=Date.parse(raw);return Number.isFinite(at)?Math.max(0,at-Date.now()):0}
function supaDataApiBlockedError(until=supaDataApiBlockedUntil){const retryAfterMs=Math.max(0,until-Date.now()),
  rateLimited=supaDataApiBlockCode==='SUPABASE_DATA_API_RATE_LIMIT',e=new Error(rateLimited?`Supabase ביקש להאט בקשות. ניסיון נוסף יתבצע בעוד ${Math.max(1,Math.ceil(retryAfterMs/1000))} שניות.`:`Supabase Data API במצב התאוששות. ניסיון נוסף יתבצע בעוד ${Math.max(1,Math.ceil(retryAfterMs/1000))} שניות.`);e.code=rateLimited?'SUPABASE_DATA_API_RATE_LIMIT':'SUPABASE_DATA_API_BACKOFF';e.retryAfterMs=retryAfterMs;return e}
function resetSupaDataApiBreaker(){supaDataApiFailureCount=0;supaDataApiBackgroundFailures=0;supaDataApiBlockedUntil=0;supaDataApiBlockCode=''}
function tripSupaDataApiBreaker(){supaDataApiBackgroundFailures=0;const index=Math.min(supaDataApiFailureCount,SUPA_DATA_API_BACKOFF_MS.length-1),delay=SUPA_DATA_API_BACKOFF_MS[index];supaDataApiFailureCount=Math.min(supaDataApiFailureCount+1,SUPA_DATA_API_BACKOFF_MS.length);supaDataApiBlockedUntil=Math.max(supaDataApiBlockedUntil,Date.now()+delay);supaDataApiBlockCode='SUPABASE_DATA_API_BACKOFF';return delay}
function tripSupaDataApiRateLimit(response){supaDataApiBackgroundFailures=0;const delay=Math.max(1_000,responseRetryAfterMs(response)||SUPA_DATA_API_BACKOFF_MS[0]);supaDataApiBlockedUntil=Math.max(supaDataApiBlockedUntil,Date.now()+delay);supaDataApiBlockCode='SUPABASE_DATA_API_RATE_LIMIT';return delay}
function isSupaDataApiTransportFailure(error){return ['SUPABASE_NETWORK_TIMEOUT','SUPABASE_NETWORK_UNAVAILABLE'].includes(String(error?.code||''))}
function recordSupaDataApiTransportFailure({priority,safeRead,retried}){
  // Retried reads/uncertain writes trip; corroborate single background GET/HEAD failures.
  if(priority==='low'&&safeRead&&!retried&&++supaDataApiBackgroundFailures<SUPA_BACKGROUND_FAILURES_TO_TRIP)return;
  tripSupaDataApiBreaker();
}
async function responseIsAppBusy(response){if(Number(response?.status)!==429)return false;try{const body=await response.clone().json();return String(body?.code||'')==='PT429'||String(body?.message||'').toLowerCase().includes('save_busy')}catch{return false}}
const supaDataApiScheduler=createDataApiScheduler({maxHighBurst:4});
function tripIncidentBackoff(){supaIncidentBlockedUntil=Date.now()+SUPA_DATA_API_BACKOFF_MS[Math.min(supaIncidentFailures++,3)]}
async function withSupaDataApiSlot(path,request,{priority='low',coalesceKey='',safeRead=false,retried=false}={}){
  if(!isSupaDataApiPath(path))return request();
  const scheduled=supaDataApiScheduler.schedule(async()=>{
    const monitoring=isSyncIncidentRpc(path),blocked=Date.now()<supaDataApiBlockedUntil;
    if(blocked&&(!monitoring||supaDataApiBlockCode==='SUPABASE_DATA_API_RATE_LIMIT'))throw supaDataApiBlockedError();
    if(monitoring&&Date.now()<supaIncidentBlockedUntil)throw supaDataApiBlockedError(supaIncidentBlockedUntil);
    try{
      const response=await request(),status=Number(response?.status);
      // Monitoring never trips/resets business backoff; keep global throttling.
      if(monitoring){
        if(status===429&&!await responseIsAppBusy(response))tripSupaDataApiRateLimit(response);
        else if(status>=500||status===429)tripIncidentBackoff();
        else{supaIncidentBlockedUntil=0;supaIncidentFailures=0}
        return response;
      }
      if(SUPA_DATA_API_RETRY_STATUSES.has(status))tripSupaDataApiBreaker();
      else if(status===429){if(await responseIsAppBusy(response))resetSupaDataApiBreaker();else tripSupaDataApiRateLimit(response)}
      else resetSupaDataApiBreaker();
      return response;
    }catch(error){if(isSupaDataApiTransportFailure(error)){if(monitoring)tripIncidentBackoff();else recordSupaDataApiTransportFailure({priority,safeRead,retried})}throw error}
  },{priority,key:coalesceKey,blockedError:supaDataApiBlockedError});
  return scheduled.then(response=>typeof response?.clone==='function'?response.clone():response);
}

function sleep(ms,signal){return new Promise((resolve,reject)=>{const abort=()=>{clearTimeout(timer);reject(signal.reason)},timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve()},ms);signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort()})}
function isSupaNetworkError(error){const name=String(error?.name||''),message=String(error?.message||error||'').toLowerCase();return name==='AbortError'||name==='TypeError'||message.includes('failed to fetch')||message.includes('networkerror')||message.includes('load failed')}
function supaNetworkFailure(error,{attempts=1}={}){const timedOut=String(error?.name||'')==='AbortError',repeated=attempts>1,e=new Error(timedOut?(repeated?'החיבור ל-Supabase לא הגיב בזמן גם לאחר ניסיונות חוזרים.':'החיבור ל-Supabase לא הגיב בזמן.'):(repeated?'לא ניתן להגיע כרגע ל-Supabase גם לאחר ניסיונות חוזרים.':'לא ניתן להגיע כרגע ל-Supabase.'));e.code=timedOut?'SUPABASE_NETWORK_TIMEOUT':'SUPABASE_NETWORK_UNAVAILABLE';e.cause=error;return e}
async function fetchSupaNetwork(url,options,{retry=false,timeoutMs=SUPA_NETWORK_TIMEOUT_MS,assertRequestScope,withRequestScope}={}){
  const attempts=retry?SUPA_NETWORK_ATTEMPTS:1;let lastError=null;
  for(let attempt=0;attempt<attempts;attempt++){
    options.signal?.throwIfAborted();assertRequestScope?.();
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.max(1000,Number(timeoutMs)||SUPA_NETWORK_TIMEOUT_MS));
    try{const send=()=>{assertRequestScope?.();return fetch(url,{...options,signal:options.signal?AbortSignal.any([controller.signal,options.signal]):controller.signal})};return await (withRequestScope?withRequestScope(send):send())}
    catch(error){options.signal?.throwIfAborted();lastError=error;if(!isSupaNetworkError(error))throw error;if(attempt+1>=attempts)throw supaNetworkFailure(error,{attempts});await sleep(SUPA_NETWORK_BACKOFF_MS[Math.min(attempt,SUPA_NETWORK_BACKOFF_MS.length-1)],options.signal)}
    finally{clearTimeout(timer)}
  }
  throw supaNetworkFailure(lastError,{attempts})
}

export function createCloudAuth({session={},assertSessionOwner=()=>true}){
const capabilityGate=createSyncCapabilityGate(async()=>{const response=await supaFetch('/rest/v1/rpc/get_netunim_sync_capabilities',{method:'POST',body:'{}',dataPriority:'high'});if(!response.ok)throw Object.assign(new Error('ה־DB אינו תואם לגרסת האתר; יש להשלים את עדכון מסד הנתונים.'),{code:'netunim_sync_capabilities_missing'});return response.json()});
async function ensureSyncCapabilities(){session.syncCapabilitiesChecking=true;try{const ready=await capabilityGate.ensure();session.syncCapabilitiesError=null;return ready}catch(error){session.syncCapabilitiesError=error;throw error}finally{session.syncCapabilitiesChecking=false}}
function supaConfigured(){return /^https:\/\//.test(SUPA_CONFIG.url||'')&&String(SUPA_CONFIG.publishableKey||'').length>20}

function supaHeaders(token){return {'Content-Type':'application/json','apikey':SUPA_CONFIG.publishableKey,...(token?{'Authorization':'Bearer '+token}:{})}}

const accountScope=createAuthenticatedAccountScope({loadSession:loadSession});
const cloudAuthInstance=++cloudAuthInstanceSequence;
const requestGuards=new WeakMap();let requestGuardSequence=0;
function guardCoalesceIdentity(guard){
  if(typeof guard!=='function')return 'none';
  let id=requestGuards.get(guard);
  if(!id){id=++requestGuardSequence;requestGuards.set(guard,id)}
  return String(id);
}
const accountObservation=createBrowserAccountObservation({scope:accountScope,sessionKey:CLOUD_SESSION_KEY,rereadSession:loadSession});

function loadSession(){try{return JSON.parse(localStorage.getItem(CLOUD_SESSION_KEY)||'null')}catch(e){return null}}

function saveSession(s,{refresh=false}={}){capabilityGate.reset();if(s)localStorage.setItem(CLOUD_SESSION_KEY,JSON.stringify(s));else localStorage.removeItem(CLOUD_SESSION_KEY);accountScope.replace(s,{refresh})}

function cloudAuthRequired(message='נדרשת התחברות לענן'){const error=new Error(message);error.code='cloud_auth_required';return error}

async function authPassword(email,password){const r=await fetch(`${SUPA_CONFIG.url}/auth/v1/token?grant_type=password`,{method:'POST',headers:supaHeaders(),body:JSON.stringify({email,password})});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error_description||j.msg||j.message||'התחברות נכשלה');j.expires_at=Math.floor(Date.now()/1000)+Number(j.expires_in||3600);assertSessionOwner(j);saveSession(j);localStorage.setItem(CLOUD_EMAIL_KEY,email);return j}

async function authPasswordForLocalReset(email,password){if(!supaConfigured())throw new Error('הגדרת Supabase חסרה');const r=await fetch(`${SUPA_CONFIG.url}/auth/v1/token?grant_type=password`,{method:'POST',headers:supaHeaders(),body:JSON.stringify({email,password})});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error_description||j.msg||j.message||'התחברות נכשלה');if(!String(j?.access_token||'').trim())throw new Error('Supabase לא החזיר token תקין לאימות האיפוס');j.expires_at=Math.floor(Date.now()/1000)+Number(j.expires_in||3600);return j}

async function localResetReadOnlyFetch(resetSession,path){const token=String(resetSession?.access_token||'').trim(),safePath=String(path||'');if(!token)throw Object.assign(new Error('נדרשת התחברות מחדש לענן לצורך האיפוס'),{code:'local_reset_auth_required'});if(!safePath.startsWith('/rest/v1/')||safePath.includes('/rpc/'))throw new Error('local_reset_read_only_path_rejected');const r=await fetchSupaNetwork(SUPA_CONFIG.url+safePath,{method:'GET',headers:supaHeaders(token)},{retry:true,timeoutMs:SUPA_NETWORK_TIMEOUT_MS});if(r.status===401)throw Object.assign(new Error('פג תוקף אימות הענן לצורך האיפוס'),{code:'local_reset_auth_required'});return r}

async function refreshSession({force=true,observedAccessToken=''}={}){if(refreshPromise)return refreshPromise;refreshPromise=(async()=>{const refresh=async()=>{const scope=accountScope.current();const s=loadSession();if(!s?.refresh_token)throw cloudAuthRequired('נדרשת התחברות מחדש לענן');assertSessionOwner(s);if(observedAccessToken&&s.access_token&&s.access_token!==observedAccessToken)return s;if(!force&&Number(s.expires_at||0)>=Math.floor(Date.now()/1000)+60)return s;const r=await fetch(`${SUPA_CONFIG.url}/auth/v1/token?grant_type=refresh_token`,{method:'POST',headers:supaHeaders(),body:JSON.stringify({refresh_token:s.refresh_token})});const j=await r.json().catch(()=>({}));accountScope.assertCurrent(scope);if(!r.ok){saveSession(null);throw cloudAuthRequired('פג תוקף ההתחברות לענן')};j.expires_at=Math.floor(Date.now()/1000)+Number(j.expires_in||3600);assertSessionOwner(j);saveSession(j,{refresh:true});return j};return globalThis.navigator?.locks?.request?navigator.locks.request('netunim-orders-auth-refresh',{mode:'exclusive'},refresh):refresh()})().finally(()=>{refreshPromise=null});return refreshPromise}

async function ensureSession(){let s=loadSession();if(!s)throw cloudAuthRequired();assertSessionOwner(s);if(Number(s.expires_at||0)<Math.floor(Date.now()/1000)+60)s=await refreshSession({force:false,observedAccessToken:s.access_token});return s}

async function supaFetch(path,opt={}){
  // Capture login before async work; fence queued/in-flight responses.
  const requestScope=accountScope.current(),assertRequestScope=opt.assertRequestScope;
  const assertCurrent=()=>{
    // Caller cancellation survives.
    assertRequestScope?.();
    opt.signal?.throwIfAborted();
    // Preserve login-required; fence later logins.
    if(requestScope.owner||accountScope.current().epoch!==requestScope.epoch)accountScope.assertCurrent(requestScope);
  };
  assertCurrent();if(syncRequestNeedsCapabilities(path,opt.method))await ensureSyncCapabilities();
  assertCurrent();
  const {networkRetry,networkTimeoutMs,dataPriority,coalesceKey,assertRequestScope:_callerGuard,withRequestScope,...requestOptions}=opt,
    method=String(requestOptions.method||'GET').toUpperCase(),safeRead=method==='GET'||method==='HEAD',
    priority=dataPriority||(safeRead?'low':'high'),retry=networkRetry===undefined?(safeRead&&priority==='high'):!!networkRetry,
    timeoutMs=networkTimeoutMs??(priority==='low'?SUPA_BACKGROUND_TIMEOUT_MS:SUPA_NETWORK_TIMEOUT_MS);
  const request=async()=>{
    assertCurrent();let s=await ensureSession();assertCurrent();
    let r=await fetchSupaNetwork(SUPA_CONFIG.url+path,{...requestOptions,headers:{...supaHeaders(s.access_token),...(requestOptions.headers||{})}},{retry,timeoutMs,assertRequestScope:assertCurrent,withRequestScope});
    assertCurrent();
    if(r.status===401){
      const observed=s.access_token;s=await refreshSession({force:true,observedAccessToken:observed});assertCurrent();r=await fetchSupaNetwork(SUPA_CONFIG.url+path,{...requestOptions,headers:{...supaHeaders(s.access_token),...(requestOptions.headers||{})}},{retry,timeoutMs,assertRequestScope:assertCurrent,withRequestScope});assertCurrent()}
    return r;
  };
  // Keys require the same login/operation guard.
  const key=coalesceKey||(priority==='low'&&safeRead?`${method}:${path}`:'');
  const scopedKey=key?`${cloudAuthInstance}:${requestScope.epoch}:${requestScope.owner||''}:${guardCoalesceIdentity(assertRequestScope)}:${key}`:'';
  return withSupaDataApiSlot(path,request,{priority,safeRead,retried:retry,coalesceKey:scopedKey});
}

function cloudEnabled(){const current=loadSession();if(localStorage.getItem(CLOUD_AUTO_KEY)!=='1'||!current)return false;try{return assertSessionOwner(current,{allowMissing:true})===true}catch{return false}}

return { getAccountScope:accountScope.current, subscribeAccountScope:accountObservation.subscribe, ensureSyncCapabilities, supaConfigured, supaHeaders, loadSession, saveSession, authPassword, authPasswordForLocalReset, localResetReadOnlyFetch, refreshSession, ensureSession, supaFetch, cloudEnabled };
}
