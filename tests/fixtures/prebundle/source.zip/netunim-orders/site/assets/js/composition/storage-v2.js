import {mergeSharedChecks} from '../sync/checks-merge.js';
import {createStorageStartupProtocol,createStorageStartupAdmission} from '../shared/storage-startup-protocol.js';
import {createStorageOwnerBinding} from '../shared/storage-owner.js';
import {createStorageV2BootstrapCoordinator} from '../shared/storage-v2-bootstrap.js';
import {createStorageV2LocalBirth,verifyStorageV2LocalEngine} from '../shared/storage-v2-local-birth.js';
import {createStorageV2OwnerTransfer} from '../shared/storage-v2-owner-transfer.js';
import {createStorageV2DetachedTarget} from '../shared/storage-v2-detached-target.js';
import {createStorageV2FencedRecovery} from '../shared/storage-v2-fenced-recovery.js';
import {createStorageV2Runtime,storageV2Mode} from '../shared/storage-v2-runtime.js';
import {createSharedChecksV2Runtime} from '../shared/shared-checks-v2-runtime.js';
import {createStorageV2CloudPorts} from '../storage/v2-cloud-ports.js';
import {createSharedChecksV2Composition} from '../shared/shared-checks-v2-composition.js';
import {assertValidOrderCloudState} from '../state/validation.js';
import {INITIAL_STATE} from '../state/constants.js';
import {createSharedChecksStorageV2} from '../shared/shared-checks-storage-v2.js';
import {equalSyncJson} from '../shared/cloud-sync.js';

// Owns the Orders V2 storage lifecycle. main.js supplies application ports.
export function createOrdersStorageV2Coordinator({tab,session,storage=globalThis.localStorage}={}){
  if(!tab||!session)throw new Error('orders_storage_v2_tab_required');
  const owner=createStorageOwnerBinding({app:'orders',primary:()=>tab.primaryTab});
  const bootstrap=createStorageV2BootstrapCoordinator({app:'orders',owner:()=>owner.current(),primary:()=>tab.primaryTab});
  let localBirth=null,ownerTransfer=null,fencedRecovery=null,transferRebinding=false,ports=null;
  const requirePorts=()=>{if(!ports)throw new Error('orders_storage_v2_not_configured');return ports};
  const startupProtocol=createStorageStartupProtocol({
    ownership:{current:()=>owner.current(),authenticated:()=>requirePorts().cloudAuth.loadSession()?.user?.id||null},
    markers:{account:()=>requirePorts().verifyStorageV2AccountMarker(),local:()=>{requirePorts();return verifyStorageV2LocalEngine({app:'orders',owner:()=>owner.current()})}},
    account:{read:()=>requirePorts().cloudTransport.readStorageProtocolState(),recoverAccount:()=>{requirePorts();return fencedRecovery.recover()}},
  });
  const startupAdmission=createStorageStartupAdmission({protocol:startupProtocol,primary:()=>tab.primaryTab,
    transfer:{preparing:()=>!!ownerTransfer?.preparing||transferRebinding,resume:resumeStorageV2OwnerTransfer},
    birth:{preparing:()=>!!localBirth?.preparing,ensure:()=>{requirePorts();return localBirth.begin()}}});
  const preparing=()=>owner.locked||transferRebinding||!!ownerTransfer?.preparing||!!localBirth?.preparing||!!(bootstrap.hasGroup&&bootstrap.group?.phase!=='complete');
  const mode=()=>storageV2Mode('orders',storage,owner.current(),{preparing:preparing()});
  const createRuntime=options=>createStorageV2Runtime({app:'orders',owner:()=>owner.current(),primary:()=>tab.primaryTab&&owner.writable,captureCommitAuthority:()=>owner.captureCommitAuthority(),mode,...options});
  const createCloudPorts=storageBrowser=>({...createStorageV2CloudPorts(storageBrowser),storageV2PrimaryRequested:()=>['primary','preparing'].includes(mode())});
  const createSharedComposition=({model,checksSession,domainRevisions,main,stateNormalization,getCloudTransport})=>createSharedChecksV2Composition({
    site:'orders',owner:()=>owner.current(),primary:()=>tab.primaryTab&&owner.writable,captureCommitAuthority:()=>owner.captureCommitAuthority(),preparing,
    model,checksSession,eventsKey:'checksBankEvents',domainRevisions,main,
    merge:mergeSharedChecks,readRemote:(...args)=>getCloudTransport().readSharedChecksCloud(...args),rpc:(...args)=>getCloudTransport().rpcSaveSharedChecksV2(...args),refreshBankRpc:(...args)=>getCloudTransport().refreshCheckBankMatches(...args),
    validateMainCloud:state=>assertValidOrderCloudState(state,'Orders V2 restore cloud state'),applyMainState:state=>{const previous=model.state;model.state=stateNormalization.normalizeState({...state,checks:previous.checks});domainRevisions.reconcile(previous,model.state,{forceAll:true})},
  });

  function configure(next){
    if(ports)throw new Error('orders_storage_v2_already_configured');
    for(const name of ['main','checks','folder','backup'])for(const method of ['cancelPending','drain']){
      if(typeof next.saveRuntime?.[name]?.[method]!=='function')throw new TypeError(`orders_save_runtime_${name}_${method}_required`);
    }
    ports=next;
    const p=requirePorts();
    async function quiesceSaves(){
      p.saveRuntime.main.cancelPending();p.saveRuntime.checks.cancelPending();
      p.saveRuntime.folder.cancelPending();
      p.saveRuntime.backup.cancelPending();
      await Promise.all([p.saveRuntime.main.drain(),p.saveRuntime.checks.drain()]);
      if(session.localUndurableGenerations?.size)throw new Error('storage_uncommitted_mutation');
      p.saveRuntime.folder.cancelPending();await p.saveRuntime.folder.drain();
      // Main/Checks and accepted working-file completion may submit a backup.
      p.saveRuntime.backup.cancelPending();await p.saveRuntime.backup.drain();
    }
    fencedRecovery=createStorageV2FencedRecovery({app:'orders',owner:()=>owner.current(),primary:()=>tab.primaryTab&&owner.writable,refreshOwnerBinding:()=>owner.refresh(),
      authenticatedOwner:()=>p.cloudAuth.loadSession()?.user?.id||null,readProtocolState:()=>p.cloudTransport.readStorageProtocolState(),
      readMainRemote:()=>p.cloudTransport.readCloud(),projectMainRemote:row=>p.stateSnapshots.prepareCloudState(row.state),
      readSharedRemote:()=>p.cloudTransport.readSharedChecksCloud(),projectSharedRemote:row=>row.state,
      composeMainState:(cloud,shared)=>p.prepareV2Checkpoint(p.stateNormalization.normalizeState({...cloud,checks:shared.checks})),
      projectMainState:state=>p.stateSnapshots.prepareCloudState(state),validateMainState:state=>p.validateMainState(state),
      validateMainCloud:state=>assertValidOrderCloudState(state,'Orders fenced recovery cloud state'),storage});
    localBirth=createStorageV2LocalBirth({
      app:'orders',owner:()=>owner.current(),primary:()=>tab.primaryTab&&owner.writable,
      main:p.mainStorageV2,shared:p.sharedChecksV2,
      enableShared:()=>{if(!p.sharedChecksV2Composition.lockPreparation())throw new Error('orders_local_birth_shared_lock_required')},
      readSource:async()=>{
        const mainState=p.prepareV2Checkpoint(INITIAL_STATE);delete mainState.checks;
        return {mainState,sharedState:{checks:[],bankEvents:[]}};
      },
      quiesce:async()=>{
        await quiesceSaves();
        await p.syncDocument.quiesceForStorageCutover();
        await p.saveRuntime.checks.drain();
        const pending=[p.files.storageV2CommitPromise].filter(Boolean);
        if(pending.length)await Promise.all(pending);
      },
    });
    const fixedMain=identity=>createStorageV2Runtime({
      app:'orders',owner:()=>identity,primary:()=>tab.primaryTab,mode:()=> 'preparing',
      validate:state=>p.validateMainState(state),prepareCheckpoint:p.prepareV2Checkpoint,
    });
    const fixedShared=identity=>{
      let snapshot={checks:[],bankEvents:[]};
      return createSharedChecksV2Runtime({
        site:'orders',owner:()=>identity,primary:()=>tab.primaryTab,mode:()=> 'preparing',
        readState:()=>snapshot,applyState:state=>{snapshot=structuredClone(state)},
        merge:mergeSharedChecks,
        readRemote:()=>p.cloudTransport.readSharedChecksCloud(),
        rpc:(...args)=>p.cloudTransport.rpcSaveSharedChecksV2(...args),
      });
    };
    async function settleSource({sourceOwner}){
      if(owner.current()!==sourceOwner||!owner.locked)throw new Error('orders_transfer_source_lock_required');
      const marked=sourceOwner==='local'
        ?await verifyStorageV2LocalEngine({app:'orders',owner:()=>sourceOwner})
        :await p.verifyStorageV2AccountMarker();
      if(marked!==true||owner.current()!==sourceOwner||!owner.locked)throw new Error('orders_transfer_source_not_primary');
      await quiesceSaves();
      await p.syncDocument.quiesceForStorageCutover();
      await p.saveRuntime.checks.drain();
      const pending=[p.files.storageV2CommitPromise,p.sharedChecksV2.commitPromise].filter(Boolean);
      if(pending.length)await Promise.all(pending);
      // The durable V2 source marker and the recovered Main/Shared heads below
      // decide transfer safety. Retired V1 records have no authority here.
      const main=fixedMain(sourceOwner),shared=fixedShared(sourceOwner),mainRecovered=await main.recover(null),sharedRecovered=await shared.recover();
      if(!mainRecovered?.state||!sharedRecovered?.state)throw new Error('orders_transfer_source_checkpoint_missing');
      const mainCloud=await main.cloudState({validateBase:state=>assertValidOrderCloudState(state,'Orders transfer source cloud base')}),sharedCloud=await shared.cloudState();
      if(mainCloud.flight||mainCloud.control||sharedCloud.flight||sharedCloud.control)throw new Error('orders_transfer_source_flight_unsettled');
      if(sourceOwner==='local'){
        if(mainCloud.base||sharedCloud.base)throw new Error('orders_transfer_local_cloud_head_unexpected');
      }else if(!mainCloud.base||!sharedCloud.base||mainCloud.pending||sharedCloud.pending||mainCloud.base.ackSeq!==mainCloud.seq||sharedCloud.base.ackSeq!==sharedCloud.seq)throw new Error('orders_transfer_source_pending');
      const sharedState={checks:structuredClone(sharedRecovered.state.checks),bankEvents:structuredClone(sharedRecovered.state.bankEvents)},fullState=p.prepareV2Checkpoint({...mainRecovered.state,checks:sharedState.checks}),cloudState=p.stateSnapshots.prepareCloudState(fullState);
      return {main:{state:cloudState,fullState,seq:mainRecovered.seq},shared:{state:sharedState,seq:sharedRecovered.seq}};
    }
    function detachedTarget(targetOwner){
      const main=fixedMain(targetOwner),shared=fixedShared(targetOwner);
      return createStorageV2DetachedTarget({
        app:'orders',targetOwner,primary:()=>tab.primaryTab,main,shared,
        readMainRemote:()=>p.cloudTransport.readCloud(),projectMainRemote:row=>p.stateSnapshots.prepareCloudState(row.state),
        readSharedRemote:()=>p.cloudTransport.readSharedChecksCloud(),projectSharedRemote:row=>({checks:row.state.checks,bankEvents:row.state.bankEvents}),
        composeMainState:(mainState,sharedState)=>p.prepareV2Checkpoint(p.stateNormalization.normalizeState({...structuredClone(mainState),checks:structuredClone(sharedState.checks)})),
        projectMainState:state=>p.stateSnapshots.prepareCloudState(state),emptyMainState:()=>p.prepareV2Checkpoint(INITIAL_STATE),
        validateMainCloud:state=>assertValidOrderCloudState(state,'Orders detached target cloud state'),
        rpcMain:(...args)=>p.cloudTransport.rpcSaveV2(...args),rpcShared:(...args)=>p.cloudTransport.rpcSaveSharedChecksV2(...args),
      });
    }
    ownerTransfer=createStorageV2OwnerTransfer({
      app:'orders',ownerBinding:owner,primary:()=>tab.primaryTab,online:()=>globalThis.navigator?.onLine!==false,
      authOwner:()=>p.cloudAuth.loadSession()?.user?.id||null,settleSource,createDetachedTarget:detachedTarget,
      installTargetView:async({mainState,sharedState,mainRevision,sharedRevision})=>{
        const previous=p.model.state;
        p.model.state=p.stateNormalization.normalizeState({...structuredClone(mainState),checks:structuredClone(sharedState.checks)});
        p.domainRevisions.reconcile(previous,p.model.state,{forceAll:true});
        p.session.cloudRevision=mainRevision;p.session.lastCloudState=p.stateSnapshots.prepareCloudState(p.model.state);
        p.session.cloudSaveRequested=false;p.session.storageV2CloudPending=false;p.session.cloudConflictBlocked=false;p.session.cloudUpdatedAt=null;
        p.checksSession.checksCloudRevision=sharedRevision;p.checksSession.checksCloudBase=structuredClone(sharedState.checks);
        p.checksSession.checksBankEvents=structuredClone(sharedState.bankEvents);p.checksSession.checksSaveRequested=false;
      },
    });
    return true;
  }
  async function rebindTransferredOwner(){
    const p=requirePorts();
    const main=await p.mainStorageV2.recoverForOwner({intent:'load-account'});
    if(!main?.state||await p.sharedChecksV2Composition.recoverPrimary()!==true)throw new Error('orders_transfer_active_recovery_failed');
    const previous=p.model.state;
    p.model.state=p.stateNormalization.normalizeState({...structuredClone(main.state),checks:structuredClone(p.model.state.checks)});
    p.domainRevisions.reconcile(previous,p.model.state,{forceAll:true});
  }
  async function finishOwnerTransfer(action){
    const initialOwner=owner.current();transferRebinding=true;
    try{
      const result=await action();
      if(result)await rebindTransferredOwner();
      transferRebinding=false;
      return result;
    }catch(error){
      // After activation, failed active-runtime hydration cannot expose a
      // writable target with an old source model in the same tab.
      if(owner.locked||owner.current()===initialOwner)transferRebinding=false;
      throw error;
    }
  }
  async function startStorageV2OwnerTransfer(options){return finishOwnerTransfer(()=>ownerTransfer.start(options))}
  async function resumeStorageV2OwnerTransfer(){return finishOwnerTransfer(()=>ownerTransfer.resume())}
  function ownerAdoption(){return owner.status().binding?.pendingAdoption||null}
  async function recoverShared(){
    const p=requirePorts(),recovered=await p.sharedChecksV2Composition.recoverPrimary();
    return recovered;
  }
  async function captureFolderState(){
    const p=requirePorts(),identity=owner.current(),generation=session.localGeneration;
    const account=JSON.stringify(p.cloudAuth.getAccountScope()),scope=JSON.stringify(p.mainStorageV2.cloudScope);
    const mainCommit=p.mainStorageV2.commitPromise,sharedCommit=p.sharedChecksV2.commitPromise;
    const current=()=>tab.primaryTab&&owner.writable&&!preparing()&&owner.current()===identity&&generation===session.localGeneration
      &&account===JSON.stringify(p.cloudAuth.getAccountScope())&&scope===JSON.stringify(p.mainStorageV2.cloudScope)
      &&p.mainStorageV2.primaryReady&&p.sharedChecksV2.localReady&&!session.localUndurableGenerations?.size
      &&!p.mainStorageV2.durabilityAtRisk&&!p.sharedChecksV2.durabilityAtRisk
      &&mainCommit===p.mainStorageV2.commitPromise&&sharedCommit===p.sharedChecksV2.commitPromise;
    if(!current())return null;
    await Promise.all([mainCommit,sharedCommit]);if(!current())return null;
    // Read without publishing into the visible model. A backup is never an
    // implicit admission or recovery of an optimistic draft.
    const shared=createSharedChecksStorageV2({owner:()=>identity,primary:()=>false});
    const [main,checks]=await Promise.all([p.mainStorageV2.recoverReadOnly(),shared.recoverReadOnly()]);
    if(!current()||!main?.state||!checks?.state)return null;
    // Workbooks have their own durable owner; use the established Main
    // projection so its UI-only external-workbook marker is canonical too.
    const snapshot={...p.stateSnapshots.prepareCloudState(main.state),checks:checks.state.checks};
    const matches=()=>current()&&p.stateSnapshots.sameOrderCloudData(snapshot,p.model.state)&&equalSyncJson(snapshot.checks,p.model.state.checks);
    return matches()?{state:snapshot,current:matches}:null;
  }
  return {owner,bootstrap,preparing,mode,createRuntime,createCloudPorts,createSharedComposition,recoverShared,captureFolderState,configure,ownerAdoption,startupProtocol,startupAdmission,startStorageV2OwnerTransfer,resumeStorageV2OwnerTransfer,
    ownerUiPorts:()=>({storageOwnerCurrent:()=>owner.current(),storageOwnerAdoption:()=>ownerAdoption()}),
    localBirthLifecyclePorts:()=>({hydrateLocalBirth:()=>localBirth.hydrate()}),
    ownerTransferLifecyclePorts:()=>({hydrateStorageV2OwnerTransfer:()=>ownerTransfer.hydrate()}),
    ownerTransferUiPorts:()=>({startStorageV2OwnerTransfer,resumeStorageV2OwnerTransfer,storageV2OwnerTransferPreparing:()=>!!ownerTransfer?.preparing||transferRebinding}),
  };
}
