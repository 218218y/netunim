import {esc, uid} from '../../core/values.js';
import {checkNum, checkMoney} from '../../core/money.js';
import {generatedCheckSeriesRow, nextSeriesCheckNumber} from './model.js';
import {checkAddMonthsISO, checkTodayISO} from '../../core/dates.js';
import {$} from '../../state/constants.js';
import {applyCheckBankReview,removableCheckBankEvents,removeCheckBankEvents} from '../../shared/check-bank-review.js';

// Dependencies are supplied by the composition root; this module has no startup side effects.
export function createDomainsChecksEditor({model, ui, toast, checkDateEditorMarkup, modal, setCheckDateValue, normalizeCheckModalDates, scheduleCheckSave, closeModal, confirmDialog}){
  function openCheckModal(id){
    if(id){
      const c=model.state.checks.find(x=>x.id===id);
      if(!c)return toast('הצ\'ק לא נמצא');
      modal('עריכת צ\'ק',(
        `<div class="form-grid"><div class="field"><label>שם</label><input id="fName" value="${esc(c.name)}" autofocus></div><div class="field"><label>סכום</label><input id="fAmount" type="number" min="0" step="0.01" inputmode="decimal" value="` +
        `${esc(c.amount||'')}"></div><div class="field"><label>תאריך פירעון</label>${checkDateEditorMarkup('fDue',c.dueDate||'',{label:'תאריך פירעון'})}<div class="check-date-hint">יום / חודש / 2 ספרות שנה</div></div><div class="field"><label>סטטוס</label><select id="fStatus">` +
        `${['בקופה','הופקד - במעקב','נפרע','חזר','בוטל'].map(s=>`<option ${c.status===s?'selected':''}>${esc(s)}</option>`).join('')}</select></div><div class="field"><label>סיווג</label><label class="check-account-checkbox"><input id="fCheckHome" type="checkbox" ` +
        `${c.account==='ביתי'?'checked':''}> צ׳ק ביתי</label></div><div class="field"><label>מספר צ'ק</label><input id="fNum" value="${esc(c.checkNumber)}"></div><div class="field full"><label>הערה</label><textarea id="fNote">` +
        `${esc(c.note)}</textarea><label><input type="checkbox" id="fCheckAuto" ${c.bankAutomationDisabled===true?'':'checked'}> זיהוי הפקדה ומעקב אוטומטי בבנק</label></div></div>`),(
        `<button class="btn primary" data-action="save-check" data-click-arg0="${esc(id)}">שמור שינויים</button><button class="btn" data-action="close-modal">ביטול</button><button class="btn danger" style="margin-right:auto" data-action="delete-check" data-click-arg0="` +
        `${esc(id)}">מחיקה</button>`));
      return
    }
    modal('צ\'ק חדש',(
      `<div class="form-grid"><div class="field"><label>שם לקוח</label><input id="fName" autofocus></div><div class="field"><label>מספר צ'קים</label><input id="fCheckCount" ` +
      `class="check-count-input" type="number" min="1" max="60" step="1" inputmode="numeric" value="1" data-input="change-check-series-count"></div><div class="field"><label>סטטוס</label>` +
      `<select id="fStatus">${['בקופה','הופקד - במעקב','נפרע','חזר','בוטל'].map(s=>`<option ${s==='בקופה'?'selected':''}>${esc(s)}</option>`).join('')}</select></div><div class="field"><label>סיווג</label><label class="check-account-checkbox"><input id="fCheckHome" type="checkbox"> צ׳ק ביתי</label></div><div ` +
      `class="check-series-wrap"><div class="check-series-head"><span>#</span><span>תאריך פירעון</span><span>סכום</span><span>מספר צ'ק</span></div><div id="checkSeriesRows"></div></div>` +
      `<div class="check-series-note">ממלאים את השורה הראשונה ובוחרים מספר צ'קים. השורות הבאות נוצרות חודש אחר חודש באותו יום ובאותו סכום. אפשר לשנות ידנית כל תאריך, סכום או מספר צ'ק ` +
      `לפני השמירה. בשנה מקלידים שתי ספרות בלבד, למשל 26 = 2026.</div><div class="field full"><label>הערה</label><textarea id="fNote"></textarea></div></div>`),
      `<button class="btn primary" data-action="save-check-series">הוסף צ'קים</button><button class="btn" data-action="close-modal">ביטול</button>`);
    renderCheckSeriesRows([{date:'',amount:'',number:'',manualDate:false,manualAmount:false,manualNumber:false}])
  }
  function checkSeriesDrafts(){
    return [...document.querySelectorAll('#checkSeriesRows .check-series-row')].map(row=>({
      date:row.querySelector('[data-series-field="date"]')?.value||'',
      amount:row.querySelector('[data-series-field="amount"]')?.value||'',
      number:row.querySelector('[data-series-field="number"]')?.value.trim()||'',
      manualDate:row.querySelector('[data-series-field="date"]')?.dataset.manual==='1',
      manualAmount:row.querySelector('[data-series-field="amount"]')?.dataset.manual==='1',
      manualNumber:row.querySelector('[data-series-field="number"]')?.dataset.manual==='1'
    }))
  }
  function renderCheckSeriesRows(rows){
    const host=$('#checkSeriesRows');
    if(!host)return;
    host.innerHTML=rows.map((r,i)=>(`<div class="check-series-row"><div class="check-series-index">${i+1}</div>${checkDateEditorMarkup('',r.date||'',{series:true,seriesField:'date',manual:r.manualDate,role:i===0?'series-first':'series-manual',label:`תאריך פירעון בצ'ק ${i+1}`})}<input data-series-field="amount" data-manual="` +
      `${esc(r.manualAmount?'1':'0')}" type="number" min="0" step="0.01" inputmode="decimal" value="${esc(r.amount||'')}" ${i===0?'data-input="sync-check-series-from-first"':'data-input="mark-check-series-manual"'}><input data-series-field="number" data-manual="` +
      `${esc(r.manualNumber?'1':'0')}" value="${esc(r.number||'')}" ${i===0?'data-input="sync-check-series-from-first"':'data-input="mark-check-series-manual"'}></div>`)).join('')
  }
  function markCheckSeriesManual(input){
    input.dataset.manual='1'
  }
  function changeCheckSeriesCount(){
    const input=$('#fCheckCount');
    if(!input)return;
    let count=Math.round(checkNum(input.value));
    count=Math.min(60,Math.max(1,count||1));
    input.value=count;
    const current=checkSeriesDrafts();
    if(current.length===count){
      syncCheckSeriesFromFirst();
      return
    }
    const first=current[0]||{date:'',amount:'',number:''},rows=[];
    for(let i=0;i<count;i++)rows.push(current[i]||generatedCheckSeriesRow(first,i));
    renderCheckSeriesRows(rows);
    syncCheckSeriesFromFirst()
  }
  function syncCheckSeriesFromFirst(){
    const rows=[...document.querySelectorAll('#checkSeriesRows .check-series-row')];
    if(!rows.length)return;
    const first={
      date:rows[0].querySelector('[data-series-field="date"]')?.value||'',
      amount:rows[0].querySelector('[data-series-field="amount"]')?.value||'',
      number:rows[0].querySelector('[data-series-field="number"]')?.value.trim()||''
    };
    rows.slice(1).forEach((row,j)=>{
      const i=j+1,date=row.querySelector('[data-series-field="date"]'),amount=row.querySelector('[data-series-field="amount"]'),number=row.querySelector('[data-series-field="number"]');
      if(date?.dataset.manual!=='1')setCheckDateValue(date,first.date?checkAddMonthsISO(first.date,i):'');
      if(amount?.dataset.manual!=='1')amount.value=first.amount;
      if(number?.dataset.manual!=='1')number.value=nextSeriesCheckNumber(first.number,i)
    })
  }
  function saveCheckSeries(){
    if(!normalizeCheckModalDates())return;
    syncCheckSeriesFromFirst();
    const name=$('#fName').value.trim(),status=$('#fStatus').value,account=$('#fCheckHome')?.checked?'ביתי':'עסקי',note=$('#fNote').value.trim();
    const drafts=checkSeriesDrafts();
    if(!name)return toast('יש למלא שם לקוח');
    if(!drafts.length)return toast('יש להוסיף לפחות צ\'ק אחד');
    const invalid=drafts.findIndex(r=>!r.date||checkMoney(r.amount)<=0);
    if(invalid>=0)return toast(`יש למלא תאריך וסכום בצ'ק ${invalid+1}`);
    const depositedStatus=['הופקד - במעקב','נפרע'].includes(status);
    const createdAt=checkTodayISO(),
      depositedAt=depositedStatus?new Date().toISOString():null,
      records=drafts.map(r=>({
      id:uid('CHK'),
      name,
      account,
      amount:checkMoney(r.amount),
      dueDate:r.date,
      status,
      depositDate:depositedStatus?r.date:null,
      depositedAt,
      depositSeq:null,
      clearedDate:status==='נפרע'?checkTodayISO():null,
      checkNumber:r.number,
      note,
      createdAt
    }));
    model.state.checks.push(...records);
    closeModal();
    scheduleCheckSave(records.length===1?'הצ\'ק נוסף':`${records.length} צ'קים נוספו`,{
      operations:records.map(record=>({type:'put',collection:'checks',id:record.id,mode:'insert',index:model.state.checks.findIndex(row=>row.id===record.id),record}))
    })
  }
  function saveCheck(id){
    if(!normalizeCheckModalDates())return;
    const old=model.state.checks.find(x=>x.id===id);
    if(!old)return toast('הצ\'ק לא נמצא');
    const rec={
      ...old,
      id,
      name:$('#fName').value.trim(),
      account:$('#fCheckHome')?.checked?'ביתי':'עסקי',
      amount:checkMoney($('#fAmount').value),
      dueDate:$('#fDue').value,
      bankAutomationDisabled:document.getElementById('fCheckAuto')?.checked===false,
      status:$('#fStatus').value,
      depositDate:null,
      depositedAt:old.depositedAt||null,
      depositSeq:old.depositSeq||null,
      clearedDate:old.clearedDate||null,
      checkNumber:$('#fNum').value.trim(),
      note:$('#fNote').value.trim(),
      createdAt:old.createdAt||checkTodayISO()
    };
    if(rec.amount!==Number(old.amount))rec.amountEditId=uid('CHECK_AMOUNT');
    if(!rec.name||!rec.amount||!rec.dueDate)return toast('יש למלא שם, סכום ותאריך');
    const wasDeposited=['הופקד - במעקב','נפרע'].includes(old.status),isDeposited=['הופקד - במעקב','נפרע'].includes(rec.status);
    rec.depositDate=isDeposited?rec.dueDate:(rec.status==='חזר'&&old.depositDate?rec.dueDate:null);
    if(old.depositDate&&(wasDeposited||rec.status===old.status)&&rec.dueDate===old.dueDate&&['הופקד - במעקב','נפרע','חזר'].includes(rec.status))rec.depositDate=old.depositDate;
    if(isDeposited&&!wasDeposited){
      rec.depositedAt=new Date().toISOString();
      rec.depositSeq=null
    }
    if(rec.status==='נפרע'&&!rec.clearedDate)rec.clearedDate=checkTodayISO();
    if(rec.status!=='נפרע')rec.clearedDate=null;
    model.state.checks[model.state.checks.findIndex(x=>x.id===id)]=rec;
    closeModal();
    scheduleCheckSave('הצ\'ק עודכן',{operations:[{type:'put',collection:'checks',id:rec.id,mode:'replace',record:rec}]})
  }
  function markCheckDeposited(id){
    const c=model.state.checks.find(x=>x.id===id);
    if(!c||c.status!=='בקופה')return false;
    c.status='הופקד - במעקב';
    c.depositDate=c.dueDate;
    c.depositedAt=new Date().toISOString();
    c.depositSeq=null;
    c.clearedDate=null;
    scheduleCheckSave('הצ\'ק סומן כהופקד',{operations:[{type:'put',collection:'checks',id:c.id,mode:'replace',record:c}]});
    return true
  }
  function markCheckCleared(id){
    const c=model.state.checks.find(x=>x.id===id);
    if(!c)return;
    const wasDeposited=['הופקד - במעקב','נפרע'].includes(c.status);
    c.status='נפרע';
    c.clearedDate=checkTodayISO();
    c.depositDate=c.depositDate||c.dueDate;
    if(!wasDeposited){
      c.depositedAt=new Date().toISOString();
      c.depositSeq=null
    }
    scheduleCheckSave('הצ\'ק סומן כנפרע',{operations:[{type:'put',collection:'checks',id:c.id,mode:'replace',record:c}]})
  }
  async function deleteCheck(id){
    const c=model.state.checks.find(x=>x.id===id);
    if(!c)return;
    if(!await confirmDialog('מחיקת צ׳ק',`למחוק את הצ'ק של ${c.name}?`,{confirmText:'מחק צ׳ק'}))return;
    model.state.checks=model.state.checks.filter(x=>x.id!==id);
    closeModal();
    scheduleCheckSave('הצ\'ק נמחק',{deletedIds:[id],mutationType:'delete',surface:'orders.delete.checks',operations:[{type:'delete',collection:'checks',id}]})
  }
  async function deleteChecksBulkSelected(){
    const ids=[...ui.checksBulkSelected].filter(id=>model.state.checks.some(x=>x.id===id));
    if(!ids.length)return toast('לא נבחרו צ\'קים למחיקה');
    if(!await confirmDialog('מחיקת צ׳קים',`למחוק ${ids.length} צ'קים שנבחרו?\n\nהמחיקה תסונכרן למאגר הצ'קים המשותף כאשר הענן פעיל.`,{confirmText:'מחק צ׳קים'}))return;
    const set=new Set(ids);
    model.state.checks=model.state.checks.filter(x=>!set.has(x.id));
    ui.checksBulkSelected.clear();
    ui.checksBulkAnchorId=null;
    scheduleCheckSave(`${ids.length} צ'קים נמחקו`,{deletedIds:ids,mutationType:'bulk-delete',surface:'orders.bulk.checks',operations:ids.map(id=>({type:'delete',collection:'checks',id}))})
  }
  function reviewCheckBank(id,eventId,action){
    if(action==='remove-selected'){
      const selected=new Set(Array.isArray(id)?id:[]),changed=[];
      for(const check of model.state.checks){
        if(selected.has(check.id)&&removeCheckBankEvents(check,removableCheckBankEvents(check,{bulk:true}).map(m=>m.eventId)))changed.push(check)
      }
      if(changed.length)scheduleCheckSave('הודעות שטופלו הוסרו',{operations:changed.map(record=>({type:'put',collection:'checks',id:record.id,mode:'replace',record}))});
      return !!changed.length;
    }
    if(!applyCheckBankReview(model.state.checks,id,eventId,action))return false;
    const check=model.state.checks.find(row=>row.id===id);
    if(!check)throw new Error('check_bank_review_target_missing');
    scheduleCheckSave('בדיקת התאמת הצ׳ק נשמרה',{operations:[{type:'put',collection:'checks',id:check.id,mode:'replace',record:check}]});
    return true
  }
  return {
    reviewCheckBank,
    openCheckModal,
    checkSeriesDrafts,
    renderCheckSeriesRows,
    markCheckSeriesManual,
    changeCheckSeriesCount,
    syncCheckSeriesFromFirst,
    saveCheckSeries,
    saveCheck,
    markCheckDeposited,
    markCheckCleared,
    deleteCheck,
    deleteChecksBulkSelected
  };
}
