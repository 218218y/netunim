import {checkFutureTotalData,checkMonthSummaryMarkup} from '../../shared/check-summary.js';
import {money} from '../../core/money.js';
import {esc} from '../../core/values.js';
import {applyBulkRangeSelection} from '../../core/bulk-selection.js';
import {checkUrgency, checkBelongsToAccountData, checkIsClosedStatus, futureCheckMonthsData} from './model.js';
import {checkMonthKey, checkMonthLabel, checkDateFmt, checkTodayISO} from '../../core/dates.js';
import {searchMatch} from '../../core/search.js';
import {$} from '../../state/constants.js';

import {checkBankReviewMarkup,checkBankStatusMarkup,checkBankActivityMarkup,checkMorningSourceMarkup} from '../../shared/check-bank-review.js';

// Dependencies are supplied by the composition root; this module has no startup side effects.
export function createDomainsChecksView({getBankImageContext=()=>({}), model, ui, checksSession, loadSession, mountViewLayout}){
function checkAccountFilterMatch(check){return ui.checkAccount==='all'||checkBelongsToAccountData(check,ui.checkAccount)}
function visibleChecks(){let rows=model.state.checks.filter(checkAccountFilterMatch);if(ui.checkTab==='open')rows=rows.filter(x=>!checkIsClosedStatus(x.status));if(ui.checkTab==='deposited')rows=rows.filter(x=>x.status==='הופקד - במעקב');if(ui.checkTab==='closed')rows=rows.filter(x=>['נפרע','חזר','בוטל'].includes(x.status));if(ui.checkYear!=='all')rows=rows.filter(x=>x.dueDate?.startsWith(ui.checkYear+'-'));const q=ui.checkSearchValue.trim();if(q)rows=rows.filter(x=>searchMatch(q,[x.name,x.checkNumber,x.note,x.status,x.account,x.amount,x.dueDate,x.depositDate,x.clearedDate,x.createdAt],[x.dueDate,x.depositDate,x.clearedDate,x.createdAt]));return rows.sort((a,b)=>(a.dueDate||'').localeCompare(b.dueDate||''))}

function visibleChecksTotal(rows=visibleChecks()){return ui.checkTab==='open'?checkFutureTotalData(rows):rows.reduce((sum,row)=>sum+(Number(row.amount)||0),0)}
function checkTotalLabel(){return ui.checkTab==='open'?'סה״כ צ׳קים עתידיים':ui.checkTab==='deposited'?'סה״כ צ׳קים שהופקדו':'סה״כ צ׳קים שנסגרו'}

function checkBadgeStatus(s){const cls=s==='בקופה'?'blue':s==='הופקד - במעקב'?'orange':s==='נפרע'?'green':s==='חזר'?'red':'';return `<span class="checks-badge ${esc(cls)}">${esc(s)}</span>`}

function checkDueBadge(c){const u=checkUrgency(c);if(u==='overdue')return '<span class="checks-badge red">עבר מועד</span>';if(u==='week')return '<span class="checks-badge orange">השבוע</span>';if(u==='month')return '<span class="checks-badge yellow">עד 30 יום</span>';return ''}

function checksCloudLabel(){if(checksSession.checksCloudLastError)return `<span class="checks-cloud-note warn" title="${esc(checksSession.checksCloudLastError)}">צ'קים בענן: נדרשת בדיקה</span>`;if(checksSession.checksCloudRevision>0)return `<span class="checks-cloud-note synced">צ'קים משותפים · מקור עצמאי</span>`;if(loadSession())return '<span class="checks-cloud-note warn">צ\'קים בענן: טרם נטענו מהמאגר המשותף</span>';return '<span class="checks-cloud-note">צ\'קים מקומיים · יסתנכרנו לאחר חיבור לענן</span>'}

function toggleChecksBulkMode(){ui.checksBulkMode=!ui.checksBulkMode;ui.checksBulkSelected.clear();ui.checksBulkAnchorId=null}

function toggleChecksBulkRow(id,checked,shiftKey=false){if(!ui.checksBulkMode||!model.state.checks.some(x=>x.id===id))return;ui.checksBulkAnchorId=applyBulkRangeSelection({selected:ui.checksBulkSelected,orderedIds:checksVisibleIds(),id,checked,shiftKey,anchorId:ui.checksBulkAnchorId});syncChecksBulkUi()}

function checksVisibleIds(){return [...document.querySelectorAll('[data-check-id]')].map(x=>x.dataset.checkId).filter(Boolean)}

function toggleChecksBulkVisible(checked){if(!ui.checksBulkMode)return;checksVisibleIds().forEach(id=>checked?ui.checksBulkSelected.add(id):ui.checksBulkSelected.delete(id));document.querySelectorAll('.checks-bulk-check[data-check-row]').forEach(cb=>cb.checked=checked);syncChecksBulkUi()}

function syncChecksBulkUi(){if(!ui.checksBulkMode)return;const valid=new Set(model.state.checks.map(x=>x.id));[...ui.checksBulkSelected].forEach(id=>{if(!valid.has(id))ui.checksBulkSelected.delete(id)});const del=$('#checksBulkDelete');if(del){del.disabled=!ui.checksBulkSelected.size;del.textContent=ui.checksBulkSelected.size?`מחק ${ui.checksBulkSelected.size}`:'מחק נבחרים'}const visible=checksVisibleIds(),n=visible.filter(id=>ui.checksBulkSelected.has(id)).length;document.querySelectorAll('[data-check-all]').forEach(h=>{h.checked=visible.length>0&&n===visible.length;h.indeterminate=n>0&&n<visible.length});document.querySelectorAll('[data-check-id]').forEach(row=>row.classList.toggle('checks-bulk-selected',ui.checksBulkSelected.has(row.dataset.checkId)))}

function checksBulkControls(){return `<div class="checks-bulk-actions"><button class="btn small checks-bulk-toggle ${esc(ui.checksBulkMode?'active':'')}" data-action="toggle-checks-bulk-mode">${ui.checksBulkMode?'סיום בחירה':'בחירה'}</button>${ui.checksBulkMode?'<button id="checksBulkDelete" class="btn danger small checks-bulk-delete" data-action="delete-checks-bulk-selected" disabled>מחק נבחרים</button>':''}</div>`}

function checksBulkHeader(){return ui.checksBulkMode?'<th class="checks-bulk-col"><input class="checks-bulk-check" type="checkbox" data-check-all title="בחר את כל השורות המוצגות" data-change="toggle-checks-bulk-visible"></th>':''}

function checksBulkCell(id){return ui.checksBulkMode?`<td class="checks-bulk-col"><input class="checks-bulk-check" data-check-row type="checkbox" ${ui.checksBulkSelected.has(id)?'checked':''} aria-label="בחר צ'ק" data-action="toggle-checks-bulk-row" data-change="toggle-checks-bulk-row" data-click-arg0="${esc(id)}"></td>`:''}

function checksHeaderContextMarkup(){
  const bankAccountFilter=ui.checkAccount==='all'?null:ui.checkAccount;
  return `<div class="kupa-checks-status">${checkBankActivityMarkup(model.state.checks,bankAccountFilter,ui.checkBankHistoryPage,getBankImageContext(),{floatingMenu:true})}${checksCloudLabel()}</div>`;
}

function checksMarkup({embedded=false,showEmbeddedStatus=true,showBankActivity=true}={}){
  const bankAccountFilter=ui.checkAccount==='all'?null:ui.checkAccount,years=[...new Set(model.state.checks.filter(checkAccountFilterMatch).map(x=>x.dueDate?.slice(0,4)).filter(Boolean))].sort();
  if(ui.checkYear!=='all'&&!years.includes(ui.checkYear))ui.checkYear='all';
  const rows=visibleChecks(),groups={};rows.forEach(r=>(groups[checkMonthKey(r.dueDate)]??=[]).push(r));
  const toolbar=`<div class="checks-toolbar"><div class="checks-segmented"><button class="${esc(ui.checkTab==='open'?'active':'')}" data-action="check-tab">הכל</button><button class="${esc(ui.checkTab==='deposited'?'active':'')}" data-action="check-tab-2">הופקדו</button><button class="${esc(ui.checkTab==='closed'?'active':'')}" data-action="check-tab-3">נסגרו</button></div><select data-change="check-year"><option value="all">כל השנים</option>${years.map(y=>`<option value="${esc(y)}" ${ui.checkYear===y?'selected':''}>${esc(y)}</option>`).join('')}</select><input class="checks-search" value="${esc(ui.checkSearchValue)}" placeholder="חיפוש שם / מספר / הערה" data-input="render-checks-search"><span class="checks-grand-total" id="checksGrandTotal">${checkTotalLabel()} <b>${money(visibleChecksTotal(rows))}</b></span><div class="check-account-toggle" role="group" aria-label="סיווג צ׳קים"><button class="${esc(ui.checkAccount==='all'?'active':'')}" data-action="check-account" data-click-arg0="all">הכל</button><button class="${esc(ui.checkAccount==='עסקי'?'active':'')}" data-action="check-account" data-click-arg0="עסקי">עסקי</button><button class="${esc(ui.checkAccount==='ביתי'?'active':'')}" data-action="check-account" data-click-arg0="ביתי">ביתי</button></div><span class="checks-spacer"></span>${checksBulkControls()}${ui.checksBulkMode?'<button type="button" class="btn" data-action="review-check-bank" data-click-arg2="remove-selected">הסר הודעות שטופלו לצ׳קים שנבחרו</button>':''}<button class="btn primary" data-action="open-check-modal">+ צ'ק חדש</button></div>`;
  const bankReview=checkBankReviewMarkup(model.state.checks,bankAccountFilter),bankActivity=showBankActivity?checkBankActivityMarkup(model.state.checks,bankAccountFilter,ui.checkBankHistoryPage,getBankImageContext()):'',forecast=checkForecastMarkup(),groupsMarkup=`<div id="checkGroups">${renderCheckGroups(groups)}</div>`;
  const heading=embedded?(showEmbeddedStatus?`<div class="checks-embedded-status">${checksCloudLabel()}</div>`:''):`<section class="hero checks-hero"><div><h1>צ'קים</h1></div><div class="actions">${checksCloudLabel()}</div></section>`;
  return `<div class="checks-page ${embedded?'checks-page-embedded':''}">${heading}${toolbar}${bankReview}${bankActivity}${forecast}${groupsMarkup}</div>`;
}

function checkForecastMarkup(){
  const months=futureCheckMonthsData(model.state,{fromMonth:checkMonthKey(checkTodayISO()),year:ui.checkYear,account:ui.checkAccount});
  const max=Math.max(1,...months.map(x=>Math.abs(x.total))),split=Math.ceil(months.length/2),columns=[months.slice(0,split),months.slice(split)],body=months.length?`<div class="checks-forecast-body"><div class="checks-forecast-columns">${columns.filter(column=>column.length).map(column=>`<div class="checks-forecast-list">${column.map(x=>checkForecastBarRow(x,max)).join('')}</div>`).join('')}</div></div>`:`<div class="checks-forecast-body"><div class="checks-forecast-empty">אין צ׳קים עתידיים בקופה בטווח שנבחר.</div></div>`;
  return `<section class="checks-forecast forecast-disclosure-section"><div class="forecast-disclosure-head"><button type="button" class="forecast-disclosure-toggle ${ui.checksForecastOpen?'open':''}" data-action="toggle-checks-forecast" aria-expanded="${ui.checksForecastOpen===true}" aria-controls="checksForecastBody"><span>תצוגת צ׳קים לפי חודש</span><span class="forecast-disclosure-chevron" aria-hidden="true">⌄</span></button></div><div id="checksForecastBody" class="forecast-disclosure-body" ${ui.checksForecastOpen?'':'hidden'}>${body}</div></section>`;
}

function checkForecastBarRow(month,max){const width=month.total===0?0:Math.max(2,Math.abs(month.total)/max*100);return `<div class="checks-forecast-row"><b>${esc(checkMonthLabel(month.key))}</b><div class="checks-forecast-bar"><i style="width:${esc(width)}%"></i></div><div class="checks-forecast-num">${money(month.total)}</div></div>`}

function renderChecks({embedded=false,target=null}={}){const host=target||$('#main');if(!host)return;host.innerHTML=checksMarkup({embedded});if(!embedded)mountViewLayout({sourceSelector:'.checks-page',headCount:2,className:'checks-page',scrollKey:`checks:${ui.checkTab}:${ui.checkYear}`});syncChecksBulkUi()}

function renderChecksSearch(v){ui.checkSearchValue=v;const rows=visibleChecks(),groups={};rows.forEach(r=>(groups[checkMonthKey(r.dueDate)]??=[]).push(r));const host=$('#checkGroups');if(host)host.innerHTML=renderCheckGroups(groups);const total=$('#checksGrandTotal');if(total)total.innerHTML=`${checkTotalLabel()} <b>${money(visibleChecksTotal(rows))}</b>`;syncChecksBulkUi()}

function renderCheckGroups(groups){const keys=Object.keys(groups).sort();if(!keys.length)return '<div class="checks-empty">אין צ\'קים בתצוגה הזאת.</div>';return keys.map(k=>{const arr=groups[k];return `<section class="checks-month"><div class="checks-month-title"><b>${checkMonthLabel(k)}</b><span class="checks-month-total">${checkMonthSummaryMarkup(arr,money)}</span></div><div class="checks-table-wrap"><table class="checks-table"><thead><tr>${checksBulkHeader()}<th>שם</th><th>סכום</th><th>פירעון</th><th>סטטוס</th><th>התראה</th><th>מס' צ'ק</th><th>הערה</th><th></th></tr></thead><tbody>${arr.map(checkRow).join('')}</tbody></table></div></section>`}).join('')}

function checkRow(c){return `<tr data-check-id="${esc(c.id)}" class="${esc(ui.checksBulkSelected.has(c.id)?'checks-bulk-selected':'')}">${checksBulkCell(c.id)}<td data-label="שם"><b>${esc(c.name)}</b>${checkMorningSourceMarkup(c,{documentAction:'morning-open-document'})}</td><td data-label="סכום" class="checks-amount">${money(c.amount)}</td><td data-label="פירעון">${checkDateFmt(c.dueDate)}</td><td data-label="סטטוס">${checkBadgeStatus(c.status)}${checkBankStatusMarkup(c)}</td><td data-label="התראה">${checkDueBadge(c)}</td><td data-label="מספר צ׳ק">${esc(c.checkNumber)||'—'}</td><td data-label="הערה" class="checks-muted">${esc(c.note)||'—'}</td><td data-label="פעולות"><div class="checks-row-actions">${c.status==='בקופה'?`<button class="checks-iconbtn" data-action="mark-check-deposited" data-click-arg0="${esc(c.id)}">הופקד</button>`:''}${c.status==='הופקד - במעקב'?`<button class="checks-iconbtn" data-action="mark-check-cleared" data-click-arg0="${esc(c.id)}">נפרע</button>`:''}<button class="checks-iconbtn" data-action="open-check-modal-2" data-click-arg0="${esc(c.id)}">עריכה</button></div></td></tr>`}

return { checkAccountFilterMatch, visibleChecks, visibleChecksTotal, checkBadgeStatus, checkDueBadge, checksCloudLabel, checksHeaderContextMarkup, toggleChecksBulkMode, toggleChecksBulkRow, checksVisibleIds, toggleChecksBulkVisible, syncChecksBulkUi, checksBulkControls, checksBulkHeader, checksBulkCell, checksMarkup, renderChecks, renderChecksSearch, renderCheckGroups, checkRow };
}
